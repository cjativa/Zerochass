exports.ids = [0];
exports.modules = {

/***/ "./siteconfig.json":
/*!*************************!*\
  !*** ./siteconfig.json ***!
  \*************************/
/*! exports provided: title, description, keywords, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"title\":\"Zerochass\",\"description\":\"Zerochass is an online learning platform, where you can learn more about software engineering and web development. Here you'll find quick and bite-size tutorials about React, TypeScript, JavaScript, NodeJS, and much more on software engineering and web development\",\"keywords\":\"zerochass, company, coding, programming, tutorials, javascript, typescript, software engineering, web development, free\"}");

/***/ })

};;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiIwLmpzIiwic291cmNlUm9vdCI6IiJ9