exports.ids = [31];
exports.modules = {

/***/ "i5SM":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, "isAuthenticated", function() { return /* binding */ isAuthenticated; });

// EXTERNAL MODULE: external "jsonwebtoken"
var external_jsonwebtoken_ = __webpack_require__("tMJi");
var external_jsonwebtoken_default = /*#__PURE__*/__webpack_require__.n(external_jsonwebtoken_);

// CONCATENATED MODULE: ./util/config.ts
const Config = {
  dbHost: process.env.DB_HOST,
  dbUser: process.env.DB_USER,
  dbPassword: process.env.DB_PASSWORD,
  dbName: process.env.DB_NAME,
  zerochassSecret: process.env.ZEROCHASS_SECRET,
  awsRegion: process.env.AWS_REGION,
  awsBucket: process.env.AWS_BUCKET
};
// EXTERNAL MODULE: external "nookies"
var external_nookies_ = __webpack_require__("kG9d");
var external_nookies_default = /*#__PURE__*/__webpack_require__.n(external_nookies_);

// CONCATENATED MODULE: ./server/api/middleware/protectWithAuthentcation.ts



;
/** Returns boolean on user being authenticated */

const isAuthenticated = (req, res) => {
  const authentication = {
    authenticated: null,
    userId: null,
    accessToken: null
  }; // Check if there's a zerochassServerCookie on the request -- if it does exist, the jwt will be available

  const {
    zerochassServerCookie,
    zerochassClientCookie
  } = external_nookies_default.a.get({
    req
  }); // If there's no jwt, update the authentication object

  if (!zerochassServerCookie) {
    authentication['authenticated'] = false;
  } // Else there's a jwt, let's see if it's valid
  else {
      const userPayload = external_jsonwebtoken_default.a.verify(zerochassServerCookie, Config.zerochassSecret); // If the token is invalid (i.e. no payload), clear the cookie and update authentication object

      if (!userPayload) {
        external_nookies_default.a.destroy(null, zerochassServerCookie);
        external_nookies_default.a.destroy(null, zerochassClientCookie);
        authentication['authenticated'] = false;
      } // Else, token is valid - let's set the userId on the request object
      else {
          authentication['userId'] = userPayload['userId'];
          authentication['accessToken'] = userPayload['accessToken'];
          authentication['authenticated'] = true;
        }
    }

  return authentication;
};
/** Middleware that secures protected routes with authentication */

const handleAccess = (request, response) => {
  const {
    userId,
    authenticated,
    accessToken
  } = isAuthenticated(request, response);

  if (authenticated) {
    request['authenticated'] = true;
    request['userId'] = userId;
    request['accessToken'] = accessToken;
  } else {
    response.status(401).json(`Invalid or missing authorization token`);
  }

  return authenticated;
};
/** Protects secured API routes against non-authenticated sessions.
 * Also adds userId and access token to request object for authenticated sessions */


const protectWithAuthentication = handler => (request, response) => {
  // Determine if the session is authenticated
  const isAuthenticated = handleAccess(request, response); // If the session was authenticated, allows the requested endpoint to handle responding

  if (isAuthenticated) return handler(request, response);
};

/* harmony default export */ var protectWithAuthentcation = __webpack_exports__["default"] = (protectWithAuthentication);

/***/ })

};;