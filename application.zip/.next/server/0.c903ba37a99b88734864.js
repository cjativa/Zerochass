exports.ids = [0];
exports.modules = {

/***/ "D8MT":
/***/ (function(module) {

module.exports = JSON.parse("{\"title\":\"Zerochass\",\"description\":\"Zerochass is an online learning platform, where you can learn more about software engineering and web development. Here you'll find quick and bite-size tutorials about React, TypeScript, JavaScript, NodeJS, and much more on software engineering and web development\",\"keywords\":\"zerochass, company, coding, programming, tutorials, javascript, typescript, software engineering, web development, free\"}");

/***/ })

};;