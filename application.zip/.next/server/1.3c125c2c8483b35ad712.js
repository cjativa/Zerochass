exports.ids = [1];
exports.modules = {

/***/ "nhez":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return protectPageWithAuthentication; });
async function protectPageWithAuthentication({
  req,
  res
}) {
  const {
    isAuthenticated
  } = await __webpack_require__.e(/* import() */ 31).then(__webpack_require__.bind(null, "i5SM"));
  const {
    authenticated,
    accessToken,
    userId
  } = isAuthenticated(req, res);

  if (!authenticated) {
    res.writeHead(302, {
      Location: '/'
    });
    res.end();
  } else {
    req['authenticated'] = true;
    req['userId'] = userId;
    req['accessToken'] = accessToken;
  }
}
;

/***/ })

};;