module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 13);
/******/ })
/************************************************************************/
/******/ ({

/***/ 13:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("GvfU");


/***/ }),

/***/ "CaIY":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(__dirname) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Knex; });
/* harmony import */ var knex__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("SfJF");
/* harmony import */ var knex__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(knex__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("ebvM");


const KnexConfiguration = {
  development: {
    client: 'pg',
    connection: {
      host: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbHost,
      user: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbUser,
      password: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbPassword,
      database: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbName,
      port: 5432
    },
    migrations: {
      directory: __dirname + '/db/pg/migrations'
    },
    seeds: {
      directory: __dirname + '/db/pg/seeds/development'
    }
  },
  production: {
    client: 'pg',
    connection: {
      host: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbHost,
      user: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbUser,
      password: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbPassword,
      database: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbName,
      ssl: true
    },
    migrations: {
      directory: __dirname + '/db/pg/migrations'
    },
    seeds: {
      directory: __dirname + '/db/pg/seeds/production'
    }
  }
};
const Knex = knex__WEBPACK_IMPORTED_MODULE_0___default()(KnexConfiguration[_utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].environment]);
/* WEBPACK VAR INJECTION */}.call(this, "/"))

/***/ }),

/***/ "GvfU":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _server_dataAccess_tag_entity__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("M4QR");


const handler = async (request, response) => {
  const {
    tag
  } = request.query;
  const matchingTags = await _server_dataAccess_tag_entity__WEBPACK_IMPORTED_MODULE_0__[/* TagDB */ "a"].findTag('tag', tag);
  response.json(matchingTags);
};

/* harmony default export */ __webpack_exports__["default"] = (handler);

/***/ }),

/***/ "M4QR":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, "a", function() { return /* reexport */ tag_TagDAO; });

// EXTERNAL MODULE: ./server/database/knex.ts
var knex = __webpack_require__("CaIY");

// CONCATENATED MODULE: ./server/dataAccess/tag/index.ts

class tag_TagDAO {
  static async listTags() {
    return await knex["a" /* Knex */].select('*').from('tags');
  }

  static async findTag(prop, value) {
    return await knex["a" /* Knex */].select('*').from('tags').where(prop, value);
  }

  static async relateWithTutorial(tags, tutorialId) {
    // Add any tags that don't exist in the schema
    const insertableTags = tags.map(tag => {
      return {
        tag
      };
    });
    await Object(knex["a" /* Knex */])('tags').insert(insertableTags).onConflict('tag').ignore(); // Remove any tags that should no longer be associated with the tutorial

    await tag_TagDAO.validateWithTutorial(tags, tutorialId); // Get the ids for these tags

    const tagIds = await Object(knex["a" /* Knex */])('tags').select('id').whereIn('tag', tags); // Turn them into the tag/tutorial id pairs

    const tutorialTagPairs = tagIds.map(tagId => {
      return {
        tagId: tagId.id,
        tutorialId
      };
    });
    await Object(knex["a" /* Knex */])('tutorial_tag_relations').insert(tutorialTagPairs).onConflict(['tagId', 'tutorialId']).ignore();
  }

  static async validateWithTutorial(tags, tutorialId) {
    // Find out which tags are associated with this tutorial right now
    const tagsInDatabase = (await knex["a" /* Knex */].raw(`
        SELECT tags.tag, tags.id
        FROM tags
        INNER JOIN tutorial_tag_relations ttr
        ON 
            ttr."tagId" = tags.id
        WHERE 
            ttr."tutorialId" = ${tutorialId};
        `)).rows; // Any not provided, or any provided that aren't what the database has on record
    // means we need to remove from the database

    const tagIdsToRemove = tagsInDatabase.reduce((acc, tagItem) => {
      const tagShouldBeRemoved = !tags.find(tag => tag.toLowerCase() === tagItem.tag.toLowerCase());

      if (tagShouldBeRemoved && tagItem.hasOwnProperty('id')) {
        acc.push(tagItem.id);
      }

      return acc;
    }, []);

    if (tagIdsToRemove.length > 0) {
      await Object(knex["a" /* Knex */])('tutorial_tag_relations').delete().whereIn('tagId', tagIdsToRemove).andWhere({
        tutorialId
      });
    }
  }

}
;
// CONCATENATED MODULE: ./server/dataAccess/tag/entity.ts


/***/ }),

/***/ "SfJF":
/***/ (function(module, exports) {

module.exports = require("knex");

/***/ }),

/***/ "ebvM":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
const Config = {
  dbHost: process.env.DB_HOST,
  dbUser: process.env.DB_USER,
  dbPassword: process.env.DB_PASSWORD,
  dbName: process.env.DB_NAME,
  zerochassSecret: process.env.ZEROCHASS_SECRET,
  awsRegion: process.env.AWS_REGION,
  awsBucket: process.env.AWS_BUCKET,
  port: process.env.PORT,
  environment: ("production" || false).toLowerCase()
};
/* harmony default export */ __webpack_exports__["a"] = (Config);

/***/ })

/******/ });