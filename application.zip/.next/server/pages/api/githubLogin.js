module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 4);
/******/ })
/************************************************************************/
/******/ ({

/***/ "+jo5":
/***/ (function(module, exports) {

module.exports = require("@octokit/rest");

/***/ }),

/***/ "2v0O":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return TutorialSectionDAO; });
/* harmony import */ var _database_knex__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("CaIY");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


class TutorialSectionDAO {
  static async getSeparateSections(tutorialSections, tutorialId) {
    const sectionsToAdd = [];
    const sectionsToUpdate = [];
    const sectionsToDelete = []; // Compare the incoming tutorial sections with what's on file for this tutorial

    const existingSectionIds = await TutorialSectionDAO.listTutorialSectionIds(tutorialId);
    const providedSectionIds = tutorialSections.filter(section => section.hasOwnProperty('id')).map(section => section.id); // The section id's to delete are the ones that exist in the database
    // but are no longer being provided in the request - i.e. these need to be removed

    const sectionIdsToDelete = existingSectionIds.filter(existingSectionId => !providedSectionIds.includes(parseInt(existingSectionId.toString())));
    sectionsToDelete.push(...sectionIdsToDelete);
    tutorialSections.forEach(tutorialSection => {
      // If there's an id then the section needs to be updated
      if (tutorialSection.hasOwnProperty('id')) {
        sectionsToUpdate.push(tutorialSection);
      } // Otherwise, no id means it needs to be added
      else {
          sectionsToAdd.push(tutorialSection);
        }
    });
    return {
      sectionsToAdd,
      sectionsToUpdate,
      sectionsToDelete
    };
  }

  /** something */
  static async listTutorialSections(tutorialId) {
    return await _database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"].select('*').from('tutorial_sections').where('tutorialId', tutorialId).orderBy('id', 'asc');
  }

  static async addOrUpdateTutorialSection(tutorialSections, tutorialId) {
    const {
      sectionsToAdd,
      sectionsToUpdate,
      sectionsToDelete
    } = await TutorialSectionDAO.getSeparateSections(tutorialSections, tutorialId);
    let addedSections = [];
    let updatedSections = [];
    const sectionsWithId = sectionsToAdd.map(section => {
      return _objectSpread(_objectSpread({}, section), {}, {
        tutorialId
      });
    });

    if (sectionsToAdd.length > 0) {
      const addedSections = await Object(_database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"])('tutorial_sections').insert(sectionsWithId).returning('*');
      addedSections.push(...addedSections);
    }

    if (sectionsToUpdate.length > 0) {
      for (let i = 0; i < sectionsToUpdate.length; i++) {
        const section = sectionsToUpdate[i];
        const updatedSection = await Object(_database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"])('tutorial_sections').update(section).where({
          'id': section.id,
          'tutorialId': tutorialId
        }).returning('*');
        updatedSections.push(...updatedSection);
      }
    }

    if (sectionsToDelete.length > 0) {
      await TutorialSectionDAO.deleteSections(tutorialId, sectionsToDelete);
    }

    return [...addedSections, ...updatedSections];
  }

  static async deleteTutorialSection(id) {
    const response = await Object(_database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"])('tutorial_sections').where('id', id).del();

    if (response == 1) {
      return true;
    }

    return false;
  }

  static async listTutorialSectionIds(tutorialId) {
    const sectionIdsRes = await _database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"].select('id').from('tutorial_sections').where('tutorialId', tutorialId);
    const sectionIds = sectionIdsRes.map(el => el.id);
    return sectionIds;
  }

  static async deleteSections(tutorialId, sectionIds) {
    // Delete these sections from the tutorial progress table
    await Object(_database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"])('tutorial_sections_progress').delete().whereIn('sectionId', sectionIds); // Delete the tutorial sections

    await Object(_database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"])('tutorial_sections').delete().whereIn('id', sectionIds).andWhere({
      tutorialId
    });
  }

}
;
/**
 *
 *
 *
  /** Adds or updates the sections for a tutorial */

/*
public static async addSections(tutorialId: number, tutorialSections: TutorialInterface['sections']) {

  const sectionRequests = tutorialSections.map((section) => {
      let query, values;
      const { title, content, id } = section;

      // If the section has an id, then it needs to be updated
      if (id) {
          query = `
          UPDATE tutorial_sections
          SET
              "title" = ($1),
              "content" = ($2)
          WHERE "id" = ($3) AND "tutorialId" = ($4)
          `;
          values = [title, content, id, tutorialId];
      }

      // Otherwise, no existing id means it's an insert
      else {
          query = `
          INSERT INTO tutorial_sections ("title", "content", "tutorialId")
          VALUES ($1, $2, $3)
          `;
          values = [title, content, tutorialId];
      }

      return Client.executeQuery(query, values);
  });

  await Promise.all(sectionRequests);
};

/** Deletes any sections that from the tutorial that exist in the database but were not sent along with an update */

/*
 */

/***/ }),

/***/ 4:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("aWGM");


/***/ }),

/***/ "64Oa":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, "a", function() { return /* reexport */ planner_PlannerDAO; });

// EXTERNAL MODULE: ./server/database/knex.ts
var knex = __webpack_require__("CaIY");

// EXTERNAL MODULE: ./server/dataAccess/tutorialSection/index.ts
var tutorialSection = __webpack_require__("2v0O");

// EXTERNAL MODULE: ./server/dataAccess/tutorialProgress/index.ts
var tutorialProgress = __webpack_require__("QYdn");

// CONCATENATED MODULE: ./server/dataAccess/planner/index.ts



class planner_PlannerDAO {
  /** Creates the planner entry for the user */
  static async createPlanner(userId) {
    const planner = await Object(knex["a" /* Knex */])('planner').insert({
      userId: userId
    }).returning('*');
    return planner.shift();
  }

  /** Retrieve all tutorials belonging to this user */
  static async retrieveTutorials(userId) {
    const tutorialsInPlanner = await knex["a" /* Knex */].raw(`
        SELECT 
        -- top level fields
        t."title", 
        t."description2", 
        t."featuredImage", 
        t."slug", 
        COUNT(ts."tutorialId") as "totalSectionCount",

        (
            SELECT COUNT(tsp."sectionId") 
            FROM tutorial_sections_progress tsp 
            WHERE tsp."sectionId" in 
            (
                SELECT "id"
                FROM tutorial_sections ts
                WHERE 
                    ts."tutorialId" = t."id"
                    AND 
                    tsp."isComplete" = true
                    AND
                    "userId" = ${userId}
            )
        ) AS "completedSectionCount"

        -- get the tutorial ids belonging to the user's planner
        FROM tutorials t
        INNER JOIN tutorial_sections ts
        ON t."id" = ts."tutorialId"
        WHERE t."id" IN 
        (
            SELECT "tutorialId" 
            FROM planner_detail
            WHERE planner_detail."plannerId" = 
            (
                SELECT "id"
                FROM planner p
                WHERE p."userId" = ${userId}
            )
        )

        GROUP BY
            t."title", 
            t."description2", 
            t."featuredImage", 
            t."slug", 
            "completedSectionCount"     
    `);
    return tutorialsInPlanner.rows;
  }

  /** Get the id of the planner belonging to the user */
  static async getPlannerId(userId) {
    const plannerIdRes = await Object(knex["a" /* Knex */])('planner').select('id').from('planner').where('userId', userId);
    const {
      id
    } = plannerIdRes.shift();
    return id;
  }

  /** Register this tutorial into the user's planner */
  static async registerTutorial(tutorialId, plannerId, userId) {
    const registeredTutorial = await Object(knex["a" /* Knex */])('planner_detail').insert({
      plannerId: plannerId,
      tutorialId: tutorialId
    }).returning('*');
    return registeredTutorial.shift();
  }

  /** Unregisters this tutorial from a user's planner */
  static async unregisterTutorial(tutorialId, plannerId, userId) {
    // Remove this tutorial from the planner
    await Object(knex["a" /* Knex */])('planner_detail').where({
      tutorialId,
      plannerId
    }).delete(); // Unregister all of its sections from  the tutorial section progress table

    const sectionIds = await tutorialSection["a" /* TutorialSectionDAO */].listTutorialSectionIds(tutorialId);
    const unregistrations = sectionIds.map(sectionId => tutorialProgress["a" /* TutorialProgressDAO */].unregisterSection(sectionId, userId));
    await Promise.all(unregistrations);
  }

  /** Check if the tutorial (by id) is already registered in the planner */
  static async isTutorialRegistered(tutorialId, plannerId) {
    const isTutorialAlreadyRegisteredRes = await Object(knex["a" /* Knex */])('planner_detail').select('*').where('tutorialId', tutorialId).andWhere('plannerId', plannerId);
    const isTutorialAlreadyRegistered = isTutorialAlreadyRegisteredRes.length > 0 ? true : false;
    return isTutorialAlreadyRegistered;
  }

  /** Returns the number of planners that have registered this tutorial */
  static async getRegisteredCount(tutorialId) {
    const totalRegisteredCountRes = await Object(knex["a" /* Knex */])('planner_detail').count('plannerId').where('tutorialId', tutorialId);
    const count = parseInt(totalRegisteredCountRes.shift().count.toString());
    return count;
  }

}
;
// CONCATENATED MODULE: ./server/dataAccess/planner/entity.ts


/***/ }),

/***/ "CaIY":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(__dirname) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Knex; });
/* harmony import */ var knex__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("SfJF");
/* harmony import */ var knex__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(knex__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("ebvM");


const KnexConfiguration = {
  development: {
    client: 'pg',
    connection: {
      host: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbHost,
      user: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbUser,
      password: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbPassword,
      database: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbName,
      port: 5432
    },
    migrations: {
      directory: __dirname + '/db/pg/migrations'
    },
    seeds: {
      directory: __dirname + '/db/pg/seeds/development'
    }
  },
  production: {
    client: 'pg',
    connection: {
      host: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbHost,
      user: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbUser,
      password: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbPassword,
      database: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbName,
      ssl: true
    },
    migrations: {
      directory: __dirname + '/db/pg/migrations'
    },
    seeds: {
      directory: __dirname + '/db/pg/seeds/production'
    }
  }
};
const Knex = knex__WEBPACK_IMPORTED_MODULE_0___default()(KnexConfiguration[_utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].environment]);
/* WEBPACK VAR INJECTION */}.call(this, "/"))

/***/ }),

/***/ "QYdn":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return TutorialProgressDAO; });
/* harmony import */ var _database_knex__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("CaIY");
/* harmony import */ var _dataAccess_planner_entity__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("64Oa");


class TutorialProgressDAO {
  /** Registers the section this tutorial belongs to the user's Planner 
    * and marks this particular section as complete */
  static async setSectionComplete(userId, sectionId) {
    // Get the id of the tutorial this section belongs to
    const tutorialIdRes = await Object(_database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"])('tutorial_sections').select('tutorialId').where({
      id: sectionId
    });
    const {
      tutorialId
    } = tutorialIdRes.shift(); // Check if the tutorial is already in the user's planner

    const plannerId = await _dataAccess_planner_entity__WEBPACK_IMPORTED_MODULE_1__[/* PlannerDB */ "a"].getPlannerId(userId);
    const isTutorialRegistered = await _dataAccess_planner_entity__WEBPACK_IMPORTED_MODULE_1__[/* PlannerDB */ "a"].isTutorialRegistered(tutorialId, plannerId); // If the tutorial is not registered, register it

    if (isTutorialRegistered === false) {
      await _dataAccess_planner_entity__WEBPACK_IMPORTED_MODULE_1__[/* PlannerDB */ "a"].registerTutorial(tutorialId, plannerId, userId);
    } // Mark the section as complete


    const sectionProgress = await _database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"].raw(`
      INSERT INTO tutorial_sections_progress
          ("sectionId", "userId", "isComplete")
          VALUES (${sectionId}, ${userId}, true)

          ON CONFLICT ("sectionId", "userId") 
          DO UPDATE
              SET 
              "isComplete" = true
              WHERE EXCLUDED."sectionId" = ${sectionId} AND EXCLUDED."userId" = ${userId}

          RETURNING "isComplete", "sectionId"
    `);
    return sectionProgress.rows.shift();
  }

  /** Marks this particular section as incomplete */
  static async setSectionIncomplete(sectionId, userId) {
    const sectionProgress = await _database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"].raw(`
      INSERT INTO tutorial_sections_progress
      ("sectionId", "userId", "isComplete")
      VALUES (${sectionId}, ${userId}, false)

      ON CONFLICT ("sectionId", "userId") 
      DO UPDATE
          SET 
          "isComplete" = false
          WHERE EXCLUDED."sectionId" = ${sectionId} AND EXCLUDED."userId" = ${userId}

      RETURNING "isComplete", "sectionId"
      `);
    return sectionProgress;
  }

  /** Unregisters section from progress tracking */
  static async unregisterSection(sectionId, userId) {
    await Object(_database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"])('tutorial_sections_progress').where({
      sectionId,
      userId
    }).delete();
  }

  /** Retrieves the progress of these section ids */
  static async retrieveSectionProgress(sectionIds, userId) {
    const sectionsProgressRes = await Object(_database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"])('tutorial_sections_progress').select('sectionId', 'userId', 'isComplete').whereIn('sectionId', sectionIds).andWhere({
      userId
    });
    return sectionsProgressRes;
  }

}
;

/***/ }),

/***/ "QnN6":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, "a", function() { return /* reexport */ user_UserDAO; });

// EXTERNAL MODULE: ./server/database/knex.ts
var knex = __webpack_require__("CaIY");

// CONCATENATED MODULE: ./server/dataAccess/user/index.ts

class user_UserDAO {
  static async findUser(prop, val) {
    const users = await knex["a" /* Knex */].select('*').from('user_information').where(prop, val);
    return users.shift();
  }

  static async registerUser(userData, providerId) {
    const results = await Object(knex["a" /* Knex */])('user_information').insert({
      name: userData.name,
      uid: userData.uid,
      profileImage: userData.profileImageUrl,
      auth_provider: providerId
    }).returning('*');
    const addedUser = results.shift(); // Add their account information

    await Object(knex["a" /* Knex */])('user_account_information').insert({
      email: userData.email,
      username: userData.username,
      userId: addedUser.id
    });
    return addedUser;
  }

  static async getUserInformation(userId) {
    const users = await Object(knex["a" /* Knex */])('user_information').join('user_account_information', {
      'user_information.id': 'user_account_information.userId'
    }).select('heading', 'about', 'name', 'website', 'profileImage', 'username').where('user_information.id', userId);
    return users.shift();
  }

  static async updateUserInformation(userData) {
    const users = await knex["a" /* Knex */].where({
      id: userData.id
    }).update({
      heading: userData.heading,
      name: userData.name,
      about: userData.about,
      website: userData.website,
      profileImage: userData.profileImage
    }).returning('*');
    return users.shift();
  }

}
;
// CONCATENATED MODULE: ./server/dataAccess/user/entity.ts


/***/ }),

/***/ "SfJF":
/***/ (function(module, exports) {

module.exports = require("knex");

/***/ }),

/***/ "aWGM":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: external "@octokit/rest"
var rest_ = __webpack_require__("+jo5");

// EXTERNAL MODULE: ./server/dataAccess/user/entity.ts + 1 modules
var entity = __webpack_require__("QnN6");

// EXTERNAL MODULE: ./server/dataAccess/planner/entity.ts + 1 modules
var planner_entity = __webpack_require__("64Oa");

// CONCATENATED MODULE: ./server/services/userService.ts


class userService_UserService {
  /** Registers a user using the provided information for the designated provider */
  static async signUp(suInfo, provider) {
    // Try to look up the user prior to sign-up -- to prevent double sign-ups
    const user = await entity["a" /* UserDB */].findUser('uid', suInfo.uid); // We've located the user - so no need to sign them up

    if (user) {
      return {
        userId: user.id,
        profileImageUrl: suInfo.profileImageUrl
      };
    } // Otherwise, let's sign them up
    else {
        // Get the auth provider id and userId after insertion
        const providerId = this.getIdForProvider(provider);
        const user = await entity["a" /* UserDB */].registerUser(suInfo, providerId); // Creating their planner is part of the sign up process

        await planner_entity["a" /* PlannerDB */].createPlanner(user.id);
        return {
          userId: user.id,
          profileImageUrl: suInfo.profileImageUrl
        };
      }
  }

  static getIdForProvider(provider) {
    if (provider === 'GITHUB') return 1;
    if (provider === 'TWITTER') return 2;
  }

}
;
// EXTERNAL MODULE: ./server/api/services/authenticationService.ts + 1 modules
var authenticationService = __webpack_require__("jThR");

// CONCATENATED MODULE: ./src/pages/api/githubLogin.ts



const octokit = new rest_["Octokit"]();
const githubAuthUrl = 'https://github.com/login/oauth/access_token';
/* harmony default export */ var githubLogin = __webpack_exports__["default"] = (async (request, response) => {
  if (request.method.toLowerCase() === 'get') {
    return githubLogin_GitHubService.handleLogin(request, response);
  }
});

class githubLogin_GitHubService {
  /** Handles a sign up action with GitHub */
  static async handleLogin(request, response) {
    const {
      data
    } = await octokit.request(`POST ${githubAuthUrl}`, {
      headers: {
        accept: 'application/json'
      },
      data: {
        client_id: "4641cd510f9afeaca3b3",
        client_secret: process.env.GITHUB_CLIENT_SECRET,
        code: request.query.code
      }
    }); // If we have data in the response 
    // we can retrieve further user information

    if (data) {
      const userInformation = await this.retrieveUserInformation(data); // Attempt to sign them up

      const {
        userId,
        profileImageUrl
      } = await userService_UserService.signUp(userInformation, "GITHUB");
      await authenticationService["a" /* AuthenticationService */].signIn(data.access_token, userId, profileImageUrl, response);
      response.writeHead(302, {
        Location: '/'
      });
      response.end();
    }
  }

  /** Uses the provided authentication object to retrieve information for the user
   * to build the sign up data object */
  static async retrieveUserInformation(authentication) {
    const headers = {
      Authorization: `token ${authentication.access_token}`
    }; // Check if we have access to user information

    if (authentication.scope.includes('read:user')) {
      const {
        data
      } = await octokit.users.getAuthenticated({
        headers
      }); // Build the information object

      const signUpInformation = {
        email: data.email,
        username: data.login,
        profileImageUrl: data.avatar_url,
        name: data.name,
        uid: data.id
      }; // Get primary email if possible

      if (authentication.scope.includes('user:email')) {
        const {
          data
        } = await octokit.users.listEmails({
          headers
        }); // Replace the original email

        const {
          email
        } = data.find(p => p.primary == true);
        signUpInformation.email = email;
      }

      return signUpInformation;
    }
  }

}

/***/ }),

/***/ "ebvM":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
const Config = {
  dbHost: process.env.DB_HOST,
  dbUser: process.env.DB_USER,
  dbPassword: process.env.DB_PASSWORD,
  dbName: process.env.DB_NAME,
  zerochassSecret: process.env.ZEROCHASS_SECRET,
  awsRegion: process.env.AWS_REGION,
  awsBucket: process.env.AWS_BUCKET,
  port: process.env.PORT,
  environment: ("production" || false).toLowerCase()
};
/* harmony default export */ __webpack_exports__["a"] = (Config);

/***/ }),

/***/ "jThR":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, "a", function() { return /* binding */ AuthenticationService; });

// EXTERNAL MODULE: external "jsonwebtoken"
var external_jsonwebtoken_ = __webpack_require__("tMJi");
var external_jsonwebtoken_default = /*#__PURE__*/__webpack_require__.n(external_jsonwebtoken_);

// EXTERNAL MODULE: ./server/utils/config.ts
var config = __webpack_require__("ebvM");

// CONCATENATED MODULE: ./server/utils/authConfig.ts
/** Authentication configuration for the application */
const AuthConfig = {
  /** Name for the server cookie */
  zerochassServerCookie: 'zerochassServerCookie',

  /** Name for the client cookie */
  zerochassClientCookie: 'zerochassClientCookie',

  /** Expiration time authentication token should expire at after issuing */
  tokenExpiration: '30d',

  /** Expiration time authentication cookie should expire at after issuing */
  cookieExpiration: 30 * 86400 * 1000 // 30 days

};
/* harmony default export */ var authConfig = (AuthConfig);
// EXTERNAL MODULE: external "nookies"
var external_nookies_ = __webpack_require__("kG9d");
var external_nookies_default = /*#__PURE__*/__webpack_require__.n(external_nookies_);

// CONCATENATED MODULE: ./server/api/services/authenticationService.ts




const {
  zerochassClientCookie,
  zerochassServerCookie
} = authConfig;
/** Signs a user in */

const signIn = async (accessToken, userId, profileImageUrl, res) => {
  const jwt = generateJwt(accessToken, userId);
  const expires = new Date(Date.now() + authConfig.cookieExpiration); // Create cookies

  external_nookies_default.a.set({
    res
  }, zerochassServerCookie, jwt, {
    httpOnly: true,
    expires,
    path: "/"
  });
  external_nookies_default.a.set({
    res
  }, zerochassClientCookie, JSON.stringify({
    authenticated: true,
    profileImageUrl,
    expires: expires.getTime()
  }), {
    httpOnly: false,
    expires,
    path: "/"
  });
};
/** Logs a user out */


const logOut = (req, res) => {
  external_nookies_default.a.destroy({
    res
  }, zerochassServerCookie, {
    path: "/"
  });
  external_nookies_default.a.destroy({
    res
  }, zerochassClientCookie, {
    path: "/"
  });
  return res;
};
/** Returns generated jwt using the provided access token */


const generateJwt = (accessToken, userId) => {
  // Create jwt token with expiration
  const token = external_jsonwebtoken_default.a.sign({
    accessToken,
    userId
  }, config["a" /* default */].zerochassSecret, {
    expiresIn: authConfig.tokenExpiration
  });
  return token;
};

const AuthenticationService = {
  signIn,
  logOut
};

/***/ }),

/***/ "kG9d":
/***/ (function(module, exports) {

module.exports = require("nookies");

/***/ }),

/***/ "tMJi":
/***/ (function(module, exports) {

module.exports = require("jsonwebtoken");

/***/ })

/******/ });