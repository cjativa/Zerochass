module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 3);
/******/ })
/************************************************************************/
/******/ ({

/***/ 3:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("fnQt");


/***/ }),

/***/ "4hjK":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return S3; });
/* harmony import */ var aws_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("DaQf");
/* harmony import */ var aws_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(aws_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("ebvM");
function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


 // Set the region 

aws_sdk__WEBPACK_IMPORTED_MODULE_0___default.a.config.update({
  region: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].awsRegion
});
class S3 {
  /** Uploads a file to the specified bucket */
  static async upload(uploadParams) {
    const response = await this.s3.upload(uploadParams).promise();
    return response;
  }

}

_defineProperty(S3, "s3", new aws_sdk__WEBPACK_IMPORTED_MODULE_0___default.a.S3({
  apiVersion: '2006-03-01'
}));

/***/ }),

/***/ "7+yl":
/***/ (function(module, exports) {

// This alphabet uses `A-Za-z0-9_-` symbols. The genetic algorithm helped
// optimize the gzip compression for this alphabet.
let urlAlphabet =
  'ModuleSymbhasOwnPr-0123456789ABCDEFGHNRVfgctiUvz_KqYTJkLxpZXIjQW'

module.exports = { urlAlphabet }


/***/ }),

/***/ "DaQf":
/***/ (function(module, exports) {

module.exports = require("aws-sdk");

/***/ }),

/***/ "PJMN":
/***/ (function(module, exports) {

module.exports = require("crypto");

/***/ }),

/***/ "ebvM":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
const Config = {
  dbHost: process.env.DB_HOST,
  dbUser: process.env.DB_USER,
  dbPassword: process.env.DB_PASSWORD,
  dbName: process.env.DB_NAME,
  zerochassSecret: process.env.ZEROCHASS_SECRET,
  awsRegion: process.env.AWS_REGION,
  awsBucket: process.env.AWS_BUCKET,
  port: process.env.PORT,
  environment: ("production" || false).toLowerCase()
};
/* harmony default export */ __webpack_exports__["a"] = (Config);

/***/ }),

/***/ "fnQt":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var nanoid__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("k4gg");
/* harmony import */ var nanoid__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(nanoid__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _server_utils_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("ebvM");
/* harmony import */ var _server_services_awsService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("4hjK");
/* harmony import */ var _server_api_middleware_protectWithAuthentcation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("i5SM");





const handler = async (request, response) => {
  const method = request.method.toLowerCase();

  if (method === 'post') {
    return AssetUploadService.uploadAsset(request, response);
  }
};

class AssetUploadService {
  static async uploadAsset(request, response) {
    const {
      dataUrl
    } = request.body;
    const uploadableBase64 = Buffer.from(dataUrl.replace(/^data:image\/\w+;base64,/, ""), 'base64'); // Get the url for the uploaded image and store it in the tutorial

    const uploadResponse = await _server_services_awsService__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"].upload({
      Bucket: `${_server_utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].awsBucket}/images`,
      Key: `${Object(nanoid__WEBPACK_IMPORTED_MODULE_0__["nanoid"])()}.png`,
      Body: uploadableBase64,
      ACL: 'public-read',
      ContentEncoding: 'base64',
      ContentType: 'image/png'
    });
    return response.status(200).json(uploadResponse.Location);
  }

}

;
/* harmony default export */ __webpack_exports__["default"] = (Object(_server_api_middleware_protectWithAuthentcation__WEBPACK_IMPORTED_MODULE_3__["default"])(handler));

/***/ }),

/***/ "i5SM":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, "isAuthenticated", function() { return /* binding */ isAuthenticated; });

// EXTERNAL MODULE: external "jsonwebtoken"
var external_jsonwebtoken_ = __webpack_require__("tMJi");
var external_jsonwebtoken_default = /*#__PURE__*/__webpack_require__.n(external_jsonwebtoken_);

// CONCATENATED MODULE: ./util/config.ts
const Config = {
  dbHost: process.env.DB_HOST,
  dbUser: process.env.DB_USER,
  dbPassword: process.env.DB_PASSWORD,
  dbName: process.env.DB_NAME,
  zerochassSecret: process.env.ZEROCHASS_SECRET,
  awsRegion: process.env.AWS_REGION,
  awsBucket: process.env.AWS_BUCKET
};
// EXTERNAL MODULE: external "nookies"
var external_nookies_ = __webpack_require__("kG9d");
var external_nookies_default = /*#__PURE__*/__webpack_require__.n(external_nookies_);

// CONCATENATED MODULE: ./server/api/middleware/protectWithAuthentcation.ts



;
/** Returns boolean on user being authenticated */

const isAuthenticated = (req, res) => {
  const authentication = {
    authenticated: null,
    userId: null,
    accessToken: null
  }; // Check if there's a zerochassServerCookie on the request -- if it does exist, the jwt will be available

  const {
    zerochassServerCookie,
    zerochassClientCookie
  } = external_nookies_default.a.get({
    req
  }); // If there's no jwt, update the authentication object

  if (!zerochassServerCookie) {
    authentication['authenticated'] = false;
  } // Else there's a jwt, let's see if it's valid
  else {
      const userPayload = external_jsonwebtoken_default.a.verify(zerochassServerCookie, Config.zerochassSecret); // If the token is invalid (i.e. no payload), clear the cookie and update authentication object

      if (!userPayload) {
        external_nookies_default.a.destroy(null, zerochassServerCookie);
        external_nookies_default.a.destroy(null, zerochassClientCookie);
        authentication['authenticated'] = false;
      } // Else, token is valid - let's set the userId on the request object
      else {
          authentication['userId'] = userPayload['userId'];
          authentication['accessToken'] = userPayload['accessToken'];
          authentication['authenticated'] = true;
        }
    }

  return authentication;
};
/** Middleware that secures protected routes with authentication */

const handleAccess = (request, response) => {
  const {
    userId,
    authenticated,
    accessToken
  } = isAuthenticated(request, response);

  if (authenticated) {
    request['authenticated'] = true;
    request['userId'] = userId;
    request['accessToken'] = accessToken;
  } else {
    response.status(401).json(`Invalid or missing authorization token`);
  }

  return authenticated;
};
/** Protects secured API routes against non-authenticated sessions.
 * Also adds userId and access token to request object for authenticated sessions */


const protectWithAuthentication = handler => (request, response) => {
  // Determine if the session is authenticated
  const isAuthenticated = handleAccess(request, response); // If the session was authenticated, allows the requested endpoint to handle responding

  if (isAuthenticated) return handler(request, response);
};

/* harmony default export */ var protectWithAuthentcation = __webpack_exports__["default"] = (protectWithAuthentication);

/***/ }),

/***/ "k4gg":
/***/ (function(module, exports, __webpack_require__) {

let crypto = __webpack_require__("PJMN")

let { urlAlphabet } = __webpack_require__("7+yl")

// It is best to make fewer, larger requests to the crypto module to
// avoid system call overhead. So, random numbers are generated in a
// pool. The pool is a Buffer that is larger than the initial random
// request size by this multiplier. The pool is enlarged if subsequent
// requests exceed the maximum buffer size.
const POOL_SIZE_MULTIPLIER = 32
let pool, poolOffset

let random = bytes => {
  if (!pool || pool.length < bytes) {
    pool = Buffer.allocUnsafe(bytes * POOL_SIZE_MULTIPLIER)
    crypto.randomFillSync(pool)
    poolOffset = 0
  } else if (poolOffset + bytes > pool.length) {
    crypto.randomFillSync(pool)
    poolOffset = 0
  }

  let res = pool.subarray(poolOffset, poolOffset + bytes)
  poolOffset += bytes
  return res
}

let customRandom = (alphabet, size, getRandom) => {
  // First, a bitmask is necessary to generate the ID. The bitmask makes bytes
  // values closer to the alphabet size. The bitmask calculates the closest
  // `2^31 - 1` number, which exceeds the alphabet size.
  // For example, the bitmask for the alphabet size 30 is 31 (00011111).
  let mask = (2 << (31 - Math.clz32((alphabet.length - 1) | 1))) - 1
  // Though, the bitmask solution is not perfect since the bytes exceeding
  // the alphabet size are refused. Therefore, to reliably generate the ID,
  // the random bytes redundancy has to be satisfied.

  // Note: every hardware random generator call is performance expensive,
  // because the system call for entropy collection takes a lot of time.
  // So, to avoid additional system calls, extra bytes are requested in advance.

  // Next, a step determines how many random bytes to generate.
  // The number of random bytes gets decided upon the ID size, mask,
  // alphabet size, and magic number 1.6 (using 1.6 peaks at performance
  // according to benchmarks).
  let step = Math.ceil((1.6 * mask * size) / alphabet.length)

  return () => {
    let id = ''
    while (true) {
      let bytes = getRandom(step)
      // A compact alternative for `for (let i = 0; i < step; i++)`.
      let i = step
      while (i--) {
        // Adding `|| ''` refuses a random byte that exceeds the alphabet size.
        id += alphabet[bytes[i] & mask] || ''
        if (id.length === size) return id
      }
    }
  }
}

let customAlphabet = (alphabet, size) => customRandom(alphabet, size, random)

let nanoid = (size = 21) => {
  let bytes = random(size)
  let id = ''
  // A compact alternative for `for (let i = 0; i < size; i++)`.
  while (size--) {
    // It is incorrect to use bytes exceeding the alphabet size.
    // The following mask reduces the random byte in the 0-255 value
    // range to the 0-63 value range. Therefore, adding hacks, such
    // as empty string fallback or magic numbers, is unneccessary because
    // the bitmask trims bytes down to the alphabet size.
    id += urlAlphabet[bytes[size] & 63]
  }
  return id
}

module.exports = { nanoid, customAlphabet, customRandom, urlAlphabet, random }


/***/ }),

/***/ "kG9d":
/***/ (function(module, exports) {

module.exports = require("nookies");

/***/ }),

/***/ "tMJi":
/***/ (function(module, exports) {

module.exports = require("jsonwebtoken");

/***/ })

/******/ });