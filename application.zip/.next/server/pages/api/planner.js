module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 6);
/******/ })
/************************************************************************/
/******/ ({

/***/ "/7EB":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _server_api_middleware_protectWithAuthentcation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("i5SM");
// import { TutorialProgressManager } from '../../../util/database/classes/tutorialProgressManager';


const handler = async (request, response) => {};

/* harmony default export */ __webpack_exports__["default"] = (Object(_server_api_middleware_protectWithAuthentcation__WEBPACK_IMPORTED_MODULE_0__["default"])(handler));

/***/ }),

/***/ 6:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("/7EB");


/***/ }),

/***/ "i5SM":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, "isAuthenticated", function() { return /* binding */ isAuthenticated; });

// EXTERNAL MODULE: external "jsonwebtoken"
var external_jsonwebtoken_ = __webpack_require__("tMJi");
var external_jsonwebtoken_default = /*#__PURE__*/__webpack_require__.n(external_jsonwebtoken_);

// CONCATENATED MODULE: ./util/config.ts
const Config = {
  dbHost: process.env.DB_HOST,
  dbUser: process.env.DB_USER,
  dbPassword: process.env.DB_PASSWORD,
  dbName: process.env.DB_NAME,
  zerochassSecret: process.env.ZEROCHASS_SECRET,
  awsRegion: process.env.AWS_REGION,
  awsBucket: process.env.AWS_BUCKET
};
// EXTERNAL MODULE: external "nookies"
var external_nookies_ = __webpack_require__("kG9d");
var external_nookies_default = /*#__PURE__*/__webpack_require__.n(external_nookies_);

// CONCATENATED MODULE: ./server/api/middleware/protectWithAuthentcation.ts



;
/** Returns boolean on user being authenticated */

const isAuthenticated = (req, res) => {
  const authentication = {
    authenticated: null,
    userId: null,
    accessToken: null
  }; // Check if there's a zerochassServerCookie on the request -- if it does exist, the jwt will be available

  const {
    zerochassServerCookie,
    zerochassClientCookie
  } = external_nookies_default.a.get({
    req
  }); // If there's no jwt, update the authentication object

  if (!zerochassServerCookie) {
    authentication['authenticated'] = false;
  } // Else there's a jwt, let's see if it's valid
  else {
      const userPayload = external_jsonwebtoken_default.a.verify(zerochassServerCookie, Config.zerochassSecret); // If the token is invalid (i.e. no payload), clear the cookie and update authentication object

      if (!userPayload) {
        external_nookies_default.a.destroy(null, zerochassServerCookie);
        external_nookies_default.a.destroy(null, zerochassClientCookie);
        authentication['authenticated'] = false;
      } // Else, token is valid - let's set the userId on the request object
      else {
          authentication['userId'] = userPayload['userId'];
          authentication['accessToken'] = userPayload['accessToken'];
          authentication['authenticated'] = true;
        }
    }

  return authentication;
};
/** Middleware that secures protected routes with authentication */

const handleAccess = (request, response) => {
  const {
    userId,
    authenticated,
    accessToken
  } = isAuthenticated(request, response);

  if (authenticated) {
    request['authenticated'] = true;
    request['userId'] = userId;
    request['accessToken'] = accessToken;
  } else {
    response.status(401).json(`Invalid or missing authorization token`);
  }

  return authenticated;
};
/** Protects secured API routes against non-authenticated sessions.
 * Also adds userId and access token to request object for authenticated sessions */


const protectWithAuthentication = handler => (request, response) => {
  // Determine if the session is authenticated
  const isAuthenticated = handleAccess(request, response); // If the session was authenticated, allows the requested endpoint to handle responding

  if (isAuthenticated) return handler(request, response);
};

/* harmony default export */ var protectWithAuthentcation = __webpack_exports__["default"] = (protectWithAuthentication);

/***/ }),

/***/ "kG9d":
/***/ (function(module, exports) {

module.exports = require("nookies");

/***/ }),

/***/ "tMJi":
/***/ (function(module, exports) {

module.exports = require("jsonwebtoken");

/***/ })

/******/ });