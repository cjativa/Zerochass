module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 7);
/******/ })
/************************************************************************/
/******/ ({

/***/ "2v0O":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return TutorialSectionDAO; });
/* harmony import */ var _database_knex__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("CaIY");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


class TutorialSectionDAO {
  static async getSeparateSections(tutorialSections, tutorialId) {
    const sectionsToAdd = [];
    const sectionsToUpdate = [];
    const sectionsToDelete = []; // Compare the incoming tutorial sections with what's on file for this tutorial

    const existingSectionIds = await TutorialSectionDAO.listTutorialSectionIds(tutorialId);
    const providedSectionIds = tutorialSections.filter(section => section.hasOwnProperty('id')).map(section => section.id); // The section id's to delete are the ones that exist in the database
    // but are no longer being provided in the request - i.e. these need to be removed

    const sectionIdsToDelete = existingSectionIds.filter(existingSectionId => !providedSectionIds.includes(parseInt(existingSectionId.toString())));
    sectionsToDelete.push(...sectionIdsToDelete);
    tutorialSections.forEach(tutorialSection => {
      // If there's an id then the section needs to be updated
      if (tutorialSection.hasOwnProperty('id')) {
        sectionsToUpdate.push(tutorialSection);
      } // Otherwise, no id means it needs to be added
      else {
          sectionsToAdd.push(tutorialSection);
        }
    });
    return {
      sectionsToAdd,
      sectionsToUpdate,
      sectionsToDelete
    };
  }

  /** something */
  static async listTutorialSections(tutorialId) {
    return await _database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"].select('*').from('tutorial_sections').where('tutorialId', tutorialId).orderBy('id', 'asc');
  }

  static async addOrUpdateTutorialSection(tutorialSections, tutorialId) {
    const {
      sectionsToAdd,
      sectionsToUpdate,
      sectionsToDelete
    } = await TutorialSectionDAO.getSeparateSections(tutorialSections, tutorialId);
    let addedSections = [];
    let updatedSections = [];
    const sectionsWithId = sectionsToAdd.map(section => {
      return _objectSpread(_objectSpread({}, section), {}, {
        tutorialId
      });
    });

    if (sectionsToAdd.length > 0) {
      const addedSections = await Object(_database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"])('tutorial_sections').insert(sectionsWithId).returning('*');
      addedSections.push(...addedSections);
    }

    if (sectionsToUpdate.length > 0) {
      for (let i = 0; i < sectionsToUpdate.length; i++) {
        const section = sectionsToUpdate[i];
        const updatedSection = await Object(_database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"])('tutorial_sections').update(section).where({
          'id': section.id,
          'tutorialId': tutorialId
        }).returning('*');
        updatedSections.push(...updatedSection);
      }
    }

    if (sectionsToDelete.length > 0) {
      await TutorialSectionDAO.deleteSections(tutorialId, sectionsToDelete);
    }

    return [...addedSections, ...updatedSections];
  }

  static async deleteTutorialSection(id) {
    const response = await Object(_database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"])('tutorial_sections').where('id', id).del();

    if (response == 1) {
      return true;
    }

    return false;
  }

  static async listTutorialSectionIds(tutorialId) {
    const sectionIdsRes = await _database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"].select('id').from('tutorial_sections').where('tutorialId', tutorialId);
    const sectionIds = sectionIdsRes.map(el => el.id);
    return sectionIds;
  }

  static async deleteSections(tutorialId, sectionIds) {
    // Delete these sections from the tutorial progress table
    await Object(_database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"])('tutorial_sections_progress').delete().whereIn('sectionId', sectionIds); // Delete the tutorial sections

    await Object(_database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"])('tutorial_sections').delete().whereIn('id', sectionIds).andWhere({
      tutorialId
    });
  }

}
;
/**
 *
 *
 *
  /** Adds or updates the sections for a tutorial */

/*
public static async addSections(tutorialId: number, tutorialSections: TutorialInterface['sections']) {

  const sectionRequests = tutorialSections.map((section) => {
      let query, values;
      const { title, content, id } = section;

      // If the section has an id, then it needs to be updated
      if (id) {
          query = `
          UPDATE tutorial_sections
          SET
              "title" = ($1),
              "content" = ($2)
          WHERE "id" = ($3) AND "tutorialId" = ($4)
          `;
          values = [title, content, id, tutorialId];
      }

      // Otherwise, no existing id means it's an insert
      else {
          query = `
          INSERT INTO tutorial_sections ("title", "content", "tutorialId")
          VALUES ($1, $2, $3)
          `;
          values = [title, content, tutorialId];
      }

      return Client.executeQuery(query, values);
  });

  await Promise.all(sectionRequests);
};

/** Deletes any sections that from the tutorial that exist in the database but were not sent along with an update */

/*
 */

/***/ }),

/***/ "64Oa":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, "a", function() { return /* reexport */ planner_PlannerDAO; });

// EXTERNAL MODULE: ./server/database/knex.ts
var knex = __webpack_require__("CaIY");

// EXTERNAL MODULE: ./server/dataAccess/tutorialSection/index.ts
var tutorialSection = __webpack_require__("2v0O");

// EXTERNAL MODULE: ./server/dataAccess/tutorialProgress/index.ts
var tutorialProgress = __webpack_require__("QYdn");

// CONCATENATED MODULE: ./server/dataAccess/planner/index.ts



class planner_PlannerDAO {
  /** Creates the planner entry for the user */
  static async createPlanner(userId) {
    const planner = await Object(knex["a" /* Knex */])('planner').insert({
      userId: userId
    }).returning('*');
    return planner.shift();
  }

  /** Retrieve all tutorials belonging to this user */
  static async retrieveTutorials(userId) {
    const tutorialsInPlanner = await knex["a" /* Knex */].raw(`
        SELECT 
        -- top level fields
        t."title", 
        t."description2", 
        t."featuredImage", 
        t."slug", 
        COUNT(ts."tutorialId") as "totalSectionCount",

        (
            SELECT COUNT(tsp."sectionId") 
            FROM tutorial_sections_progress tsp 
            WHERE tsp."sectionId" in 
            (
                SELECT "id"
                FROM tutorial_sections ts
                WHERE 
                    ts."tutorialId" = t."id"
                    AND 
                    tsp."isComplete" = true
                    AND
                    "userId" = ${userId}
            )
        ) AS "completedSectionCount"

        -- get the tutorial ids belonging to the user's planner
        FROM tutorials t
        INNER JOIN tutorial_sections ts
        ON t."id" = ts."tutorialId"
        WHERE t."id" IN 
        (
            SELECT "tutorialId" 
            FROM planner_detail
            WHERE planner_detail."plannerId" = 
            (
                SELECT "id"
                FROM planner p
                WHERE p."userId" = ${userId}
            )
        )

        GROUP BY
            t."title", 
            t."description2", 
            t."featuredImage", 
            t."slug", 
            "completedSectionCount"     
    `);
    return tutorialsInPlanner.rows;
  }

  /** Get the id of the planner belonging to the user */
  static async getPlannerId(userId) {
    const plannerIdRes = await Object(knex["a" /* Knex */])('planner').select('id').from('planner').where('userId', userId);
    const {
      id
    } = plannerIdRes.shift();
    return id;
  }

  /** Register this tutorial into the user's planner */
  static async registerTutorial(tutorialId, plannerId, userId) {
    const registeredTutorial = await Object(knex["a" /* Knex */])('planner_detail').insert({
      plannerId: plannerId,
      tutorialId: tutorialId
    }).returning('*');
    return registeredTutorial.shift();
  }

  /** Unregisters this tutorial from a user's planner */
  static async unregisterTutorial(tutorialId, plannerId, userId) {
    // Remove this tutorial from the planner
    await Object(knex["a" /* Knex */])('planner_detail').where({
      tutorialId,
      plannerId
    }).delete(); // Unregister all of its sections from  the tutorial section progress table

    const sectionIds = await tutorialSection["a" /* TutorialSectionDAO */].listTutorialSectionIds(tutorialId);
    const unregistrations = sectionIds.map(sectionId => tutorialProgress["a" /* TutorialProgressDAO */].unregisterSection(sectionId, userId));
    await Promise.all(unregistrations);
  }

  /** Check if the tutorial (by id) is already registered in the planner */
  static async isTutorialRegistered(tutorialId, plannerId) {
    const isTutorialAlreadyRegisteredRes = await Object(knex["a" /* Knex */])('planner_detail').select('*').where('tutorialId', tutorialId).andWhere('plannerId', plannerId);
    const isTutorialAlreadyRegistered = isTutorialAlreadyRegisteredRes.length > 0 ? true : false;
    return isTutorialAlreadyRegistered;
  }

  /** Returns the number of planners that have registered this tutorial */
  static async getRegisteredCount(tutorialId) {
    const totalRegisteredCountRes = await Object(knex["a" /* Knex */])('planner_detail').count('plannerId').where('tutorialId', tutorialId);
    const count = parseInt(totalRegisteredCountRes.shift().count.toString());
    return count;
  }

}
;
// CONCATENATED MODULE: ./server/dataAccess/planner/entity.ts


/***/ }),

/***/ 7:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("yYWL");


/***/ }),

/***/ "7qpo":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("QYdn");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _index__WEBPACK_IMPORTED_MODULE_0__["a"]; });



/***/ }),

/***/ "CaIY":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(__dirname) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Knex; });
/* harmony import */ var knex__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("SfJF");
/* harmony import */ var knex__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(knex__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("ebvM");


const KnexConfiguration = {
  development: {
    client: 'pg',
    connection: {
      host: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbHost,
      user: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbUser,
      password: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbPassword,
      database: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbName,
      port: 5432
    },
    migrations: {
      directory: __dirname + '/db/pg/migrations'
    },
    seeds: {
      directory: __dirname + '/db/pg/seeds/development'
    }
  },
  production: {
    client: 'pg',
    connection: {
      host: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbHost,
      user: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbUser,
      password: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbPassword,
      database: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbName,
      ssl: true
    },
    migrations: {
      directory: __dirname + '/db/pg/migrations'
    },
    seeds: {
      directory: __dirname + '/db/pg/seeds/production'
    }
  }
};
const Knex = knex__WEBPACK_IMPORTED_MODULE_0___default()(KnexConfiguration[_utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].environment]);
/* WEBPACK VAR INJECTION */}.call(this, "/"))

/***/ }),

/***/ "IzFH":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("2v0O");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _index__WEBPACK_IMPORTED_MODULE_0__["a"]; });



/***/ }),

/***/ "QYdn":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return TutorialProgressDAO; });
/* harmony import */ var _database_knex__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("CaIY");
/* harmony import */ var _dataAccess_planner_entity__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("64Oa");


class TutorialProgressDAO {
  /** Registers the section this tutorial belongs to the user's Planner 
    * and marks this particular section as complete */
  static async setSectionComplete(userId, sectionId) {
    // Get the id of the tutorial this section belongs to
    const tutorialIdRes = await Object(_database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"])('tutorial_sections').select('tutorialId').where({
      id: sectionId
    });
    const {
      tutorialId
    } = tutorialIdRes.shift(); // Check if the tutorial is already in the user's planner

    const plannerId = await _dataAccess_planner_entity__WEBPACK_IMPORTED_MODULE_1__[/* PlannerDB */ "a"].getPlannerId(userId);
    const isTutorialRegistered = await _dataAccess_planner_entity__WEBPACK_IMPORTED_MODULE_1__[/* PlannerDB */ "a"].isTutorialRegistered(tutorialId, plannerId); // If the tutorial is not registered, register it

    if (isTutorialRegistered === false) {
      await _dataAccess_planner_entity__WEBPACK_IMPORTED_MODULE_1__[/* PlannerDB */ "a"].registerTutorial(tutorialId, plannerId, userId);
    } // Mark the section as complete


    const sectionProgress = await _database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"].raw(`
      INSERT INTO tutorial_sections_progress
          ("sectionId", "userId", "isComplete")
          VALUES (${sectionId}, ${userId}, true)

          ON CONFLICT ("sectionId", "userId") 
          DO UPDATE
              SET 
              "isComplete" = true
              WHERE EXCLUDED."sectionId" = ${sectionId} AND EXCLUDED."userId" = ${userId}

          RETURNING "isComplete", "sectionId"
    `);
    return sectionProgress.rows.shift();
  }

  /** Marks this particular section as incomplete */
  static async setSectionIncomplete(sectionId, userId) {
    const sectionProgress = await _database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"].raw(`
      INSERT INTO tutorial_sections_progress
      ("sectionId", "userId", "isComplete")
      VALUES (${sectionId}, ${userId}, false)

      ON CONFLICT ("sectionId", "userId") 
      DO UPDATE
          SET 
          "isComplete" = false
          WHERE EXCLUDED."sectionId" = ${sectionId} AND EXCLUDED."userId" = ${userId}

      RETURNING "isComplete", "sectionId"
      `);
    return sectionProgress;
  }

  /** Unregisters section from progress tracking */
  static async unregisterSection(sectionId, userId) {
    await Object(_database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"])('tutorial_sections_progress').where({
      sectionId,
      userId
    }).delete();
  }

  /** Retrieves the progress of these section ids */
  static async retrieveSectionProgress(sectionIds, userId) {
    const sectionsProgressRes = await Object(_database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"])('tutorial_sections_progress').select('sectionId', 'userId', 'isComplete').whereIn('sectionId', sectionIds).andWhere({
      userId
    });
    return sectionsProgressRes;
  }

}
;

/***/ }),

/***/ "SfJF":
/***/ (function(module, exports) {

module.exports = require("knex");

/***/ }),

/***/ "ebvM":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
const Config = {
  dbHost: process.env.DB_HOST,
  dbUser: process.env.DB_USER,
  dbPassword: process.env.DB_PASSWORD,
  dbName: process.env.DB_NAME,
  zerochassSecret: process.env.ZEROCHASS_SECRET,
  awsRegion: process.env.AWS_REGION,
  awsBucket: process.env.AWS_BUCKET,
  port: process.env.PORT,
  environment: ("production" || false).toLowerCase()
};
/* harmony default export */ __webpack_exports__["a"] = (Config);

/***/ }),

/***/ "i5SM":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, "isAuthenticated", function() { return /* binding */ isAuthenticated; });

// EXTERNAL MODULE: external "jsonwebtoken"
var external_jsonwebtoken_ = __webpack_require__("tMJi");
var external_jsonwebtoken_default = /*#__PURE__*/__webpack_require__.n(external_jsonwebtoken_);

// CONCATENATED MODULE: ./util/config.ts
const Config = {
  dbHost: process.env.DB_HOST,
  dbUser: process.env.DB_USER,
  dbPassword: process.env.DB_PASSWORD,
  dbName: process.env.DB_NAME,
  zerochassSecret: process.env.ZEROCHASS_SECRET,
  awsRegion: process.env.AWS_REGION,
  awsBucket: process.env.AWS_BUCKET
};
// EXTERNAL MODULE: external "nookies"
var external_nookies_ = __webpack_require__("kG9d");
var external_nookies_default = /*#__PURE__*/__webpack_require__.n(external_nookies_);

// CONCATENATED MODULE: ./server/api/middleware/protectWithAuthentcation.ts



;
/** Returns boolean on user being authenticated */

const isAuthenticated = (req, res) => {
  const authentication = {
    authenticated: null,
    userId: null,
    accessToken: null
  }; // Check if there's a zerochassServerCookie on the request -- if it does exist, the jwt will be available

  const {
    zerochassServerCookie,
    zerochassClientCookie
  } = external_nookies_default.a.get({
    req
  }); // If there's no jwt, update the authentication object

  if (!zerochassServerCookie) {
    authentication['authenticated'] = false;
  } // Else there's a jwt, let's see if it's valid
  else {
      const userPayload = external_jsonwebtoken_default.a.verify(zerochassServerCookie, Config.zerochassSecret); // If the token is invalid (i.e. no payload), clear the cookie and update authentication object

      if (!userPayload) {
        external_nookies_default.a.destroy(null, zerochassServerCookie);
        external_nookies_default.a.destroy(null, zerochassClientCookie);
        authentication['authenticated'] = false;
      } // Else, token is valid - let's set the userId on the request object
      else {
          authentication['userId'] = userPayload['userId'];
          authentication['accessToken'] = userPayload['accessToken'];
          authentication['authenticated'] = true;
        }
    }

  return authentication;
};
/** Middleware that secures protected routes with authentication */

const handleAccess = (request, response) => {
  const {
    userId,
    authenticated,
    accessToken
  } = isAuthenticated(request, response);

  if (authenticated) {
    request['authenticated'] = true;
    request['userId'] = userId;
    request['accessToken'] = accessToken;
  } else {
    response.status(401).json(`Invalid or missing authorization token`);
  }

  return authenticated;
};
/** Protects secured API routes against non-authenticated sessions.
 * Also adds userId and access token to request object for authenticated sessions */


const protectWithAuthentication = handler => (request, response) => {
  // Determine if the session is authenticated
  const isAuthenticated = handleAccess(request, response); // If the session was authenticated, allows the requested endpoint to handle responding

  if (isAuthenticated) return handler(request, response);
};

/* harmony default export */ var protectWithAuthentcation = __webpack_exports__["default"] = (protectWithAuthentication);

/***/ }),

/***/ "kG9d":
/***/ (function(module, exports) {

module.exports = require("nookies");

/***/ }),

/***/ "tMJi":
/***/ (function(module, exports) {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ "yYWL":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _server_dataAccess_planner_entity__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("64Oa");
/* harmony import */ var _server_dataAccess_tutorialSection_entity__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("IzFH");
/* harmony import */ var _server_dataAccess_tutorialProgress_entity__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("7qpo");
/* harmony import */ var _server_api_middleware_protectWithAuthentcation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("i5SM");





const handler = async (request, response) => {
  if (request.method.toLowerCase() === 'get') {
    return EnrollmentService.retrieveTutorialEnrollment(request, response);
  }

  if (request.method.toLowerCase() === 'post') {
    return EnrollmentService.handleTutorialEnrollment(request, response);
  }
};

class EnrollmentService {
  /** Retrieves the enrollment status for the tutorial for the signed in user */
  static async retrieveTutorialEnrollment(request, response) {
    // Get the section id and whether the section should be complete for this user
    const {
      query: {
        tutorialId: id
      },
      userId
    } = request;
    const tutorialId = parseInt(id); // Retrieve the planner id for this user to find out 
    // if this tutorial is register in the planner

    const plannerId = await _server_dataAccess_planner_entity__WEBPACK_IMPORTED_MODULE_0__[/* PlannerDB */ "a"].getPlannerId(userId);
    const isTutorialRegistered = await _server_dataAccess_planner_entity__WEBPACK_IMPORTED_MODULE_0__[/* PlannerDB */ "a"].isTutorialRegistered(tutorialId, plannerId);
    let sectionProgress = [];

    if (isTutorialRegistered) {
      // Retrieve the list of section ids and find the progress
      const sectionIds = await _server_dataAccess_tutorialSection_entity__WEBPACK_IMPORTED_MODULE_1__[/* TutorialSectionDB */ "a"].listTutorialSectionIds(tutorialId);
      sectionProgress = await _server_dataAccess_tutorialProgress_entity__WEBPACK_IMPORTED_MODULE_2__[/* TutorialProgressDB */ "a"].retrieveSectionProgress(sectionIds, userId);
    }

    response.json({
      isTutorialRegistered,
      sectionProgress
    });
  }

  /** Hnadles enrolling a user into a tutorial by registering it with the planner */
  static async handleTutorialEnrollment(request, response) {
    const {
      tutorialId,
      shouldBeEnrolled
    } = request.body;
    const {
      userId
    } = request; // Get the id of the planner for this user and check if they're already enrolled

    const plannerId = await _server_dataAccess_planner_entity__WEBPACK_IMPORTED_MODULE_0__[/* PlannerDB */ "a"].getPlannerId(userId);
    const userAlreadyEnrolled = await _server_dataAccess_planner_entity__WEBPACK_IMPORTED_MODULE_0__[/* PlannerDB */ "a"].isTutorialRegistered(tutorialId, plannerId); // If the user should be enrolled

    if (shouldBeEnrolled == true) {
      // If they're not already enrolled, enroll them
      if (userAlreadyEnrolled == false) {
        await _server_dataAccess_planner_entity__WEBPACK_IMPORTED_MODULE_0__[/* PlannerDB */ "a"].registerTutorial(tutorialId, plannerId, userId);
      }
    } // Otherwise, the user should be unenrolled
    else {
        // If they're already enrolled, unenroll them
        if (userAlreadyEnrolled == true) {
          await _server_dataAccess_planner_entity__WEBPACK_IMPORTED_MODULE_0__[/* PlannerDB */ "a"].unregisterTutorial(tutorialId, plannerId, userId);
        }
      } // Return the final status of the tutorial being registered


    const isTutorialRegistered = await _server_dataAccess_planner_entity__WEBPACK_IMPORTED_MODULE_0__[/* PlannerDB */ "a"].isTutorialRegistered(tutorialId, plannerId);
    response.json({
      isTutorialRegistered
    });
  }

}

;
/* harmony default export */ __webpack_exports__["default"] = (Object(_server_api_middleware_protectWithAuthentcation__WEBPACK_IMPORTED_MODULE_3__["default"])(handler));

/***/ })

/******/ });