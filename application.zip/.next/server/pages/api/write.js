module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 16);
/******/ })
/************************************************************************/
/******/ ({

/***/ 16:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("gGt3");


/***/ }),

/***/ "2v0O":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return TutorialSectionDAO; });
/* harmony import */ var _database_knex__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("CaIY");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


class TutorialSectionDAO {
  static async getSeparateSections(tutorialSections, tutorialId) {
    const sectionsToAdd = [];
    const sectionsToUpdate = [];
    const sectionsToDelete = []; // Compare the incoming tutorial sections with what's on file for this tutorial

    const existingSectionIds = await TutorialSectionDAO.listTutorialSectionIds(tutorialId);
    const providedSectionIds = tutorialSections.filter(section => section.hasOwnProperty('id')).map(section => section.id); // The section id's to delete are the ones that exist in the database
    // but are no longer being provided in the request - i.e. these need to be removed

    const sectionIdsToDelete = existingSectionIds.filter(existingSectionId => !providedSectionIds.includes(parseInt(existingSectionId.toString())));
    sectionsToDelete.push(...sectionIdsToDelete);
    tutorialSections.forEach(tutorialSection => {
      // If there's an id then the section needs to be updated
      if (tutorialSection.hasOwnProperty('id')) {
        sectionsToUpdate.push(tutorialSection);
      } // Otherwise, no id means it needs to be added
      else {
          sectionsToAdd.push(tutorialSection);
        }
    });
    return {
      sectionsToAdd,
      sectionsToUpdate,
      sectionsToDelete
    };
  }

  /** something */
  static async listTutorialSections(tutorialId) {
    return await _database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"].select('*').from('tutorial_sections').where('tutorialId', tutorialId).orderBy('id', 'asc');
  }

  static async addOrUpdateTutorialSection(tutorialSections, tutorialId) {
    const {
      sectionsToAdd,
      sectionsToUpdate,
      sectionsToDelete
    } = await TutorialSectionDAO.getSeparateSections(tutorialSections, tutorialId);
    let addedSections = [];
    let updatedSections = [];
    const sectionsWithId = sectionsToAdd.map(section => {
      return _objectSpread(_objectSpread({}, section), {}, {
        tutorialId
      });
    });

    if (sectionsToAdd.length > 0) {
      const addedSections = await Object(_database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"])('tutorial_sections').insert(sectionsWithId).returning('*');
      addedSections.push(...addedSections);
    }

    if (sectionsToUpdate.length > 0) {
      for (let i = 0; i < sectionsToUpdate.length; i++) {
        const section = sectionsToUpdate[i];
        const updatedSection = await Object(_database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"])('tutorial_sections').update(section).where({
          'id': section.id,
          'tutorialId': tutorialId
        }).returning('*');
        updatedSections.push(...updatedSection);
      }
    }

    if (sectionsToDelete.length > 0) {
      await TutorialSectionDAO.deleteSections(tutorialId, sectionsToDelete);
    }

    return [...addedSections, ...updatedSections];
  }

  static async deleteTutorialSection(id) {
    const response = await Object(_database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"])('tutorial_sections').where('id', id).del();

    if (response == 1) {
      return true;
    }

    return false;
  }

  static async listTutorialSectionIds(tutorialId) {
    const sectionIdsRes = await _database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"].select('id').from('tutorial_sections').where('tutorialId', tutorialId);
    const sectionIds = sectionIdsRes.map(el => el.id);
    return sectionIds;
  }

  static async deleteSections(tutorialId, sectionIds) {
    // Delete these sections from the tutorial progress table
    await Object(_database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"])('tutorial_sections_progress').delete().whereIn('sectionId', sectionIds); // Delete the tutorial sections

    await Object(_database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"])('tutorial_sections').delete().whereIn('id', sectionIds).andWhere({
      tutorialId
    });
  }

}
;
/**
 *
 *
 *
  /** Adds or updates the sections for a tutorial */

/*
public static async addSections(tutorialId: number, tutorialSections: TutorialInterface['sections']) {

  const sectionRequests = tutorialSections.map((section) => {
      let query, values;
      const { title, content, id } = section;

      // If the section has an id, then it needs to be updated
      if (id) {
          query = `
          UPDATE tutorial_sections
          SET
              "title" = ($1),
              "content" = ($2)
          WHERE "id" = ($3) AND "tutorialId" = ($4)
          `;
          values = [title, content, id, tutorialId];
      }

      // Otherwise, no existing id means it's an insert
      else {
          query = `
          INSERT INTO tutorial_sections ("title", "content", "tutorialId")
          VALUES ($1, $2, $3)
          `;
          values = [title, content, tutorialId];
      }

      return Client.executeQuery(query, values);
  });

  await Promise.all(sectionRequests);
};

/** Deletes any sections that from the tutorial that exist in the database but were not sent along with an update */

/*
 */

/***/ }),

/***/ "3qNE":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, "a", function() { return /* reexport */ tutorials_TutorialDAO; });

// EXTERNAL MODULE: ./server/database/knex.ts
var knex = __webpack_require__("CaIY");

// EXTERNAL MODULE: ./server/dataAccess/tag/entity.ts + 1 modules
var entity = __webpack_require__("M4QR");

// EXTERNAL MODULE: ./server/dataAccess/tutorialSection/entity.ts
var tutorialSection_entity = __webpack_require__("IzFH");

// CONCATENATED MODULE: ./server/dataAccess/tutorials/index.ts



class tutorials_TutorialDAO {
  static async listTutorials() {
    return await knex["a" /* Knex */].select('*').from('tutorials').where('enabled', true);
  }

  static async findTutorial(prop, val) {
    const tutorials = await knex["a" /* Knex */].select('*').from('tutorials').where(prop, val);
    return tutorials.shift();
  }

  static async addTutorial(props, userId) {
    const addedTutorials = await Object(knex["a" /* Knex */])('tutorials').insert({
      title: props.title,
      color: props.color,
      description1: props.description1,
      description2: props.description2,
      enabled: props.enabled,
      featuredImage: props.featuredImage,
      codeUrl: props.codeUrl,
      liveUrl: props.liveUrl,
      slug: props.slug,
      userId: userId
    }).returning('*');
    const addedTutorial = addedTutorials.shift(); // If there's tags to associate

    if (props.tags.length > 0) {
      await entity["a" /* TagDB */].relateWithTutorial(props.tags, addedTutorial.id);
    } // If there's sections to write


    if (props.sections.length > 0) {
      await tutorialSection_entity["a" /* TutorialSectionDB */].addOrUpdateTutorialSection(props.sections, addedTutorial.id);
    }

    return addedTutorial;
  }

  static async updateTutorial(props, userId) {
    // Update the main tutorial information
    const updatedTutorial = await Object(knex["a" /* Knex */])('tutorials').where({
      'id': props.id,
      'userId': userId
    }).update({
      title: props.title,
      color: props.color,
      description1: props.description1,
      description2: props.description2,
      enabled: props.enabled,
      featuredImage: props.featuredImage,
      codeUrl: props.codeUrl,
      liveUrl: props.liveUrl,
      slug: props.slug,
      userId: userId
    }).returning('*'); // If there's tags to associate

    await entity["a" /* TagDB */].relateWithTutorial(props.tags, props.id); // If there's sections to add, update, or delete

    await tutorialSection_entity["a" /* TutorialSectionDB */].addOrUpdateTutorialSection(props.sections, props.id);
    return updatedTutorial.shift();
  }

  /** Deletes tutorial with the given tutorial id belonging to the specified user id */
  static async deleteTutorial(tutorialId, userId) {
    // Delete this tutorial from any user planner
    await Object(knex["a" /* Knex */])('planner_detail').delete().where({
      tutorialId
    }); // Delete section progress for any section belonging to this tutorial

    await knex["a" /* Knex */].raw(`
        DELETE
        FROM
            tutorial_sections_progress
        WHERE
            "sectionId" in (
                SELECT id
                FROM
                    tutorial_sections
                WHERE
                    "tutorialId" = '${tutorialId}'
            )
        `); // Delete sections belonging to this tutorial

    await Object(knex["a" /* Knex */])('tutorial_sections').delete().where({
      tutorialId
    }); // Delete tags associated to this tutorial

    await Object(knex["a" /* Knex */])('tutorial_tag_relations').delete().where({
      tutorialId
    }); // Delete this tutorial

    const response = await Object(knex["a" /* Knex */])('tutorials').where('id', tutorialId).del();

    if (response == 1) {
      return {
        id: tutorialId
      };
    } // Otherwise, unable to delete tutorial so raise error


    throw Error(`Unable to delete tutorial with ID ${tutorialId}`);
  }

  /** Returns the tags associated with a specific tutorial */
  static async getTags(tutorialId) {
    const tags = await knex["a" /* Knex */].raw(`
            SELECT id, tag
            FROM tags
            INNER JOIN tutorial_tag_relations
            ON tags.id = tutorial_tag_relations."tagId"
            WHERE tutorial_tag_relations."tutorialId" = ${tutorialId}
            `);
    return tags.rows;
  }

  static async getTutorialForEditing(userId, tutorialId) {
    // This means only retrieve the requested tutorial
    // as the user is trying to edit it
    if (tutorialId) {
      const editableTutorial = await Object(knex["a" /* Knex */])('tutorials').select('title', 'description1', 'description2', 'enabled', 'color', 'featuredImage', 'liveUrl', 'codeUrl', 'id', 'slug').where({
        id: tutorialId,
        userId: userId
      });
      return editableTutorial;
    } // Otherwise, all editable tutorials need to be shown, for the list page


    const editableTutorials = await Object(knex["a" /* Knex */])('tutorials').select('title', 'description1', 'description2', 'enabled', 'color', 'featuredImage', 'id', 'slug').where({
      userId: userId
    }); // Set up promises for fetching the tags

    const tagPromises = editableTutorials.map(tutorial => tutorials_TutorialDAO.getTags(tutorial.id));
    const tagResults = await Promise.all(tagPromises); // Set the tags into each

    editableTutorials.forEach((editableTutorial, index) => {
      editableTutorial['tags'] = tagResults[index];
    });
    return editableTutorials;
  }

  static async getSiteTutorials() {
    const siteTutorials = await knex["a" /* Knex */].raw(`
            SELECT 
        t."title", 
        t."description1",   
        t."description2", 
        t."color", 
        t."featuredImage", 
        t."id", 
        t."slug",
        u."profileImage", 
        u."name",
        uai."username"
        FROM tutorials t
        INNER JOIN user_information u 
        ON u."id" = t."userId"
        INNER JOIN user_account_information uai
        on uai."userId" = t."userId"
        WHERE t."enabled" = true
        `);
    return siteTutorials.rows;
  }

}
;
// CONCATENATED MODULE: ./server/dataAccess/tutorials/entity.ts


/***/ }),

/***/ "4hjK":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return S3; });
/* harmony import */ var aws_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("DaQf");
/* harmony import */ var aws_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(aws_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("ebvM");
function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


 // Set the region 

aws_sdk__WEBPACK_IMPORTED_MODULE_0___default.a.config.update({
  region: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].awsRegion
});
class S3 {
  /** Uploads a file to the specified bucket */
  static async upload(uploadParams) {
    const response = await this.s3.upload(uploadParams).promise();
    return response;
  }

}

_defineProperty(S3, "s3", new aws_sdk__WEBPACK_IMPORTED_MODULE_0___default.a.S3({
  apiVersion: '2006-03-01'
}));

/***/ }),

/***/ "7+yl":
/***/ (function(module, exports) {

// This alphabet uses `A-Za-z0-9_-` symbols. The genetic algorithm helped
// optimize the gzip compression for this alphabet.
let urlAlphabet =
  'ModuleSymbhasOwnPr-0123456789ABCDEFGHNRVfgctiUvz_KqYTJkLxpZXIjQW'

module.exports = { urlAlphabet }


/***/ }),

/***/ "CaIY":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(__dirname) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Knex; });
/* harmony import */ var knex__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("SfJF");
/* harmony import */ var knex__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(knex__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("ebvM");


const KnexConfiguration = {
  development: {
    client: 'pg',
    connection: {
      host: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbHost,
      user: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbUser,
      password: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbPassword,
      database: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbName,
      port: 5432
    },
    migrations: {
      directory: __dirname + '/db/pg/migrations'
    },
    seeds: {
      directory: __dirname + '/db/pg/seeds/development'
    }
  },
  production: {
    client: 'pg',
    connection: {
      host: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbHost,
      user: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbUser,
      password: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbPassword,
      database: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbName,
      ssl: true
    },
    migrations: {
      directory: __dirname + '/db/pg/migrations'
    },
    seeds: {
      directory: __dirname + '/db/pg/seeds/production'
    }
  }
};
const Knex = knex__WEBPACK_IMPORTED_MODULE_0___default()(KnexConfiguration[_utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].environment]);
/* WEBPACK VAR INJECTION */}.call(this, "/"))

/***/ }),

/***/ "DaQf":
/***/ (function(module, exports) {

module.exports = require("aws-sdk");

/***/ }),

/***/ "IzFH":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("2v0O");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _index__WEBPACK_IMPORTED_MODULE_0__["a"]; });



/***/ }),

/***/ "KP9d":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/** Function for slugifying a passed string */
const slugify = text => {
  return text.toString().toLowerCase().replace(/\s+/g, '-') // Replace spaces with -
  .replace(/[^\w\-]+/g, '') // Remove all non-word chars
  .replace(/\-\-+/g, '-') // Replace multiple - with single -
  .replace(/^-+/, '') // Trim - from start of text
  .replace(/-+$/, ''); // Trim - from end of text
};

/* harmony default export */ __webpack_exports__["a"] = (slugify);

/***/ }),

/***/ "M4QR":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, "a", function() { return /* reexport */ tag_TagDAO; });

// EXTERNAL MODULE: ./server/database/knex.ts
var knex = __webpack_require__("CaIY");

// CONCATENATED MODULE: ./server/dataAccess/tag/index.ts

class tag_TagDAO {
  static async listTags() {
    return await knex["a" /* Knex */].select('*').from('tags');
  }

  static async findTag(prop, value) {
    return await knex["a" /* Knex */].select('*').from('tags').where(prop, value);
  }

  static async relateWithTutorial(tags, tutorialId) {
    // Add any tags that don't exist in the schema
    const insertableTags = tags.map(tag => {
      return {
        tag
      };
    });
    await Object(knex["a" /* Knex */])('tags').insert(insertableTags).onConflict('tag').ignore(); // Remove any tags that should no longer be associated with the tutorial

    await tag_TagDAO.validateWithTutorial(tags, tutorialId); // Get the ids for these tags

    const tagIds = await Object(knex["a" /* Knex */])('tags').select('id').whereIn('tag', tags); // Turn them into the tag/tutorial id pairs

    const tutorialTagPairs = tagIds.map(tagId => {
      return {
        tagId: tagId.id,
        tutorialId
      };
    });
    await Object(knex["a" /* Knex */])('tutorial_tag_relations').insert(tutorialTagPairs).onConflict(['tagId', 'tutorialId']).ignore();
  }

  static async validateWithTutorial(tags, tutorialId) {
    // Find out which tags are associated with this tutorial right now
    const tagsInDatabase = (await knex["a" /* Knex */].raw(`
        SELECT tags.tag, tags.id
        FROM tags
        INNER JOIN tutorial_tag_relations ttr
        ON 
            ttr."tagId" = tags.id
        WHERE 
            ttr."tutorialId" = ${tutorialId};
        `)).rows; // Any not provided, or any provided that aren't what the database has on record
    // means we need to remove from the database

    const tagIdsToRemove = tagsInDatabase.reduce((acc, tagItem) => {
      const tagShouldBeRemoved = !tags.find(tag => tag.toLowerCase() === tagItem.tag.toLowerCase());

      if (tagShouldBeRemoved && tagItem.hasOwnProperty('id')) {
        acc.push(tagItem.id);
      }

      return acc;
    }, []);

    if (tagIdsToRemove.length > 0) {
      await Object(knex["a" /* Knex */])('tutorial_tag_relations').delete().whereIn('tagId', tagIdsToRemove).andWhere({
        tutorialId
      });
    }
  }

}
;
// CONCATENATED MODULE: ./server/dataAccess/tag/entity.ts


/***/ }),

/***/ "PJMN":
/***/ (function(module, exports) {

module.exports = require("crypto");

/***/ }),

/***/ "SfJF":
/***/ (function(module, exports) {

module.exports = require("knex");

/***/ }),

/***/ "ebvM":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
const Config = {
  dbHost: process.env.DB_HOST,
  dbUser: process.env.DB_USER,
  dbPassword: process.env.DB_PASSWORD,
  dbName: process.env.DB_NAME,
  zerochassSecret: process.env.ZEROCHASS_SECRET,
  awsRegion: process.env.AWS_REGION,
  awsBucket: process.env.AWS_BUCKET,
  port: process.env.PORT,
  environment: ("production" || false).toLowerCase()
};
/* harmony default export */ __webpack_exports__["a"] = (Config);

/***/ }),

/***/ "gGt3":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var nanoid__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("k4gg");
/* harmony import */ var nanoid__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(nanoid__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants_slugify__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("KP9d");
/* harmony import */ var _server_api_middleware_protectWithAuthentcation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("i5SM");
/* harmony import */ var _server_dataAccess_tutorials_entity__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("3qNE");
/* harmony import */ var _server_utils_config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("ebvM");
/* harmony import */ var _server_services_awsService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("4hjK");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }








const handler = async (request, response) => {
  const method = request.method.toLowerCase();

  if (method === 'get') {
    return WriteService.retrieveTutorial(request, response);
  }

  if (method === 'post') {
    return WriteService.createTutorial(request, response);
  }

  if (method === 'put') {
    return WriteService.updateTutorial(request, response);
  }

  if (method === 'delete') {
    return WriteService.deleteTutorial(request, response);
  }
};

class WriteService {
  /** Handles retrieving a tutorial for editing */
  static async retrieveTutorial(request, response) {
    const {
      id
    } = request.query;
    const {
      userId
    } = request; // If there's an id, then we fetch a single tutorial

    if (id) {
      const tutorial = await _server_dataAccess_tutorials_entity__WEBPACK_IMPORTED_MODULE_3__[/* TutorialDB */ "a"].getTutorialForEditing(userId, id);
      response.status(200).json(_objectSpread({}, tutorial));
    } // Otherwise, it's a request to fetch all editable tutorials
    else {
        const tutorials = await _server_dataAccess_tutorials_entity__WEBPACK_IMPORTED_MODULE_3__[/* TutorialDB */ "a"].getTutorialForEditing(userId);
        response.status(200).json([...tutorials]);
      }
  }

  /** Handles creating a new tutorial in the databse */
  static async createTutorial(request, response) {
    // Get the tutorial to write and the user id for it
    const tutorialRequest = request.body;
    const {
      userId
    } = request;
    const preparedTutorial = await WriteService.prepareTutorial(tutorialRequest);
    preparedTutorial['slug'] = `${Object(_constants_slugify__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(preparedTutorial.title)}--${Object(nanoid__WEBPACK_IMPORTED_MODULE_0__["nanoid"])(5)}`;
    const tutorial = await _server_dataAccess_tutorials_entity__WEBPACK_IMPORTED_MODULE_3__[/* TutorialDB */ "a"].addTutorial(preparedTutorial, userId);
    response.json(tutorial.id);
  }

  /** Handles updating an existing tutorial in the database */
  static async updateTutorial(request, response) {
    // Get the tutorial to write
    const tutorialRequest = request.body;
    const {
      userId
    } = request;
    const preparedTutorial = await WriteService.prepareTutorial(tutorialRequest);
    const updatedTutorial = await _server_dataAccess_tutorials_entity__WEBPACK_IMPORTED_MODULE_3__[/* TutorialDB */ "a"].updateTutorial(preparedTutorial, userId);
    response.json(_objectSpread({}, updatedTutorial));
  }

  static async deleteTutorial(request, response) {
    // Get id of tutorial to delete
    const {
      id
    } = request.body;
    const {
      userId
    } = request;

    try {
      await _server_dataAccess_tutorials_entity__WEBPACK_IMPORTED_MODULE_3__[/* TutorialDB */ "a"].deleteTutorial(id, userId);
      response.status(200).json(`Tutorial with ID ${id} deleted`);
    } // Handle errors with deleting
    catch (error) {
      console.log(`An error occurred deleting tutorial with ID ${id}`, error);
      response.status(400).json(`Unable to delete tutorial`);
    }
  }

  /** Prepares a tutorial by creating the payload that can be inserted into the database */
  static async prepareTutorial(tutorialRequest) {
    // These fields require some transformation prior to being ready to be part of a tutorial
    const tutorial = _objectSpread(_objectSpread({}, tutorialRequest), {}, {
      featuredImage: '',
      tags: tutorialRequest.tags.map(tag => tag.toLowerCase())
    }); // If we have a featured image, we need to upload it to S3 and get the upload
    // URL prior to inserting the URL to our database


    if (typeof tutorialRequest.featuredImage === 'object') {
      tutorial.featuredImage = await WriteService.uploadFeaturedImage(tutorialRequest.featuredImage.dataUrl);
    } // Otherwise, if a string, let it remain
    else {
        tutorial.featuredImage = tutorialRequest.featuredImage;
      }

    return tutorial;
  }

}

_defineProperty(WriteService, "uploadFeaturedImage", async featuredImageDataUrl => {
  const dataUrl = featuredImageDataUrl;
  const base64 = Buffer.from(dataUrl.replace(/^data:image\/\w+;base64,/, ""), 'base64');
  const params = {
    Bucket: `${_server_utils_config__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"].awsBucket}/featured-images`,
    Key: `${Object(nanoid__WEBPACK_IMPORTED_MODULE_0__["nanoid"])()}.png`,
    Body: base64,
    ACL: 'public-read',
    ContentEncoding: 'base64',
    ContentType: 'image/png'
  }; // Get the url for the uploaded image and store it in the tutorial

  const {
    Location
  } = await _server_services_awsService__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"].upload(params);
  return Location;
});

/* harmony default export */ __webpack_exports__["default"] = (Object(_server_api_middleware_protectWithAuthentcation__WEBPACK_IMPORTED_MODULE_2__["default"])(handler));

/***/ }),

/***/ "i5SM":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, "isAuthenticated", function() { return /* binding */ isAuthenticated; });

// EXTERNAL MODULE: external "jsonwebtoken"
var external_jsonwebtoken_ = __webpack_require__("tMJi");
var external_jsonwebtoken_default = /*#__PURE__*/__webpack_require__.n(external_jsonwebtoken_);

// CONCATENATED MODULE: ./util/config.ts
const Config = {
  dbHost: process.env.DB_HOST,
  dbUser: process.env.DB_USER,
  dbPassword: process.env.DB_PASSWORD,
  dbName: process.env.DB_NAME,
  zerochassSecret: process.env.ZEROCHASS_SECRET,
  awsRegion: process.env.AWS_REGION,
  awsBucket: process.env.AWS_BUCKET
};
// EXTERNAL MODULE: external "nookies"
var external_nookies_ = __webpack_require__("kG9d");
var external_nookies_default = /*#__PURE__*/__webpack_require__.n(external_nookies_);

// CONCATENATED MODULE: ./server/api/middleware/protectWithAuthentcation.ts



;
/** Returns boolean on user being authenticated */

const isAuthenticated = (req, res) => {
  const authentication = {
    authenticated: null,
    userId: null,
    accessToken: null
  }; // Check if there's a zerochassServerCookie on the request -- if it does exist, the jwt will be available

  const {
    zerochassServerCookie,
    zerochassClientCookie
  } = external_nookies_default.a.get({
    req
  }); // If there's no jwt, update the authentication object

  if (!zerochassServerCookie) {
    authentication['authenticated'] = false;
  } // Else there's a jwt, let's see if it's valid
  else {
      const userPayload = external_jsonwebtoken_default.a.verify(zerochassServerCookie, Config.zerochassSecret); // If the token is invalid (i.e. no payload), clear the cookie and update authentication object

      if (!userPayload) {
        external_nookies_default.a.destroy(null, zerochassServerCookie);
        external_nookies_default.a.destroy(null, zerochassClientCookie);
        authentication['authenticated'] = false;
      } // Else, token is valid - let's set the userId on the request object
      else {
          authentication['userId'] = userPayload['userId'];
          authentication['accessToken'] = userPayload['accessToken'];
          authentication['authenticated'] = true;
        }
    }

  return authentication;
};
/** Middleware that secures protected routes with authentication */

const handleAccess = (request, response) => {
  const {
    userId,
    authenticated,
    accessToken
  } = isAuthenticated(request, response);

  if (authenticated) {
    request['authenticated'] = true;
    request['userId'] = userId;
    request['accessToken'] = accessToken;
  } else {
    response.status(401).json(`Invalid or missing authorization token`);
  }

  return authenticated;
};
/** Protects secured API routes against non-authenticated sessions.
 * Also adds userId and access token to request object for authenticated sessions */


const protectWithAuthentication = handler => (request, response) => {
  // Determine if the session is authenticated
  const isAuthenticated = handleAccess(request, response); // If the session was authenticated, allows the requested endpoint to handle responding

  if (isAuthenticated) return handler(request, response);
};

/* harmony default export */ var protectWithAuthentcation = __webpack_exports__["default"] = (protectWithAuthentication);

/***/ }),

/***/ "k4gg":
/***/ (function(module, exports, __webpack_require__) {

let crypto = __webpack_require__("PJMN")

let { urlAlphabet } = __webpack_require__("7+yl")

// It is best to make fewer, larger requests to the crypto module to
// avoid system call overhead. So, random numbers are generated in a
// pool. The pool is a Buffer that is larger than the initial random
// request size by this multiplier. The pool is enlarged if subsequent
// requests exceed the maximum buffer size.
const POOL_SIZE_MULTIPLIER = 32
let pool, poolOffset

let random = bytes => {
  if (!pool || pool.length < bytes) {
    pool = Buffer.allocUnsafe(bytes * POOL_SIZE_MULTIPLIER)
    crypto.randomFillSync(pool)
    poolOffset = 0
  } else if (poolOffset + bytes > pool.length) {
    crypto.randomFillSync(pool)
    poolOffset = 0
  }

  let res = pool.subarray(poolOffset, poolOffset + bytes)
  poolOffset += bytes
  return res
}

let customRandom = (alphabet, size, getRandom) => {
  // First, a bitmask is necessary to generate the ID. The bitmask makes bytes
  // values closer to the alphabet size. The bitmask calculates the closest
  // `2^31 - 1` number, which exceeds the alphabet size.
  // For example, the bitmask for the alphabet size 30 is 31 (00011111).
  let mask = (2 << (31 - Math.clz32((alphabet.length - 1) | 1))) - 1
  // Though, the bitmask solution is not perfect since the bytes exceeding
  // the alphabet size are refused. Therefore, to reliably generate the ID,
  // the random bytes redundancy has to be satisfied.

  // Note: every hardware random generator call is performance expensive,
  // because the system call for entropy collection takes a lot of time.
  // So, to avoid additional system calls, extra bytes are requested in advance.

  // Next, a step determines how many random bytes to generate.
  // The number of random bytes gets decided upon the ID size, mask,
  // alphabet size, and magic number 1.6 (using 1.6 peaks at performance
  // according to benchmarks).
  let step = Math.ceil((1.6 * mask * size) / alphabet.length)

  return () => {
    let id = ''
    while (true) {
      let bytes = getRandom(step)
      // A compact alternative for `for (let i = 0; i < step; i++)`.
      let i = step
      while (i--) {
        // Adding `|| ''` refuses a random byte that exceeds the alphabet size.
        id += alphabet[bytes[i] & mask] || ''
        if (id.length === size) return id
      }
    }
  }
}

let customAlphabet = (alphabet, size) => customRandom(alphabet, size, random)

let nanoid = (size = 21) => {
  let bytes = random(size)
  let id = ''
  // A compact alternative for `for (let i = 0; i < size; i++)`.
  while (size--) {
    // It is incorrect to use bytes exceeding the alphabet size.
    // The following mask reduces the random byte in the 0-255 value
    // range to the 0-63 value range. Therefore, adding hacks, such
    // as empty string fallback or magic numbers, is unneccessary because
    // the bitmask trims bytes down to the alphabet size.
    id += urlAlphabet[bytes[size] & 63]
  }
  return id
}

module.exports = { nanoid, customAlphabet, customRandom, urlAlphabet, random }


/***/ }),

/***/ "kG9d":
/***/ (function(module, exports) {

module.exports = require("nookies");

/***/ }),

/***/ "tMJi":
/***/ (function(module, exports) {

module.exports = require("jsonwebtoken");

/***/ })

/******/ });