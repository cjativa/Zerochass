module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../ssr-module-cache.js');
/******/
/******/ 	// object to store loaded chunks
/******/ 	// "0" means "already loaded"
/******/ 	var installedChunks = {
/******/ 		28: 0
/******/ 	};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/ 	// This file contains only the entry chunk.
/******/ 	// The chunk loading function for additional chunks
/******/ 	__webpack_require__.e = function requireEnsure(chunkId) {
/******/ 		var promises = [];
/******/
/******/
/******/ 		// require() chunk loading for javascript
/******/
/******/ 		// "0" is the signal for "already loaded"
/******/ 		if(installedChunks[chunkId] !== 0) {
/******/ 			var chunk = require("../../" + ({}[chunkId]||chunkId) + "." + {"0":"c903ba37a99b88734864"}[chunkId] + ".js");
/******/ 			var moreModules = chunk.modules, chunkIds = chunk.ids;
/******/ 			for(var moduleId in moreModules) {
/******/ 				modules[moduleId] = moreModules[moduleId];
/******/ 			}
/******/ 			for(var i = 0; i < chunkIds.length; i++)
/******/ 				installedChunks[chunkIds[i]] = 0;
/******/ 		}
/******/ 		return Promise.all(promises);
/******/ 	};
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// uncaught error handler for webpack runtime
/******/ 	__webpack_require__.oe = function(err) {
/******/ 		process.nextTick(function() {
/******/ 			throw err; // catch this error by using import().catch()
/******/ 		});
/******/ 	};
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 22);
/******/ })
/************************************************************************/
/******/ ({

/***/ "/jkW":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.isDynamicRoute = isDynamicRoute; // Identify /[param]/ in route string

const TEST_ROUTE = /\/\[[^/]+?\](?=\/|$)/;

function isDynamicRoute(route) {
  return TEST_ROUTE.test(route);
}

/***/ }),

/***/ "0Bsm":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__("TqRt");

exports.__esModule = true;
exports.default = withRouter;

var _react = _interopRequireDefault(__webpack_require__("cDcd"));

var _router = __webpack_require__("nOHt");

function withRouter(ComposedComponent) {
  function WithRouterWrapper(props) {
    return /*#__PURE__*/_react.default.createElement(ComposedComponent, Object.assign({
      router: (0, _router.useRouter)()
    }, props));
  }

  WithRouterWrapper.getInitialProps = ComposedComponent.getInitialProps // This is needed to allow checking for custom getInitialProps in _app
  ;
  WithRouterWrapper.origGetInitialProps = ComposedComponent.origGetInitialProps;

  if (false) {}

  return WithRouterWrapper;
}

/***/ }),

/***/ "0G5g":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.cancelIdleCallback = exports.requestIdleCallback = void 0;

const requestIdleCallback = typeof self !== 'undefined' && self.requestIdleCallback || function (cb) {
  let start = Date.now();
  return setTimeout(function () {
    cb({
      didTimeout: false,
      timeRemaining: function () {
        return Math.max(0, 50 - (Date.now() - start));
      }
    });
  }, 1);
};

exports.requestIdleCallback = requestIdleCallback;

const cancelIdleCallback = typeof self !== 'undefined' && self.cancelIdleCallback || function (id) {
  return clearTimeout(id);
};

exports.cancelIdleCallback = cancelIdleCallback;

/***/ }),

/***/ 22:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("P808");


/***/ }),

/***/ "284h":
/***/ (function(module, exports, __webpack_require__) {

var _typeof = __webpack_require__("cDf5");

function _getRequireWildcardCache() {
  if (typeof WeakMap !== "function") return null;
  var cache = new WeakMap();

  _getRequireWildcardCache = function _getRequireWildcardCache() {
    return cache;
  };

  return cache;
}

function _interopRequireWildcard(obj) {
  if (obj && obj.__esModule) {
    return obj;
  }

  if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") {
    return {
      "default": obj
    };
  }

  var cache = _getRequireWildcardCache();

  if (cache && cache.has(obj)) {
    return cache.get(obj);
  }

  var newObj = {};
  var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;

  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;

      if (desc && (desc.get || desc.set)) {
        Object.defineProperty(newObj, key, desc);
      } else {
        newObj[key] = obj[key];
      }
    }
  }

  newObj["default"] = obj;

  if (cache) {
    cache.set(obj, newObj);
  }

  return newObj;
}

module.exports = _interopRequireWildcard;

/***/ }),

/***/ "2v0O":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return TutorialSectionDAO; });
/* harmony import */ var _database_knex__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("CaIY");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


class TutorialSectionDAO {
  static async getSeparateSections(tutorialSections, tutorialId) {
    const sectionsToAdd = [];
    const sectionsToUpdate = [];
    const sectionsToDelete = []; // Compare the incoming tutorial sections with what's on file for this tutorial

    const existingSectionIds = await TutorialSectionDAO.listTutorialSectionIds(tutorialId);
    const providedSectionIds = tutorialSections.filter(section => section.hasOwnProperty('id')).map(section => section.id); // The section id's to delete are the ones that exist in the database
    // but are no longer being provided in the request - i.e. these need to be removed

    const sectionIdsToDelete = existingSectionIds.filter(existingSectionId => !providedSectionIds.includes(parseInt(existingSectionId.toString())));
    sectionsToDelete.push(...sectionIdsToDelete);
    tutorialSections.forEach(tutorialSection => {
      // If there's an id then the section needs to be updated
      if (tutorialSection.hasOwnProperty('id')) {
        sectionsToUpdate.push(tutorialSection);
      } // Otherwise, no id means it needs to be added
      else {
          sectionsToAdd.push(tutorialSection);
        }
    });
    return {
      sectionsToAdd,
      sectionsToUpdate,
      sectionsToDelete
    };
  }

  /** something */
  static async listTutorialSections(tutorialId) {
    return await _database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"].select('*').from('tutorial_sections').where('tutorialId', tutorialId).orderBy('id', 'asc');
  }

  static async addOrUpdateTutorialSection(tutorialSections, tutorialId) {
    const {
      sectionsToAdd,
      sectionsToUpdate,
      sectionsToDelete
    } = await TutorialSectionDAO.getSeparateSections(tutorialSections, tutorialId);
    let addedSections = [];
    let updatedSections = [];
    const sectionsWithId = sectionsToAdd.map(section => {
      return _objectSpread(_objectSpread({}, section), {}, {
        tutorialId
      });
    });

    if (sectionsToAdd.length > 0) {
      const addedSections = await Object(_database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"])('tutorial_sections').insert(sectionsWithId).returning('*');
      addedSections.push(...addedSections);
    }

    if (sectionsToUpdate.length > 0) {
      for (let i = 0; i < sectionsToUpdate.length; i++) {
        const section = sectionsToUpdate[i];
        const updatedSection = await Object(_database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"])('tutorial_sections').update(section).where({
          'id': section.id,
          'tutorialId': tutorialId
        }).returning('*');
        updatedSections.push(...updatedSection);
      }
    }

    if (sectionsToDelete.length > 0) {
      await TutorialSectionDAO.deleteSections(tutorialId, sectionsToDelete);
    }

    return [...addedSections, ...updatedSections];
  }

  static async deleteTutorialSection(id) {
    const response = await Object(_database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"])('tutorial_sections').where('id', id).del();

    if (response == 1) {
      return true;
    }

    return false;
  }

  static async listTutorialSectionIds(tutorialId) {
    const sectionIdsRes = await _database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"].select('id').from('tutorial_sections').where('tutorialId', tutorialId);
    const sectionIds = sectionIdsRes.map(el => el.id);
    return sectionIds;
  }

  static async deleteSections(tutorialId, sectionIds) {
    // Delete these sections from the tutorial progress table
    await Object(_database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"])('tutorial_sections_progress').delete().whereIn('sectionId', sectionIds); // Delete the tutorial sections

    await Object(_database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"])('tutorial_sections').delete().whereIn('id', sectionIds).andWhere({
      tutorialId
    });
  }

}
;
/**
 *
 *
 *
  /** Adds or updates the sections for a tutorial */

/*
public static async addSections(tutorialId: number, tutorialSections: TutorialInterface['sections']) {

  const sectionRequests = tutorialSections.map((section) => {
      let query, values;
      const { title, content, id } = section;

      // If the section has an id, then it needs to be updated
      if (id) {
          query = `
          UPDATE tutorial_sections
          SET
              "title" = ($1),
              "content" = ($2)
          WHERE "id" = ($3) AND "tutorialId" = ($4)
          `;
          values = [title, content, id, tutorialId];
      }

      // Otherwise, no existing id means it's an insert
      else {
          query = `
          INSERT INTO tutorial_sections ("title", "content", "tutorialId")
          VALUES ($1, $2, $3)
          `;
          values = [title, content, tutorialId];
      }

      return Client.executeQuery(query, values);
  });

  await Promise.all(sectionRequests);
};

/** Deletes any sections that from the tutorial that exist in the database but were not sent along with an update */

/*
 */

/***/ }),

/***/ "3WeD":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.searchParamsToUrlQuery = searchParamsToUrlQuery;
exports.urlQueryToSearchParams = urlQueryToSearchParams;
exports.assign = assign;

function searchParamsToUrlQuery(searchParams) {
  const query = {};
  searchParams.forEach((value, key) => {
    if (typeof query[key] === 'undefined') {
      query[key] = value;
    } else if (Array.isArray(query[key])) {
      ;
      query[key].push(value);
    } else {
      query[key] = [query[key], value];
    }
  });
  return query;
}

function stringifyUrlQueryParam(param) {
  if (typeof param === 'string' || typeof param === 'number' && !isNaN(param) || typeof param === 'boolean') {
    return String(param);
  } else {
    return '';
  }
}

function urlQueryToSearchParams(urlQuery) {
  const result = new URLSearchParams();
  Object.entries(urlQuery).forEach(([key, value]) => {
    if (Array.isArray(value)) {
      value.forEach(item => result.append(key, stringifyUrlQueryParam(item)));
    } else {
      result.set(key, stringifyUrlQueryParam(value));
    }
  });
  return result;
}

function assign(target, ...searchParamsList) {
  searchParamsList.forEach(searchParams => {
    Array.from(searchParams.keys()).forEach(key => target.delete(key));
    searchParams.forEach((value, key) => target.append(key, value));
  });
  return target;
}

/***/ }),

/***/ "3qNE":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, "a", function() { return /* reexport */ tutorials_TutorialDAO; });

// EXTERNAL MODULE: ./server/database/knex.ts
var knex = __webpack_require__("CaIY");

// EXTERNAL MODULE: ./server/dataAccess/tag/entity.ts + 1 modules
var entity = __webpack_require__("M4QR");

// EXTERNAL MODULE: ./server/dataAccess/tutorialSection/entity.ts
var tutorialSection_entity = __webpack_require__("IzFH");

// CONCATENATED MODULE: ./server/dataAccess/tutorials/index.ts



class tutorials_TutorialDAO {
  static async listTutorials() {
    return await knex["a" /* Knex */].select('*').from('tutorials').where('enabled', true);
  }

  static async findTutorial(prop, val) {
    const tutorials = await knex["a" /* Knex */].select('*').from('tutorials').where(prop, val);
    return tutorials.shift();
  }

  static async addTutorial(props, userId) {
    const addedTutorials = await Object(knex["a" /* Knex */])('tutorials').insert({
      title: props.title,
      color: props.color,
      description1: props.description1,
      description2: props.description2,
      enabled: props.enabled,
      featuredImage: props.featuredImage,
      codeUrl: props.codeUrl,
      liveUrl: props.liveUrl,
      slug: props.slug,
      userId: userId
    }).returning('*');
    const addedTutorial = addedTutorials.shift(); // If there's tags to associate

    if (props.tags.length > 0) {
      await entity["a" /* TagDB */].relateWithTutorial(props.tags, addedTutorial.id);
    } // If there's sections to write


    if (props.sections.length > 0) {
      await tutorialSection_entity["a" /* TutorialSectionDB */].addOrUpdateTutorialSection(props.sections, addedTutorial.id);
    }

    return addedTutorial;
  }

  static async updateTutorial(props, userId) {
    // Update the main tutorial information
    const updatedTutorial = await Object(knex["a" /* Knex */])('tutorials').where({
      'id': props.id,
      'userId': userId
    }).update({
      title: props.title,
      color: props.color,
      description1: props.description1,
      description2: props.description2,
      enabled: props.enabled,
      featuredImage: props.featuredImage,
      codeUrl: props.codeUrl,
      liveUrl: props.liveUrl,
      slug: props.slug,
      userId: userId
    }).returning('*'); // If there's tags to associate

    await entity["a" /* TagDB */].relateWithTutorial(props.tags, props.id); // If there's sections to add, update, or delete

    await tutorialSection_entity["a" /* TutorialSectionDB */].addOrUpdateTutorialSection(props.sections, props.id);
    return updatedTutorial.shift();
  }

  /** Deletes tutorial with the given tutorial id belonging to the specified user id */
  static async deleteTutorial(tutorialId, userId) {
    // Delete this tutorial from any user planner
    await Object(knex["a" /* Knex */])('planner_detail').delete().where({
      tutorialId
    }); // Delete section progress for any section belonging to this tutorial

    await knex["a" /* Knex */].raw(`
        DELETE
        FROM
            tutorial_sections_progress
        WHERE
            "sectionId" in (
                SELECT id
                FROM
                    tutorial_sections
                WHERE
                    "tutorialId" = '${tutorialId}'
            )
        `); // Delete sections belonging to this tutorial

    await Object(knex["a" /* Knex */])('tutorial_sections').delete().where({
      tutorialId
    }); // Delete tags associated to this tutorial

    await Object(knex["a" /* Knex */])('tutorial_tag_relations').delete().where({
      tutorialId
    }); // Delete this tutorial

    const response = await Object(knex["a" /* Knex */])('tutorials').where('id', tutorialId).del();

    if (response == 1) {
      return {
        id: tutorialId
      };
    } // Otherwise, unable to delete tutorial so raise error


    throw Error(`Unable to delete tutorial with ID ${tutorialId}`);
  }

  /** Returns the tags associated with a specific tutorial */
  static async getTags(tutorialId) {
    const tags = await knex["a" /* Knex */].raw(`
            SELECT id, tag
            FROM tags
            INNER JOIN tutorial_tag_relations
            ON tags.id = tutorial_tag_relations."tagId"
            WHERE tutorial_tag_relations."tutorialId" = ${tutorialId}
            `);
    return tags.rows;
  }

  static async getTutorialForEditing(userId, tutorialId) {
    // This means only retrieve the requested tutorial
    // as the user is trying to edit it
    if (tutorialId) {
      const editableTutorial = await Object(knex["a" /* Knex */])('tutorials').select('title', 'description1', 'description2', 'enabled', 'color', 'featuredImage', 'liveUrl', 'codeUrl', 'id', 'slug').where({
        id: tutorialId,
        userId: userId
      });
      return editableTutorial;
    } // Otherwise, all editable tutorials need to be shown, for the list page


    const editableTutorials = await Object(knex["a" /* Knex */])('tutorials').select('title', 'description1', 'description2', 'enabled', 'color', 'featuredImage', 'id', 'slug').where({
      userId: userId
    }); // Set up promises for fetching the tags

    const tagPromises = editableTutorials.map(tutorial => tutorials_TutorialDAO.getTags(tutorial.id));
    const tagResults = await Promise.all(tagPromises); // Set the tags into each

    editableTutorials.forEach((editableTutorial, index) => {
      editableTutorial['tags'] = tagResults[index];
    });
    return editableTutorials;
  }

  static async getSiteTutorials() {
    const siteTutorials = await knex["a" /* Knex */].raw(`
            SELECT 
        t."title", 
        t."description1",   
        t."description2", 
        t."color", 
        t."featuredImage", 
        t."id", 
        t."slug",
        u."profileImage", 
        u."name",
        uai."username"
        FROM tutorials t
        INNER JOIN user_information u 
        ON u."id" = t."userId"
        INNER JOIN user_account_information uai
        on uai."userId" = t."userId"
        WHERE t."enabled" = true
        `);
    return siteTutorials.rows;
  }

}
;
// CONCATENATED MODULE: ./server/dataAccess/tutorials/entity.ts


/***/ }),

/***/ "3wub":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.normalizeLocalePath = normalizeLocalePath;

function normalizeLocalePath(pathname, locales) {
  let detectedLocale; // first item will be empty string from splitting at first char

  const pathnameParts = pathname.split('/');
  (locales || []).some(locale => {
    if (pathnameParts[1].toLowerCase() === locale.toLowerCase()) {
      detectedLocale = locale;
      pathnameParts.splice(1, 1);
      pathname = pathnameParts.join('/') || '/';
      return true;
    }

    return false;
  });
  return {
    pathname,
    detectedLocale
  };
}

/***/ }),

/***/ "4AIp":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return UserSnip; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;
;
const UserSnip = ({
  profileImageUrl,
  name,
  username,
  usePadding = true
}) => {
  const padClass = usePadding ? 'fill' : '';
  return __jsx("div", {
    className: `user-snip ${padClass}`
  }, __jsx("img", {
    src: profileImageUrl,
    className: "user-snip__avi"
  }), name && username && __jsx("div", {
    className: "user-snip__details"
  }, __jsx("p", null, name), __jsx("p", {
    className: "user-snip__username"
  }, "@", username)));
};

/***/ }),

/***/ "4Q3z":
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "64Oa":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, "a", function() { return /* reexport */ planner_PlannerDAO; });

// EXTERNAL MODULE: ./server/database/knex.ts
var knex = __webpack_require__("CaIY");

// EXTERNAL MODULE: ./server/dataAccess/tutorialSection/index.ts
var tutorialSection = __webpack_require__("2v0O");

// EXTERNAL MODULE: ./server/dataAccess/tutorialProgress/index.ts
var tutorialProgress = __webpack_require__("QYdn");

// CONCATENATED MODULE: ./server/dataAccess/planner/index.ts



class planner_PlannerDAO {
  /** Creates the planner entry for the user */
  static async createPlanner(userId) {
    const planner = await Object(knex["a" /* Knex */])('planner').insert({
      userId: userId
    }).returning('*');
    return planner.shift();
  }

  /** Retrieve all tutorials belonging to this user */
  static async retrieveTutorials(userId) {
    const tutorialsInPlanner = await knex["a" /* Knex */].raw(`
        SELECT 
        -- top level fields
        t."title", 
        t."description2", 
        t."featuredImage", 
        t."slug", 
        COUNT(ts."tutorialId") as "totalSectionCount",

        (
            SELECT COUNT(tsp."sectionId") 
            FROM tutorial_sections_progress tsp 
            WHERE tsp."sectionId" in 
            (
                SELECT "id"
                FROM tutorial_sections ts
                WHERE 
                    ts."tutorialId" = t."id"
                    AND 
                    tsp."isComplete" = true
                    AND
                    "userId" = ${userId}
            )
        ) AS "completedSectionCount"

        -- get the tutorial ids belonging to the user's planner
        FROM tutorials t
        INNER JOIN tutorial_sections ts
        ON t."id" = ts."tutorialId"
        WHERE t."id" IN 
        (
            SELECT "tutorialId" 
            FROM planner_detail
            WHERE planner_detail."plannerId" = 
            (
                SELECT "id"
                FROM planner p
                WHERE p."userId" = ${userId}
            )
        )

        GROUP BY
            t."title", 
            t."description2", 
            t."featuredImage", 
            t."slug", 
            "completedSectionCount"     
    `);
    return tutorialsInPlanner.rows;
  }

  /** Get the id of the planner belonging to the user */
  static async getPlannerId(userId) {
    const plannerIdRes = await Object(knex["a" /* Knex */])('planner').select('id').from('planner').where('userId', userId);
    const {
      id
    } = plannerIdRes.shift();
    return id;
  }

  /** Register this tutorial into the user's planner */
  static async registerTutorial(tutorialId, plannerId, userId) {
    const registeredTutorial = await Object(knex["a" /* Knex */])('planner_detail').insert({
      plannerId: plannerId,
      tutorialId: tutorialId
    }).returning('*');
    return registeredTutorial.shift();
  }

  /** Unregisters this tutorial from a user's planner */
  static async unregisterTutorial(tutorialId, plannerId, userId) {
    // Remove this tutorial from the planner
    await Object(knex["a" /* Knex */])('planner_detail').where({
      tutorialId,
      plannerId
    }).delete(); // Unregister all of its sections from  the tutorial section progress table

    const sectionIds = await tutorialSection["a" /* TutorialSectionDAO */].listTutorialSectionIds(tutorialId);
    const unregistrations = sectionIds.map(sectionId => tutorialProgress["a" /* TutorialProgressDAO */].unregisterSection(sectionId, userId));
    await Promise.all(unregistrations);
  }

  /** Check if the tutorial (by id) is already registered in the planner */
  static async isTutorialRegistered(tutorialId, plannerId) {
    const isTutorialAlreadyRegisteredRes = await Object(knex["a" /* Knex */])('planner_detail').select('*').where('tutorialId', tutorialId).andWhere('plannerId', plannerId);
    const isTutorialAlreadyRegistered = isTutorialAlreadyRegisteredRes.length > 0 ? true : false;
    return isTutorialAlreadyRegistered;
  }

  /** Returns the number of planners that have registered this tutorial */
  static async getRegisteredCount(tutorialId) {
    const totalRegisteredCountRes = await Object(knex["a" /* Knex */])('planner_detail').count('plannerId').where('tutorialId', tutorialId);
    const count = parseInt(totalRegisteredCountRes.shift().count.toString());
    return count;
  }

}
;
// CONCATENATED MODULE: ./server/dataAccess/planner/entity.ts


/***/ }),

/***/ "6D7l":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.formatUrl = formatUrl;

var querystring = _interopRequireWildcard(__webpack_require__("3WeD"));

function _getRequireWildcardCache() {
  if (typeof WeakMap !== "function") return null;
  var cache = new WeakMap();

  _getRequireWildcardCache = function () {
    return cache;
  };

  return cache;
}

function _interopRequireWildcard(obj) {
  if (obj && obj.__esModule) {
    return obj;
  }

  if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
    return {
      default: obj
    };
  }

  var cache = _getRequireWildcardCache();

  if (cache && cache.has(obj)) {
    return cache.get(obj);
  }

  var newObj = {};
  var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;

  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;

      if (desc && (desc.get || desc.set)) {
        Object.defineProperty(newObj, key, desc);
      } else {
        newObj[key] = obj[key];
      }
    }
  }

  newObj.default = obj;

  if (cache) {
    cache.set(obj, newObj);
  }

  return newObj;
} // Format function modified from nodejs
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.


const slashedProtocols = /https?|ftp|gopher|file/;

function formatUrl(urlObj) {
  let {
    auth,
    hostname
  } = urlObj;
  let protocol = urlObj.protocol || '';
  let pathname = urlObj.pathname || '';
  let hash = urlObj.hash || '';
  let query = urlObj.query || '';
  let host = false;
  auth = auth ? encodeURIComponent(auth).replace(/%3A/i, ':') + '@' : '';

  if (urlObj.host) {
    host = auth + urlObj.host;
  } else if (hostname) {
    host = auth + (~hostname.indexOf(':') ? `[${hostname}]` : hostname);

    if (urlObj.port) {
      host += ':' + urlObj.port;
    }
  }

  if (query && typeof query === 'object') {
    query = String(querystring.urlQueryToSearchParams(query));
  }

  let search = urlObj.search || query && `?${query}` || '';
  if (protocol && protocol.substr(-1) !== ':') protocol += ':';

  if (urlObj.slashes || (!protocol || slashedProtocols.test(protocol)) && host !== false) {
    host = '//' + (host || '');
    if (pathname && pathname[0] !== '/') pathname = '/' + pathname;
  } else if (!host) {
    host = '';
  }

  if (hash && hash[0] !== '#') hash = '#' + hash;
  if (search && search[0] !== '?') search = '?' + search;
  pathname = pathname.replace(/[?#]/g, encodeURIComponent);
  search = search.replace('#', '%23');
  return `${protocol}${host}${pathname}${search}${hash}`;
}

/***/ }),

/***/ "7koQ":
/***/ (function(module, exports) {

module.exports = require("react-modal");

/***/ }),

/***/ "CaIY":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(__dirname) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Knex; });
/* harmony import */ var knex__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("SfJF");
/* harmony import */ var knex__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(knex__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("ebvM");


const KnexConfiguration = {
  development: {
    client: 'pg',
    connection: {
      host: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbHost,
      user: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbUser,
      password: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbPassword,
      database: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbName,
      port: 5432
    },
    migrations: {
      directory: __dirname + '/db/pg/migrations'
    },
    seeds: {
      directory: __dirname + '/db/pg/seeds/development'
    }
  },
  production: {
    client: 'pg',
    connection: {
      host: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbHost,
      user: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbUser,
      password: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbPassword,
      database: _utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dbName,
      ssl: true
    },
    migrations: {
      directory: __dirname + '/db/pg/migrations'
    },
    seeds: {
      directory: __dirname + '/db/pg/seeds/production'
    }
  }
};
const Knex = knex__WEBPACK_IMPORTED_MODULE_0___default()(KnexConfiguration[_utils_config__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].environment]);
/* WEBPACK VAR INJECTION */}.call(this, "/"))

/***/ }),

/***/ "Eyjp":
/***/ (function(module, exports) {

module.exports = require("shards-react");

/***/ }),

/***/ "GXs3":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.default = resolveRewrites;

function resolveRewrites() {}

/***/ }),

/***/ "IzFH":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("2v0O");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _index__WEBPACK_IMPORTED_MODULE_0__["a"]; });



/***/ }),

/***/ "KP9d":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/** Function for slugifying a passed string */
const slugify = text => {
  return text.toString().toLowerCase().replace(/\s+/g, '-') // Replace spaces with -
  .replace(/[^\w\-]+/g, '') // Remove all non-word chars
  .replace(/\-\-+/g, '-') // Replace multiple - with single -
  .replace(/^-+/, '') // Trim - from start of text
  .replace(/-+$/, ''); // Trim - from end of text
};

/* harmony default export */ __webpack_exports__["a"] = (slugify);

/***/ }),

/***/ "M4QR":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, "a", function() { return /* reexport */ tag_TagDAO; });

// EXTERNAL MODULE: ./server/database/knex.ts
var knex = __webpack_require__("CaIY");

// CONCATENATED MODULE: ./server/dataAccess/tag/index.ts

class tag_TagDAO {
  static async listTags() {
    return await knex["a" /* Knex */].select('*').from('tags');
  }

  static async findTag(prop, value) {
    return await knex["a" /* Knex */].select('*').from('tags').where(prop, value);
  }

  static async relateWithTutorial(tags, tutorialId) {
    // Add any tags that don't exist in the schema
    const insertableTags = tags.map(tag => {
      return {
        tag
      };
    });
    await Object(knex["a" /* Knex */])('tags').insert(insertableTags).onConflict('tag').ignore(); // Remove any tags that should no longer be associated with the tutorial

    await tag_TagDAO.validateWithTutorial(tags, tutorialId); // Get the ids for these tags

    const tagIds = await Object(knex["a" /* Knex */])('tags').select('id').whereIn('tag', tags); // Turn them into the tag/tutorial id pairs

    const tutorialTagPairs = tagIds.map(tagId => {
      return {
        tagId: tagId.id,
        tutorialId
      };
    });
    await Object(knex["a" /* Knex */])('tutorial_tag_relations').insert(tutorialTagPairs).onConflict(['tagId', 'tutorialId']).ignore();
  }

  static async validateWithTutorial(tags, tutorialId) {
    // Find out which tags are associated with this tutorial right now
    const tagsInDatabase = (await knex["a" /* Knex */].raw(`
        SELECT tags.tag, tags.id
        FROM tags
        INNER JOIN tutorial_tag_relations ttr
        ON 
            ttr."tagId" = tags.id
        WHERE 
            ttr."tutorialId" = ${tutorialId};
        `)).rows; // Any not provided, or any provided that aren't what the database has on record
    // means we need to remove from the database

    const tagIdsToRemove = tagsInDatabase.reduce((acc, tagItem) => {
      const tagShouldBeRemoved = !tags.find(tag => tag.toLowerCase() === tagItem.tag.toLowerCase());

      if (tagShouldBeRemoved && tagItem.hasOwnProperty('id')) {
        acc.push(tagItem.id);
      }

      return acc;
    }, []);

    if (tagIdsToRemove.length > 0) {
      await Object(knex["a" /* Knex */])('tutorial_tag_relations').delete().whereIn('tagId', tagIdsToRemove).andWhere({
        tutorialId
      });
    }
  }

}
;
// CONCATENATED MODULE: ./server/dataAccess/tag/entity.ts


/***/ }),

/***/ "N4Zu":
/***/ (function(module, exports) {

module.exports = require("prismjs");

/***/ }),

/***/ "Nh2W":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__("TqRt");

exports.__esModule = true;
exports.markAssetError = markAssetError;
exports.isAssetError = isAssetError;
exports.getClientBuildManifest = getClientBuildManifest;
exports.default = void 0;

var _getAssetPathFromRoute = _interopRequireDefault(__webpack_require__("UhrY"));

var _requestIdleCallback = __webpack_require__("0G5g"); // 3.8s was arbitrarily chosen as it's what https://web.dev/interactive
// considers as "Good" time-to-interactive. We must assume something went
// wrong beyond this point, and then fall-back to a full page transition to
// show the user something of value.


const MS_MAX_IDLE_DELAY = 3800;

function withFuture(key, map, generator) {
  let entry = map.get(key);

  if (entry) {
    if ('future' in entry) {
      return entry.future;
    }

    return Promise.resolve(entry);
  }

  let resolver;
  const prom = new Promise(resolve => {
    resolver = resolve;
  });
  map.set(key, entry = {
    resolve: resolver,
    future: prom
  });
  return generator ? // eslint-disable-next-line no-sequences
  generator().then(value => (resolver(value), value)) : prom;
}

function hasPrefetch(link) {
  try {
    link = document.createElement('link');
    return (// detect IE11 since it supports prefetch but isn't detected
      // with relList.support
      !!window.MSInputMethodContext && !!document.documentMode || link.relList.supports('prefetch')
    );
  } catch (_unused) {
    return false;
  }
}

const canPrefetch = hasPrefetch();

function prefetchViaDom(href, as, link) {
  return new Promise((res, rej) => {
    if (document.querySelector(`link[rel="prefetch"][href^="${href}"]`)) {
      return res();
    }

    link = document.createElement('link'); // The order of property assignment here is intentional:

    if (as) link.as = as;
    link.rel = `prefetch`;
    link.crossOrigin = undefined;
    link.onload = res;
    link.onerror = rej; // `href` should always be last:

    link.href = href;
    document.head.appendChild(link);
  });
}

const ASSET_LOAD_ERROR = Symbol('ASSET_LOAD_ERROR'); // TODO: unexport

function markAssetError(err) {
  return Object.defineProperty(err, ASSET_LOAD_ERROR, {});
}

function isAssetError(err) {
  return err && ASSET_LOAD_ERROR in err;
}

function appendScript(src, script) {
  return new Promise((resolve, reject) => {
    script = document.createElement('script'); // The order of property assignment here is intentional.
    // 1. Setup success/failure hooks in case the browser synchronously
    //    executes when `src` is set.

    script.onload = resolve;

    script.onerror = () => reject(markAssetError(new Error(`Failed to load script: ${src}`))); // 2. Configure the cross-origin attribute before setting `src` in case the
    //    browser begins to fetch.


    script.crossOrigin = undefined; // 3. Finally, set the source and inject into the DOM in case the child
    //    must be appended for fetching to start.

    script.src = src;
    document.body.appendChild(script);
  });
} // Resolve a promise that times out after given amount of milliseconds.


function resolvePromiseWithTimeout(p, ms, err) {
  return new Promise((resolve, reject) => {
    let cancelled = false;
    p.then(r => {
      // Resolved, cancel the timeout
      cancelled = true;
      resolve(r);
    }).catch(reject);
    (0, _requestIdleCallback.requestIdleCallback)(() => setTimeout(() => {
      if (!cancelled) {
        reject(err);
      }
    }, ms));
  });
} // TODO: stop exporting or cache the failure
// It'd be best to stop exporting this. It's an implementation detail. We're
// only exporting it for backwards compatibilty with the `page-loader`.
// Only cache this response as a last resort if we cannot eliminate all other
// code branches that use the Build Manifest Callback and push them through
// the Route Loader interface.


function getClientBuildManifest() {
  if (self.__BUILD_MANIFEST) {
    return Promise.resolve(self.__BUILD_MANIFEST);
  }

  const onBuildManifest = new Promise(resolve => {
    // Mandatory because this is not concurrent safe:
    const cb = self.__BUILD_MANIFEST_CB;

    self.__BUILD_MANIFEST_CB = () => {
      resolve(self.__BUILD_MANIFEST);
      cb && cb();
    };
  });
  return resolvePromiseWithTimeout(onBuildManifest, MS_MAX_IDLE_DELAY, markAssetError(new Error('Failed to load client build manifest')));
}

function getFilesForRoute(assetPrefix, route) {
  if (false) {}

  return getClientBuildManifest().then(manifest => {
    if (!(route in manifest)) {
      throw markAssetError(new Error(`Failed to lookup route: ${route}`));
    }

    const allFiles = manifest[route].map(entry => assetPrefix + '/_next/' + encodeURI(entry));
    return {
      scripts: allFiles.filter(v => v.endsWith('.js')),
      css: allFiles.filter(v => v.endsWith('.css'))
    };
  });
}

function createRouteLoader(assetPrefix) {
  const entrypoints = new Map();
  const loadedScripts = new Map();
  const styleSheets = new Map();
  const routes = new Map();

  function maybeExecuteScript(src) {
    let prom = loadedScripts.get(src);

    if (prom) {
      return prom;
    } // Skip executing script if it's already in the DOM:


    if (document.querySelector(`script[src^="${src}"]`)) {
      return Promise.resolve();
    }

    loadedScripts.set(src, prom = appendScript(src));
    return prom;
  }

  function fetchStyleSheet(href) {
    let prom = styleSheets.get(href);

    if (prom) {
      return prom;
    }

    styleSheets.set(href, prom = fetch(href).then(res => {
      if (!res.ok) {
        throw new Error(`Failed to load stylesheet: ${href}`);
      }

      return res.text().then(text => ({
        href: href,
        content: text
      }));
    }).catch(err => {
      throw markAssetError(err);
    }));
    return prom;
  }

  return {
    whenEntrypoint(route) {
      return withFuture(route, entrypoints);
    },

    onEntrypoint(route, execute) {
      Promise.resolve(execute).then(fn => fn()).then(exports => ({
        component: exports && exports.default || exports,
        exports: exports
      }), err => ({
        error: err
      })).then(input => {
        const old = entrypoints.get(route);
        entrypoints.set(route, input);
        if (old && 'resolve' in old) old.resolve(input);
      });
    },

    loadRoute(route) {
      return withFuture(route, routes, async () => {
        try {
          const {
            scripts,
            css
          } = await getFilesForRoute(assetPrefix, route);
          const [, styles] = await Promise.all([entrypoints.has(route) ? [] : Promise.all(scripts.map(maybeExecuteScript)), Promise.all(css.map(fetchStyleSheet))]);
          const entrypoint = await resolvePromiseWithTimeout(this.whenEntrypoint(route), MS_MAX_IDLE_DELAY, markAssetError(new Error(`Route did not complete loading: ${route}`)));
          const res = Object.assign({
            styles
          }, entrypoint);
          return 'error' in entrypoint ? entrypoint : res;
        } catch (err) {
          return {
            error: err
          };
        }
      });
    },

    prefetch(route) {
      // https://github.com/GoogleChromeLabs/quicklink/blob/453a661fa1fa940e2d2e044452398e38c67a98fb/src/index.mjs#L115-L118
      // License: Apache 2.0
      let cn;

      if (cn = navigator.connection) {
        // Don't prefetch if using 2G or if Save-Data is enabled.
        if (cn.saveData || /2g/.test(cn.effectiveType)) return Promise.resolve();
      }

      return getFilesForRoute(assetPrefix, route).then(output => Promise.all(canPrefetch ? output.scripts.map(script => prefetchViaDom(script, 'script')) : [])).then(() => {
        (0, _requestIdleCallback.requestIdleCallback)(() => this.loadRoute(route));
      }).catch( // swallow prefetch errors
      () => {});
    }

  };
}

var _default = createRouteLoader;
exports.default = _default;

/***/ }),

/***/ "Osoz":
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/router-context.js");

/***/ }),

/***/ "P808":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, "getServerSideProps", function() { return /* binding */ getServerSideProps; });

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: ./src/features/layout/layout.tsx + 7 modules
var layout = __webpack_require__("jYMq");

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__("4Q3z");

// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__("zr5I");
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);

// EXTERNAL MODULE: ./src/constants/slugify.ts
var slugify = __webpack_require__("KP9d");

// EXTERNAL MODULE: ./src/components/tagItem/tagItem.tsx
var tagItem = __webpack_require__("V9y6");

// CONCATENATED MODULE: ./src/features/tutorial/tutorialHeader/tutorialHeader.tsx

var __jsx = external_react_default.a.createElement;

const TutorialHeader = props => {
  const {
    title,
    tags,
    featuredImage,
    color,
    author
  } = props;
  return __jsx("header", {
    className: `tutorial-header ${color.toLowerCase()}`
  }, __jsx("div", {
    className: "tutorial-header__image"
  }, featuredImage.length > 0 && __jsx("img", {
    className: "featured-image",
    src: featuredImage
  })), __jsx("ul", {
    className: "tutorial-header__tags"
  }, tags.map((tag, index) => __jsx(tagItem["a" /* TagItem */], {
    tagId: tag.id,
    tagName: tag.tag,
    key: `${index}__${tag.id}`
  }))), __jsx("h1", {
    className: "tutorial-header__title"
  }, title));
};
// EXTERNAL MODULE: external "react-markdown"
var external_react_markdown_ = __webpack_require__("id0+");
var external_react_markdown_default = /*#__PURE__*/__webpack_require__.n(external_react_markdown_);

// EXTERNAL MODULE: external "prismjs"
var external_prismjs_ = __webpack_require__("N4Zu");
var external_prismjs_default = /*#__PURE__*/__webpack_require__.n(external_prismjs_);

// CONCATENATED MODULE: ./src/features/tutorial/tutorialSection/tutorialSection.tsx

var tutorialSection_jsx = external_react_default.a.createElement;



const TutorialSection = props => {
  Object(external_react_["useEffect"])(() => {
    external_prismjs_default.a.highlightAll();
  }, []);
  const {
    slug,
    progressCheck
  } = props;
  const {
    title,
    content
  } = props.content;
  return tutorialSection_jsx("section", {
    className: "section line-numbers"
  }, tutorialSection_jsx("h2", {
    id: slug
  }, title), tutorialSection_jsx(external_react_markdown_default.a, {
    className: "section__text",
    source: content,
    linkTarget: "_blank"
  }), tutorialSection_jsx("div", {
    className: "section__progress"
  }, tutorialSection_jsx("hr", {
    className: "progress-rule"
  }), progressCheck));
};
// CONCATENATED MODULE: ./src/features/tutorial/colorBox/colorBox.tsx

var colorBox_jsx = external_react_default.a.createElement;
;
const ColorBox = ({
  title,
  children
}) => {
  return colorBox_jsx("div", {
    className: "color-box"
  }, colorBox_jsx("span", {
    className: "color-box__title"
  }, title), colorBox_jsx("div", {
    className: "color-box__content"
  }, children));
};
// CONCATENATED MODULE: ./src/features/tutorial/sectionBar/sectionBar.tsx

var sectionBar_jsx = external_react_default.a.createElement;

const SectionBar = ({
  sectionInformation
}) => {
  return sectionBar_jsx(ColorBox, {
    title: "Tutorial Content \uD83D\uDCDA"
  }, sectionBar_jsx("div", {
    className: "section-bar"
  }, sectionBar_jsx("ul", null, sectionInformation.map((section, index) => sectionBar_jsx("li", {
    key: index
  }, sectionBar_jsx("a", {
    href: `#${section.slug}`
  }, section.title))))));
};
// CONCATENATED MODULE: ./src/components/custom/CustomIcon.tsx

var CustomIcon_jsx = external_react_default.a.createElement;
const CustomIcon = props => {
  const {
    icon,
    color,
    onClick,
    stacked
  } = props;
  const shouldStack = stacked == true || stacked == undefined ? true : false;
  let className = shouldStack ? `fa-stack fa-2x circle` : '';
  return CustomIcon_jsx("span", {
    className: `${className}`,
    onClick: () => {
      onClick();
    }
  }, shouldStack && CustomIcon_jsx("i", {
    className: `fas fa-circle fa-stack-2x bg`,
    style: {
      color
    }
  }), CustomIcon_jsx("i", {
    className: `${icon} fa-stack-1x fa-inverse fg`
  }));
};
// CONCATENATED MODULE: ./src/components/custom/ShareGenerator.ts
const sharePlatforms = {
  FACEBOOK: 'FACEBOOK',
  TWITTER: 'TWITTER',
  PINTEREST: 'PINTEREST',
  EMAIL: 'EMAIL',
  LINKEDIN: 'LINKEDIN',
  COPY_URL: 'COPY_URL'
};
/** Generates the shareable link for a page. Link should be off base url of the site
 * @param {string} link - link to be shared
 * @param {string} title - accompanying title for the shared page
 * @param {string} text - text to supplement share (optional)
 */

const createShareForPlatform = (link, title, platform, text) => {
  const shareableText = generateShareableText(link, title, text);
  const shareableLink = generateSharePlatformLink(platform, shareableText);
  return shareableLink;
};
/** Generates the Zerochass url for the passed link
 * @param {string} link - link to be shared
 */

const createUrl = link => {
  return `${"https://zerochass.io"}/${link}`;
};

const generateShareableText = (link, title, text) => {
  // Setup share items
  const url = createUrl(link);
  const companyName = `Zerochass`;
  const hashtags = ['Zerochass', 'WebDevelopment', 'SoftwareEngineering'];
  hashtags.push(`${companyName.split(' ').join('').split('-').join('')}`);
  return {
    url,
    title,
    companyName,
    hashtags,
    text
  };
};
/** Generates the sharing link for the specified platform
 * @param {string} platform - platform to share on
 * @param {object} shareObject - share object containing items needed for sharing
 */


const generateSharePlatformLink = (platform, {
  url,
  title,
  companyName,
  hashtags,
  text
}) => {
  switch (platform) {
    case sharePlatforms.FACEBOOK:
      {
        return `https://www.facebook.com/sharer/sharer.php?u=${url}`;
      }

    case sharePlatforms.TWITTER:
      {
        const shareText = text.split(' ').join('+');
        const via = `zerochass`;
        return `https://twitter.com/intent/tweet?&text=${shareText}&via=${via}&url=${url}&hashtags=${hashtags.join()}`;
      }

    case sharePlatforms.EMAIL:
      {
        const body = `${title} – ${url}`;
        return `mailto:?body=${body}&subject=${title}`;
      }

    case sharePlatforms.LINKEDIN:
      {
        return `https://www.linkedin.com/shareArticle?mini=true&url=${url}&title=${title}`;
      }

    case sharePlatforms.COPY_URL:
      {
        return url;
      }

    /* case sharePlatforms.PINTEREST: {
        return `http://pinterest.com/pin/create/link/?url=${encodeURIComponent(url)}&description=${encodeURIComponent(title)}&media=${encodeURIComponent(imageUrl)}`
    } */

    default:
      return null;
  }
};
// CONCATENATED MODULE: ./src/components/shareButtons/shareButtons.tsx

var shareButtons_jsx = external_react_default.a.createElement;


const ShareButtons = props => {
  const {
    title,
    link,
    text
  } = props;

  const share = platform => {
    const shareLink = createShareForPlatform(link, title, platform, text);
    window.open(shareLink, '_blank');
  };

  const shareTwitter = () => {
    share("TWITTER");
  };

  const shareFacebook = () => {
    share("FACEBOOK");
  };

  const shareLinkedIn = () => {
    share("LINKEDIN");
  };

  return shareButtons_jsx("div", {
    className: "share-btns"
  }, shareButtons_jsx(CustomIcon, {
    icon: `fab fa-facebook-f`,
    color: `#4267B2`,
    onClick: shareFacebook
  }), shareButtons_jsx(CustomIcon, {
    icon: `fab fa-twitter`,
    color: `#1DA1F2`,
    onClick: shareTwitter
  }), shareButtons_jsx(CustomIcon, {
    icon: `fab fa-linkedin-in`,
    color: `#0072b1`,
    onClick: shareLinkedIn
  }));
};
// CONCATENATED MODULE: ./src/features/tutorial/shareBar/shareBar.tsx

var shareBar_jsx = external_react_default.a.createElement;



const ShareBar = props => {
  const {
    0: value,
    1: setValue
  } = Object(external_react_["useState"])('');
  const {
    0: typed,
    1: setTyped
  } = Object(external_react_["useState"])(false);
  const {
    tutorialTitle,
    slug
  } = props;
  const taText = `I just started a tutorial at zerochass.io! \n\nSo excited to begin learning about "${tutorialTitle}"`;

  const onChange = event => {
    if (!typed) {
      setTyped(true);
    } // Update the value


    const {
      value
    } = event.target;
    setValue(value);
  };

  const onFocus = event => {
    if (!typed || value.length == 0) {
      setValue(taText);
    }
  };

  const onBlur = event => {
    if (value === taText) {
      setValue('');
    }
  };

  return shareBar_jsx(ColorBox, {
    title: "Share \uD83D\uDE80"
  }, shareBar_jsx("div", {
    className: "tutorial-share-bar"
  }, shareBar_jsx("span", {
    className: "box-subtitle"
  }, "Tell all your friends!"), shareBar_jsx("textarea", {
    className: "box-text-area",
    rows: 6,
    cols: 30,
    placeholder: taText,
    onFocus: onFocus,
    onBlur: onBlur,
    value: value,
    onChange: onChange
  }), shareBar_jsx(ShareButtons, {
    link: `tutorial/${slug}`,
    title: tutorialTitle,
    text: taText
  })));
};
// CONCATENATED MODULE: ./src/features/tutorial/progressCheck/progressCheck.tsx

var progressCheck_jsx = external_react_default.a.createElement;
const ProgressCheck = props => {
  let progressClass = '';

  switch (props.sectionComplete) {
    case false:
      progressClass = 'not-started';
      break;

    case null:
      progressClass = 'in-progress';
      break;

    case true:
      progressClass = 'completed';
      break;

    default:
      progressClass = '';
      break;
  }

  const {
    onProgressClick,
    index,
    sectionId
  } = props;
  return progressCheck_jsx("span", {
    id: "progress-span",
    className: "fa-stack fa-2x",
    onClick: () => onProgressClick(sectionId)
  }, progressCheck_jsx("i", {
    className: `fas fa-circle fa-stack-2x ${progressClass}-bg`
  }), progressCheck_jsx("i", {
    className: `fas fa-check fa-stack-1x fa-inverse ${progressClass}-fg`,
    style: {
      fontSize: '38px'
    }
  }));
};
// EXTERNAL MODULE: ./src/components/contexts.tsx
var contexts = __webpack_require__("Ti4I");

// EXTERNAL MODULE: ./src/components/userSnippet/userSnippet.tsx
var userSnippet = __webpack_require__("4AIp");

// CONCATENATED MODULE: ./src/features/tutorial/tutorial.tsx

var tutorial_jsx = external_react_default.a.createElement;












const Tutorial = ({
  tutorial,
  author
}) => {
  if (!tutorial) return tutorial_jsx(external_react_default.a.Fragment, null);
  let previousEntry, nextEntry;
  const {
    title,
    tags,
    featuredImage,
    color,
    sections,
    description1,
    description2,
    slug,
    codeUrl,
    liveUrl
  } = tutorial;
  const {
    0: sectionRefs,
    1: setSectionRefs
  } = Object(external_react_["useState"])([]);
  const {
    0: sectionInformation,
    1: setSectionInformation
  } = Object(external_react_["useState"])([]);
  const {
    0: isTutorialRegistered,
    1: setIsTutorialRegistered
  } = Object(external_react_["useState"])(null);
  const {
    0: sectionProgress,
    1: setSectionProgress
  } = Object(external_react_["useState"])([]);
  const {
    isAuthenticated,
    toggleAuthenticationModal
  } = Object(external_react_["useContext"])(contexts["a" /* AuthenticationContext */]);
  const router = Object(router_["useRouter"])();
  /** Effects to occur on mount */

  Object(external_react_["useEffect"])(() => {
    // Generate the section bar content
    generateSectionBarContent(); // If this tutorial is part of a series, set up the next - prev links

    if (tutorial.hasOwnProperty("parent")) {
      setupTutorialSeries();
    } // Retrieve information on the user's progress with this tutorial


    if (isAuthenticated) {
      retrieveTutorialProgress();
    }
  }, [isAuthenticated]);
  /** Effects to occur when section information changes */

  Object(external_react_["useEffect"])(() => {
    // Add refs and set them
    const refs = sectionInformation.map((s, i) => sectionRefs[i] || /*#__PURE__*/Object(external_react_["createRef"])());
    setSectionRefs(refs);
  }, [sectionInformation]);
  /** Iterates through each tutorial section to set up content for the Sections Bar */

  const generateSectionBarContent = () => {
    const {
      sections
    } = tutorial;
    const sectionInformation = [];
    sections.forEach(section => {
      const {
        title,
        id
      } = section;
      const slug = Object(slugify["a" /* default */])(title);
      const meta = {
        title,
        id,
        slug,
        sectionComplete: false
      };
      sectionInformation.push(meta);
    });
    setSectionInformation(sectionInformation);
  };

  const setupTutorialSeries = () => {
    const entries = tutorial.parent.children; // Locate this entry in the entries list

    const thisEntryIndex = entries.findIndex(entry => {
      return tutorial.id === entry.id;
    }); // Check if a previous entry would exist

    if (entries[thisEntryIndex - 1]) {
      // Get the title and slug
      const {
        title
      } = entries[thisEntryIndex - 1];
      const link = Object(slugify["a" /* default */])(title);
      previousEntry = {
        title,
        link
      };
    } // Check if a next entry would exist


    if (entries[thisEntryIndex + 1]) {
      // Get the title and slug
      const {
        title
      } = entries[thisEntryIndex + 1];
      const link = Object(slugify["a" /* default */])(title);
      nextEntry = {
        title,
        link
      };
    }
  };
  /** Handles scrolling to the next proceeding section during a progress checkmark click */


  const onProgressClick = async sectionId => {
    const sectionIndexToUpdate = sectionInformation.findIndex(section => section.id == sectionId);
    const sectionToUpdate = sectionInformation[sectionIndexToUpdate];
    const nextSectionIndex = sectionIndexToUpdate + 1; // Handles scrolling the page down to the next section

    if (nextSectionIndex !== sectionInformation.length) {
      // The offset on each scroll
      const yOffset = -80;
      const element = sectionRefs[nextSectionIndex].current; // Scroll down to the next item

      const y = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({
        top: y,
        behavior: "smooth"
      });
    } // If the tutorial page isn't a preview, we'll trigger actions on progress click


    if (!router.query.hasOwnProperty("preview")) {
      // If the user is authenticated
      // let's also mark this section complete/incomplete for them
      if (isAuthenticated) {
        // If the section is complete, it should be marked to false
        // Otherwise, if it's not complete, it should be marked to true
        const complete = sectionToUpdate.sectionComplete ? false : true;
        const {
          isComplete
        } = (await external_axios_default()({
          url: `/api/sections/${sectionId}`,
          method: "POST",
          data: {
            complete
          }
        })).data;
      } // Otherwise, toggle the auth modal
      else {
          /* toggleAuthenticationModal(); */
        }
    }

    sectionToUpdate.sectionComplete = !sectionToUpdate.sectionComplete;
    setSectionInformation([...sectionInformation]);
  };
  /** Handles enrolling a user into the tutorial */


  const onEnrollClick = async () => {
    // The user should become unenrolled if the tutorial is registered
    // and they should be enrolled if the tutorial is not already registered
    const shouldBeEnrolled = isTutorialRegistered ? false : true;
    const {
      isTutorialRegistered: updatedRegistration
    } = (await external_axios_default()({
      url: "/api/planner/enroll",
      method: "POST",
      data: {
        tutorialId: tutorial.id,
        shouldBeEnrolled
      }
    })).data;
    setIsTutorialRegistered(updatedRegistration);
  };
  /** Retrieves information on the user's progress with this tutorial */


  const retrieveTutorialProgress = async () => {
    const {
      isTutorialRegistered,
      sectionProgress
    } = (await external_axios_default()({
      url: `/api/planner/enroll?tutorialId=${tutorial.id}`,
      method: "GET"
    })).data; // Use the section progress to update the progress of the tutorial sections

    sectionProgress.forEach(sp => {
      // Find the corresponding section
      const correspondingSection = sectionInformation.find(section => section.id === sp.sectionId); // If there's a correspond section, have it reflect the progress for the user

      if (correspondingSection) {
        correspondingSection.sectionComplete = sp.isComplete;
      }
    });
    setSectionInformation([...sectionInformation]);
    setIsTutorialRegistered(isTutorialRegistered);
  };

  return tutorial_jsx("article", {
    className: "tutorial-page"
  }, tutorial_jsx("div", {
    className: "tutorial-page__header"
  }, tutorial_jsx(TutorialHeader, {
    title: title,
    tags: tags,
    featuredImage: featuredImage,
    color: color,
    author: author
  })), tutorial_jsx("div", {
    className: "tutorial-page__body"
  }, tutorial_jsx("div", {
    className: "side-bar-column"
  }, tutorial_jsx(ColorBox, {
    title: "Posted By ✏️"
  }, tutorial_jsx(userSnippet["a" /* UserSnip */], {
    username: author.username,
    name: author.name,
    profileImageUrl: author.profileImage
  })), (liveUrl || codeUrl) && tutorial_jsx(ColorBox, {
    title: "Links 🔗"
  }, tutorial_jsx("div", {
    className: "tutorial-links"
  }, liveUrl && tutorial_jsx("a", {
    href: liveUrl,
    target: "_blank"
  }, "Live Site \uD83D\uDCBB"), codeUrl && tutorial_jsx("a", {
    href: codeUrl,
    target: "_blank"
  }, "Code Repository \uD83D\uDCDD"))), tutorial_jsx(SectionBar, {
    sectionInformation: sectionInformation
  }), tutorial_jsx(ShareBar, {
    tutorialTitle: title,
    slug: slug
  })), tutorial_jsx("div", {
    className: "sections"
  }, sections.map((section, index) => {
    const sectionComplete = sectionInformation.length > 0 ? sectionInformation[index].sectionComplete : null; // Slugify the title

    const slug = Object(slugify["a" /* default */])(section.title); // Build the Progress Check component

    const progressCheck = tutorial_jsx(ProgressCheck, {
      sectionId: section.id,
      index: index // If the user is authenticated - track progress, otherwise, display the auth modal
      ,
      onProgressClick: onProgressClick,
      sectionComplete: sectionComplete
    }); // Return the composed Section component


    return tutorial_jsx("div", {
      className: "section-item",
      key: index,
      ref: sectionRefs[index]
    }, tutorial_jsx(TutorialSection, {
      content: section,
      key: index,
      slug: slug,
      progressCheck: progressCheck
    }));
  }))));
};
// EXTERNAL MODULE: ./server/dataAccess/tutorials/entity.ts + 1 modules
var entity = __webpack_require__("3qNE");

// EXTERNAL MODULE: ./server/dataAccess/tutorialSection/entity.ts
var tutorialSection_entity = __webpack_require__("IzFH");

// EXTERNAL MODULE: ./server/dataAccess/planner/entity.ts + 1 modules
var planner_entity = __webpack_require__("64Oa");

// EXTERNAL MODULE: ./server/dataAccess/user/entity.ts + 1 modules
var user_entity = __webpack_require__("QnN6");

// CONCATENATED MODULE: ./src/pages/tutorial/[slug].tsx

var _slug_jsx = external_react_default.a.createElement;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







;

const TutorialPage = ({
  tutorial,
  author
}) => {
  const {
    tags,
    description1,
    description2,
    featuredImage,
    slug
  } = tutorial;
  const keywords = tags.map(tag => tag.title).join();
  const descriptions = `${description1} ${description2}`;
  return _slug_jsx(layout["a" /* Layout */], {
    pageTitle: tutorial.title,
    description: descriptions,
    keywords: keywords,
    slug: `tutorial/${slug}`,
    image: featuredImage,
    large: true
  }, _slug_jsx(Tutorial, {
    tutorial: tutorial,
    author: author
  }));
};

const getServerSideProps = async (_ref) => {
  let ctx = Object.assign({}, _ref);
  const slug = ctx.params.slug;
  const config = await __webpack_require__.e(/* import() */ 0).then(__webpack_require__.t.bind(null, "D8MT", 3));
  const tutorialMain = await entity["a" /* TutorialDB */].findTutorial("slug", slug);
  const sections = await tutorialSection_entity["a" /* TutorialSectionDB */].listTutorialSections(tutorialMain.id);
  const tags = await entity["a" /* TutorialDB */].getTags(tutorialMain.id);

  const tutorial = _objectSpread(_objectSpread({}, tutorialMain), {}, {
    tags,
    sections
  });

  const author = await user_entity["a" /* UserDB */].getUserInformation(tutorialMain.userId);
  const tutorialMetrics = {
    tutorialRegisteredCount: await planner_entity["a" /* PlannerDB */].getRegisteredCount(tutorialMain.id) // totalComments: await  

  };
  return {
    props: {
      siteTitle: config.title,
      tutorial,
      author
    }
  };
};
/* harmony default export */ var _slug_ = __webpack_exports__["default"] = (TutorialPage);

/***/ }),

/***/ "QYdn":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return TutorialProgressDAO; });
/* harmony import */ var _database_knex__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("CaIY");
/* harmony import */ var _dataAccess_planner_entity__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("64Oa");


class TutorialProgressDAO {
  /** Registers the section this tutorial belongs to the user's Planner 
    * and marks this particular section as complete */
  static async setSectionComplete(userId, sectionId) {
    // Get the id of the tutorial this section belongs to
    const tutorialIdRes = await Object(_database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"])('tutorial_sections').select('tutorialId').where({
      id: sectionId
    });
    const {
      tutorialId
    } = tutorialIdRes.shift(); // Check if the tutorial is already in the user's planner

    const plannerId = await _dataAccess_planner_entity__WEBPACK_IMPORTED_MODULE_1__[/* PlannerDB */ "a"].getPlannerId(userId);
    const isTutorialRegistered = await _dataAccess_planner_entity__WEBPACK_IMPORTED_MODULE_1__[/* PlannerDB */ "a"].isTutorialRegistered(tutorialId, plannerId); // If the tutorial is not registered, register it

    if (isTutorialRegistered === false) {
      await _dataAccess_planner_entity__WEBPACK_IMPORTED_MODULE_1__[/* PlannerDB */ "a"].registerTutorial(tutorialId, plannerId, userId);
    } // Mark the section as complete


    const sectionProgress = await _database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"].raw(`
      INSERT INTO tutorial_sections_progress
          ("sectionId", "userId", "isComplete")
          VALUES (${sectionId}, ${userId}, true)

          ON CONFLICT ("sectionId", "userId") 
          DO UPDATE
              SET 
              "isComplete" = true
              WHERE EXCLUDED."sectionId" = ${sectionId} AND EXCLUDED."userId" = ${userId}

          RETURNING "isComplete", "sectionId"
    `);
    return sectionProgress.rows.shift();
  }

  /** Marks this particular section as incomplete */
  static async setSectionIncomplete(sectionId, userId) {
    const sectionProgress = await _database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"].raw(`
      INSERT INTO tutorial_sections_progress
      ("sectionId", "userId", "isComplete")
      VALUES (${sectionId}, ${userId}, false)

      ON CONFLICT ("sectionId", "userId") 
      DO UPDATE
          SET 
          "isComplete" = false
          WHERE EXCLUDED."sectionId" = ${sectionId} AND EXCLUDED."userId" = ${userId}

      RETURNING "isComplete", "sectionId"
      `);
    return sectionProgress;
  }

  /** Unregisters section from progress tracking */
  static async unregisterSection(sectionId, userId) {
    await Object(_database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"])('tutorial_sections_progress').where({
      sectionId,
      userId
    }).delete();
  }

  /** Retrieves the progress of these section ids */
  static async retrieveSectionProgress(sectionIds, userId) {
    const sectionsProgressRes = await Object(_database_knex__WEBPACK_IMPORTED_MODULE_0__[/* Knex */ "a"])('tutorial_sections_progress').select('sectionId', 'userId', 'isComplete').whereIn('sectionId', sectionIds).andWhere({
      userId
    });
    return sectionsProgressRes;
  }

}
;

/***/ }),

/***/ "QnN6":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, "a", function() { return /* reexport */ user_UserDAO; });

// EXTERNAL MODULE: ./server/database/knex.ts
var knex = __webpack_require__("CaIY");

// CONCATENATED MODULE: ./server/dataAccess/user/index.ts

class user_UserDAO {
  static async findUser(prop, val) {
    const users = await knex["a" /* Knex */].select('*').from('user_information').where(prop, val);
    return users.shift();
  }

  static async registerUser(userData, providerId) {
    const results = await Object(knex["a" /* Knex */])('user_information').insert({
      name: userData.name,
      uid: userData.uid,
      profileImage: userData.profileImageUrl,
      auth_provider: providerId
    }).returning('*');
    const addedUser = results.shift(); // Add their account information

    await Object(knex["a" /* Knex */])('user_account_information').insert({
      email: userData.email,
      username: userData.username,
      userId: addedUser.id
    });
    return addedUser;
  }

  static async getUserInformation(userId) {
    const users = await Object(knex["a" /* Knex */])('user_information').join('user_account_information', {
      'user_information.id': 'user_account_information.userId'
    }).select('heading', 'about', 'name', 'website', 'profileImage', 'username').where('user_information.id', userId);
    return users.shift();
  }

  static async updateUserInformation(userData) {
    const users = await knex["a" /* Knex */].where({
      id: userData.id
    }).update({
      heading: userData.heading,
      name: userData.name,
      about: userData.about,
      website: userData.website,
      profileImage: userData.profileImage
    }).returning('*');
    return users.shift();
  }

}
;
// CONCATENATED MODULE: ./server/dataAccess/user/entity.ts


/***/ }),

/***/ "SfJF":
/***/ (function(module, exports) {

module.exports = require("knex");

/***/ }),

/***/ "Ti4I":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AuthenticationContext; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

;
const AuthenticationContext = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createContext({
  isAuthenticated: null,
  profileImageUrl: null,
  toggleAuthenticationModal: null
});

/***/ }),

/***/ "TqRt":
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "UhrY":
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ "V9y6":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return TagItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;
;
const TagItem = ({
  tagId,
  tagName,
  useMargin,
  removable,
  onRemoveClick
}) => {
  let className = "tag-item"; // If the tag should provide its own margin 
  // around itself

  if (useMargin) {
    className = className.concat(' tag-item--margin');
  }

  return __jsx("div", {
    className: className
  }, `#${tagName}`, removable && __jsx("i", {
    onClick: onRemoveClick,
    className: "x-btn fas fa-times"
  }));
};

/***/ }),

/***/ "X24+":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.removePathTrailingSlash = removePathTrailingSlash;
exports.normalizePathTrailingSlash = void 0;
/**
* Removes the trailing slash of a path if there is one. Preserves the root path `/`.
*/

function removePathTrailingSlash(path) {
  return path.endsWith('/') && path !== '/' ? path.slice(0, -1) : path;
}
/**
* Normalizes the trailing slash of a path according to the `trailingSlash` option
* in `next.config.js`.
*/


const normalizePathTrailingSlash =  false ? undefined : removePathTrailingSlash;
exports.normalizePathTrailingSlash = normalizePathTrailingSlash;

/***/ }),

/***/ "YFqc":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("cTJO")


/***/ }),

/***/ "YTqd":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.getRouteRegex = getRouteRegex; // this isn't importing the escape-string-regex module
// to reduce bytes

function escapeRegex(str) {
  return str.replace(/[|\\{}()[\]^$+*?.-]/g, '\\$&');
}

function parseParameter(param) {
  const optional = param.startsWith('[') && param.endsWith(']');

  if (optional) {
    param = param.slice(1, -1);
  }

  const repeat = param.startsWith('...');

  if (repeat) {
    param = param.slice(3);
  }

  return {
    key: param,
    repeat,
    optional
  };
}

function getRouteRegex(normalizedRoute) {
  const segments = (normalizedRoute.replace(/\/$/, '') || '/').slice(1).split('/');
  const groups = {};
  let groupIndex = 1;
  const parameterizedRoute = segments.map(segment => {
    if (segment.startsWith('[') && segment.endsWith(']')) {
      const {
        key,
        optional,
        repeat
      } = parseParameter(segment.slice(1, -1));
      groups[key] = {
        pos: groupIndex++,
        repeat,
        optional
      };
      return repeat ? optional ? '(?:/(.+?))?' : '/(.+?)' : '/([^/]+?)';
    } else {
      return `/${escapeRegex(segment)}`;
    }
  }).join(''); // dead code eliminate for browser since it's only needed
  // while generating routes-manifest

  if (true) {
    let routeKeyCharCode = 97;
    let routeKeyCharLength = 1; // builds a minimal routeKey using only a-z and minimal number of characters

    const getSafeRouteKey = () => {
      let routeKey = '';

      for (let i = 0; i < routeKeyCharLength; i++) {
        routeKey += String.fromCharCode(routeKeyCharCode);
        routeKeyCharCode++;

        if (routeKeyCharCode > 122) {
          routeKeyCharLength++;
          routeKeyCharCode = 97;
        }
      }

      return routeKey;
    };

    const routeKeys = {};
    let namedParameterizedRoute = segments.map(segment => {
      if (segment.startsWith('[') && segment.endsWith(']')) {
        const {
          key,
          optional,
          repeat
        } = parseParameter(segment.slice(1, -1)); // replace any non-word characters since they can break
        // the named regex

        let cleanedKey = key.replace(/\W/g, '');
        let invalidKey = false; // check if the key is still invalid and fallback to using a known
        // safe key

        if (cleanedKey.length === 0 || cleanedKey.length > 30) {
          invalidKey = true;
        }

        if (!isNaN(parseInt(cleanedKey.substr(0, 1)))) {
          invalidKey = true;
        }

        if (invalidKey) {
          cleanedKey = getSafeRouteKey();
        }

        routeKeys[cleanedKey] = key;
        return repeat ? optional ? `(?:/(?<${cleanedKey}>.+?))?` : `/(?<${cleanedKey}>.+?)` : `/(?<${cleanedKey}>[^/]+?)`;
      } else {
        return `/${escapeRegex(segment)}`;
      }
    }).join('');
    return {
      re: new RegExp(`^${parameterizedRoute}(?:/)?$`),
      groups,
      routeKeys,
      namedRegex: `^${namedParameterizedRoute}(?:/)?$`
    };
  }

  return {
    re: new RegExp(`^${parameterizedRoute}(?:/)?$`),
    groups
  };
}

/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "cDf5":
/***/ (function(module, exports) {

function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    module.exports = _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    module.exports = _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

module.exports = _typeof;

/***/ }),

/***/ "cTJO":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireWildcard = __webpack_require__("284h");

exports.__esModule = true;
exports.default = void 0;

var _react = _interopRequireWildcard(__webpack_require__("cDcd"));

var _router = __webpack_require__("elyg");

var _router2 = __webpack_require__("nOHt");

var _useIntersection = __webpack_require__("vNVm");

const prefetched = {};

function prefetch(router, href, as, options) {
  if (true) return;
  if (!(0, _router.isLocalURL)(href)) return; // Prefetch the JSON page if asked (only in the client)
  // We need to handle a prefetch error here since we may be
  // loading with priority which can reject but we don't
  // want to force navigation since this is only a prefetch

  router.prefetch(href, as, options).catch(err => {
    if (false) {}
  });
  const curLocale = options && typeof options.locale !== 'undefined' ? options.locale : router && router.locale; // Join on an invalid URI character

  prefetched[href + '%' + as + (curLocale ? '%' + curLocale : '')] = true;
}

function isModifiedEvent(event) {
  const {
    target
  } = event.currentTarget;
  return target && target !== '_self' || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || // triggers resource download
  event.nativeEvent && event.nativeEvent.which === 2;
}

function linkClicked(e, router, href, as, replace, shallow, scroll, locale) {
  const {
    nodeName
  } = e.currentTarget;

  if (nodeName === 'A' && (isModifiedEvent(e) || !(0, _router.isLocalURL)(href))) {
    // ignore click for browser’s default behavior
    return;
  }

  e.preventDefault(); //  avoid scroll for urls with anchor refs

  if (scroll == null) {
    scroll = as.indexOf('#') < 0;
  } // replace state instead of push if prop is present


  router[replace ? 'replace' : 'push'](href, as, {
    shallow,
    locale,
    scroll
  });
}

function Link(props) {
  if (false) {}

  const p = props.prefetch !== false;
  const router = (0, _router2.useRouter)();
  const pathname = router && router.pathname || '/';

  const {
    href,
    as
  } = _react.default.useMemo(() => {
    const [resolvedHref, resolvedAs] = (0, _router.resolveHref)(pathname, props.href, true);
    return {
      href: resolvedHref,
      as: props.as ? (0, _router.resolveHref)(pathname, props.as) : resolvedAs || resolvedHref
    };
  }, [pathname, props.href, props.as]);

  let {
    children,
    replace,
    shallow,
    scroll,
    locale
  } = props; // Deprecated. Warning shown by propType check. If the children provided is a string (<Link>example</Link>) we wrap it in an <a> tag

  if (typeof children === 'string') {
    children = /*#__PURE__*/_react.default.createElement("a", null, children);
  } // This will return the first child, if multiple are provided it will throw an error


  const child = _react.Children.only(children);

  const childRef = child && typeof child === 'object' && child.ref;
  const [setIntersectionRef, isVisible] = (0, _useIntersection.useIntersection)({
    rootMargin: '200px'
  });

  const setRef = _react.default.useCallback(el => {
    setIntersectionRef(el);

    if (childRef) {
      if (typeof childRef === 'function') childRef(el);else if (typeof childRef === 'object') {
        childRef.current = el;
      }
    }
  }, [childRef, setIntersectionRef]);

  (0, _react.useEffect)(() => {
    const shouldPrefetch = isVisible && p && (0, _router.isLocalURL)(href);
    const curLocale = typeof locale !== 'undefined' ? locale : router && router.locale;
    const isPrefetched = prefetched[href + '%' + as + (curLocale ? '%' + curLocale : '')];

    if (shouldPrefetch && !isPrefetched) {
      prefetch(router, href, as, {
        locale: curLocale
      });
    }
  }, [as, href, isVisible, locale, p, router]);
  const childProps = {
    ref: setRef,
    onClick: e => {
      if (child.props && typeof child.props.onClick === 'function') {
        child.props.onClick(e);
      }

      if (!e.defaultPrevented) {
        linkClicked(e, router, href, as, replace, shallow, scroll, locale);
      }
    }
  };

  childProps.onMouseEnter = e => {
    if (!(0, _router.isLocalURL)(href)) return;

    if (child.props && typeof child.props.onMouseEnter === 'function') {
      child.props.onMouseEnter(e);
    }

    prefetch(router, href, as, {
      priority: true
    });
  }; // If child is an <a> tag and doesn't have a href attribute, or if the 'passHref' property is
  // defined, we specify the current 'href', so that repetition is not needed by the user


  if (props.passHref || child.type === 'a' && !('href' in child.props)) {
    const curLocale = typeof locale !== 'undefined' ? locale : router && router.locale; // we only render domain locales if we are currently on a domain locale
    // so that locale links are still visitable in development/preview envs

    const localeDomain = router && router.isLocaleDomain && (0, _router.getDomainLocale)(as, curLocale, router && router.locales, router && router.domainLocales);
    childProps.href = localeDomain || (0, _router.addBasePath)((0, _router.addLocale)(as, curLocale, router && router.defaultLocale));
  }

  return /*#__PURE__*/_react.default.cloneElement(child, childProps);
}

var _default = Link;
exports.default = _default;

/***/ }),

/***/ "dZ6Y":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.default = mitt;
/*
MIT License
Copyright (c) Jason Miller (https://jasonformat.com/)
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
// This file is based on https://github.com/developit/mitt/blob/v1.1.3/src/index.js
// It's been edited for the needs of this script
// See the LICENSE at the top of the file

function mitt() {
  const all = Object.create(null);
  return {
    on(type, handler) {
      ;
      (all[type] || (all[type] = [])).push(handler);
    },

    off(type, handler) {
      if (all[type]) {
        all[type].splice(all[type].indexOf(handler) >>> 0, 1);
      }
    },

    emit(type, ...evts) {
      // eslint-disable-next-line array-callback-return
      ;
      (all[type] || []).slice().map(handler => {
        handler(...evts);
      });
    }

  };
}

/***/ }),

/***/ "ebvM":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
const Config = {
  dbHost: process.env.DB_HOST,
  dbUser: process.env.DB_USER,
  dbPassword: process.env.DB_PASSWORD,
  dbName: process.env.DB_NAME,
  zerochassSecret: process.env.ZEROCHASS_SECRET,
  awsRegion: process.env.AWS_REGION,
  awsBucket: process.env.AWS_BUCKET,
  port: process.env.PORT,
  environment: ("production" || false).toLowerCase()
};
/* harmony default export */ __webpack_exports__["a"] = (Config);

/***/ }),

/***/ "elyg":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.getDomainLocale = getDomainLocale;
exports.addLocale = addLocale;
exports.delLocale = delLocale;
exports.hasBasePath = hasBasePath;
exports.addBasePath = addBasePath;
exports.delBasePath = delBasePath;
exports.isLocalURL = isLocalURL;
exports.interpolateAs = interpolateAs;
exports.resolveHref = resolveHref;
exports.default = void 0;

var _normalizeTrailingSlash = __webpack_require__("X24+");

var _routeLoader = __webpack_require__("Nh2W");

var _denormalizePagePath = __webpack_require__("wkBG");

var _normalizeLocalePath = __webpack_require__("3wub");

var _mitt = _interopRequireDefault(__webpack_require__("dZ6Y"));

var _utils = __webpack_require__("g/15");

var _isDynamic = __webpack_require__("/jkW");

var _parseRelativeUrl = __webpack_require__("hS4m");

var _querystring = __webpack_require__("3WeD");

var _resolveRewrites = _interopRequireDefault(__webpack_require__("GXs3"));

var _routeMatcher = __webpack_require__("gguc");

var _routeRegex = __webpack_require__("YTqd");

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}
/* global __NEXT_DATA__ */
// tslint:disable:no-console


let detectDomainLocale;

if (false) {}

const basePath =  false || '';

function buildCancellationError() {
  return Object.assign(new Error('Route Cancelled'), {
    cancelled: true
  });
}

function addPathPrefix(path, prefix) {
  return prefix && path.startsWith('/') ? path === '/' ? (0, _normalizeTrailingSlash.normalizePathTrailingSlash)(prefix) : `${prefix}${pathNoQueryHash(path) === '/' ? path.substring(1) : path}` : path;
}

function getDomainLocale(path, locale, locales, domainLocales) {
  if (false) {}

  return false;
}

function addLocale(path, locale, defaultLocale) {
  if (false) {}

  return path;
}

function delLocale(path, locale) {
  if (false) {}

  return path;
}

function pathNoQueryHash(path) {
  const queryIndex = path.indexOf('?');
  const hashIndex = path.indexOf('#');

  if (queryIndex > -1 || hashIndex > -1) {
    path = path.substring(0, queryIndex > -1 ? queryIndex : hashIndex);
  }

  return path;
}

function hasBasePath(path) {
  path = pathNoQueryHash(path);
  return path === basePath || path.startsWith(basePath + '/');
}

function addBasePath(path) {
  // we only add the basepath on relative urls
  return addPathPrefix(path, basePath);
}

function delBasePath(path) {
  path = path.slice(basePath.length);
  if (!path.startsWith('/')) path = `/${path}`;
  return path;
}
/**
* Detects whether a given url is routable by the Next.js router (browser only).
*/


function isLocalURL(url) {
  // prevent a hydration mismatch on href for url with anchor refs
  if (url.startsWith('/') || url.startsWith('#')) return true;

  try {
    // absolute urls can be local if they are on the same origin
    const locationOrigin = (0, _utils.getLocationOrigin)();
    const resolved = new URL(url, locationOrigin);
    return resolved.origin === locationOrigin && hasBasePath(resolved.pathname);
  } catch (_) {
    return false;
  }
}

function interpolateAs(route, asPathname, query) {
  let interpolatedRoute = '';
  const dynamicRegex = (0, _routeRegex.getRouteRegex)(route);
  const dynamicGroups = dynamicRegex.groups;
  const dynamicMatches = // Try to match the dynamic route against the asPath
  (asPathname !== route ? (0, _routeMatcher.getRouteMatcher)(dynamicRegex)(asPathname) : '') || // Fall back to reading the values from the href
  // TODO: should this take priority; also need to change in the router.
  query;
  interpolatedRoute = route;
  const params = Object.keys(dynamicGroups);

  if (!params.every(param => {
    let value = dynamicMatches[param] || '';
    const {
      repeat,
      optional
    } = dynamicGroups[param]; // support single-level catch-all
    // TODO: more robust handling for user-error (passing `/`)

    let replaced = `[${repeat ? '...' : ''}${param}]`;

    if (optional) {
      replaced = `${!value ? '/' : ''}[${replaced}]`;
    }

    if (repeat && !Array.isArray(value)) value = [value];
    return (optional || param in dynamicMatches) && ( // Interpolate group into data URL if present
    interpolatedRoute = interpolatedRoute.replace(replaced, repeat ? value.map( // these values should be fully encoded instead of just
    // path delimiter escaped since they are being inserted
    // into the URL and we expect URL encoded segments
    // when parsing dynamic route params
    segment => encodeURIComponent(segment)).join('/') : encodeURIComponent(value)) || '/');
  })) {
    interpolatedRoute = ''; // did not satisfy all requirements
    // n.b. We ignore this error because we handle warning for this case in
    // development in the `<Link>` component directly.
  }

  return {
    params,
    result: interpolatedRoute
  };
}

function omitParmsFromQuery(query, params) {
  const filteredQuery = {};
  Object.keys(query).forEach(key => {
    if (!params.includes(key)) {
      filteredQuery[key] = query[key];
    }
  });
  return filteredQuery;
}
/**
* Resolves a given hyperlink with a certain router state (basePath not included).
* Preserves absolute urls.
*/


function resolveHref(currentPath, href, resolveAs) {
  // we use a dummy base url for relative urls
  const base = new URL(currentPath, 'http://n');
  const urlAsString = typeof href === 'string' ? href : (0, _utils.formatWithValidation)(href); // Return because it cannot be routed by the Next.js router

  if (!isLocalURL(urlAsString)) {
    return resolveAs ? [urlAsString] : urlAsString;
  }

  try {
    const finalUrl = new URL(urlAsString, base);
    finalUrl.pathname = (0, _normalizeTrailingSlash.normalizePathTrailingSlash)(finalUrl.pathname);
    let interpolatedAs = '';

    if ((0, _isDynamic.isDynamicRoute)(finalUrl.pathname) && finalUrl.searchParams && resolveAs) {
      const query = (0, _querystring.searchParamsToUrlQuery)(finalUrl.searchParams);
      const {
        result,
        params
      } = interpolateAs(finalUrl.pathname, finalUrl.pathname, query);

      if (result) {
        interpolatedAs = (0, _utils.formatWithValidation)({
          pathname: result,
          hash: finalUrl.hash,
          query: omitParmsFromQuery(query, params)
        });
      }
    } // if the origin didn't change, it means we received a relative href


    const resolvedHref = finalUrl.origin === base.origin ? finalUrl.href.slice(finalUrl.origin.length) : finalUrl.href;
    return resolveAs ? [resolvedHref, interpolatedAs || resolvedHref] : resolvedHref;
  } catch (_) {
    return resolveAs ? [urlAsString] : urlAsString;
  }
}

function stripOrigin(url) {
  const origin = (0, _utils.getLocationOrigin)();
  return url.startsWith(origin) ? url.substring(origin.length) : url;
}

function prepareUrlAs(router, url, as) {
  // If url and as provided as an object representation,
  // we'll format them into the string version here.
  let [resolvedHref, resolvedAs] = resolveHref(router.pathname, url, true);
  const origin = (0, _utils.getLocationOrigin)();
  const hrefHadOrigin = resolvedHref.startsWith(origin);
  const asHadOrigin = resolvedAs && resolvedAs.startsWith(origin);
  resolvedHref = stripOrigin(resolvedHref);
  resolvedAs = resolvedAs ? stripOrigin(resolvedAs) : resolvedAs;
  const preparedUrl = hrefHadOrigin ? resolvedHref : addBasePath(resolvedHref);
  const preparedAs = as ? stripOrigin(resolveHref(router.pathname, as)) : resolvedAs || resolvedHref;
  return {
    url: preparedUrl,
    as: asHadOrigin ? preparedAs : addBasePath(preparedAs)
  };
}

function resolveDynamicRoute(pathname, pages) {
  const cleanPathname = (0, _normalizeTrailingSlash.removePathTrailingSlash)((0, _denormalizePagePath.denormalizePagePath)(pathname));

  if (cleanPathname === '/404' || cleanPathname === '/_error') {
    return pathname;
  } // handle resolving href for dynamic routes


  if (!pages.includes(cleanPathname)) {
    // eslint-disable-next-line array-callback-return
    pages.some(page => {
      if ((0, _isDynamic.isDynamicRoute)(page) && (0, _routeRegex.getRouteRegex)(page).re.test(cleanPathname)) {
        pathname = page;
        return true;
      }
    });
  }

  return (0, _normalizeTrailingSlash.removePathTrailingSlash)(pathname);
}

const manualScrollRestoration =  false && false;
const SSG_DATA_NOT_FOUND = Symbol('SSG_DATA_NOT_FOUND');

function fetchRetry(url, attempts) {
  return fetch(url, {
    // Cookies are required to be present for Next.js' SSG "Preview Mode".
    // Cookies may also be required for `getServerSideProps`.
    //
    // > `fetch` won’t send cookies, unless you set the credentials init
    // > option.
    // https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
    //
    // > For maximum browser compatibility when it comes to sending &
    // > receiving cookies, always supply the `credentials: 'same-origin'`
    // > option instead of relying on the default.
    // https://github.com/github/fetch#caveats
    credentials: 'same-origin'
  }).then(res => {
    if (!res.ok) {
      if (attempts > 1 && res.status >= 500) {
        return fetchRetry(url, attempts - 1);
      }

      if (res.status === 404) {
        return res.json().then(data => {
          if (data.notFound) {
            return {
              notFound: SSG_DATA_NOT_FOUND
            };
          }

          throw new Error(`Failed to load static props`);
        });
      }

      throw new Error(`Failed to load static props`);
    }

    return res.json();
  });
}

function fetchNextData(dataHref, isServerRender) {
  return fetchRetry(dataHref, isServerRender ? 3 : 1).catch(err => {
    // We should only trigger a server-side transition if this was caused
    // on a client-side transition. Otherwise, we'd get into an infinite
    // loop.
    if (!isServerRender) {
      (0, _routeLoader.markAssetError)(err);
    }

    throw err;
  });
}

class Router {
  /**
  * Map of all components loaded in `Router`
  */
  // Static Data Cache
  // In-flight Server Data Requests, for deduping
  constructor(_pathname, _query, _as, {
    initialProps,
    pageLoader,
    App,
    wrapApp,
    Component,
    err,
    subscription,
    isFallback,
    locale,
    locales,
    defaultLocale,
    domainLocales,
    isPreview
  }) {
    this.route = void 0;
    this.pathname = void 0;
    this.query = void 0;
    this.asPath = void 0;
    this.basePath = void 0;
    this.components = void 0;
    this.sdc = {};
    this.sdr = {};
    this.sub = void 0;
    this.clc = void 0;
    this.pageLoader = void 0;
    this._bps = void 0;
    this.events = void 0;
    this._wrapApp = void 0;
    this.isSsr = void 0;
    this.isFallback = void 0;
    this._inFlightRoute = void 0;
    this._shallow = void 0;
    this.locale = void 0;
    this.locales = void 0;
    this.defaultLocale = void 0;
    this.domainLocales = void 0;
    this.isReady = void 0;
    this.isPreview = void 0;
    this.isLocaleDomain = void 0;
    this._idx = 0;

    this.onPopState = e => {
      const state = e.state;

      if (!state) {
        // We get state as undefined for two reasons.
        //  1. With older safari (< 8) and older chrome (< 34)
        //  2. When the URL changed with #
        //
        // In the both cases, we don't need to proceed and change the route.
        // (as it's already changed)
        // But we can simply replace the state with the new changes.
        // Actually, for (1) we don't need to nothing. But it's hard to detect that event.
        // So, doing the following for (1) does no harm.
        const {
          pathname,
          query
        } = this;
        this.changeState('replaceState', (0, _utils.formatWithValidation)({
          pathname: addBasePath(pathname),
          query
        }), (0, _utils.getURL)());
        return;
      }

      if (!state.__N) {
        return;
      }

      let forcedScroll;
      const {
        url,
        as,
        options,
        idx
      } = state;

      if (false) {}

      this._idx = idx;
      const {
        pathname
      } = (0, _parseRelativeUrl.parseRelativeUrl)(url); // Make sure we don't re-render on initial load,
      // can be caused by navigating back from an external site

      if (this.isSsr && as === this.asPath && pathname === this.pathname) {
        return;
      } // If the downstream application returns falsy, return.
      // They will then be responsible for handling the event.


      if (this._bps && !this._bps(state)) {
        return;
      }

      this.change('replaceState', url, as, Object.assign({}, options, {
        shallow: options.shallow && this._shallow,
        locale: options.locale || this.defaultLocale
      }), forcedScroll);
    }; // represents the current component key


    this.route = (0, _normalizeTrailingSlash.removePathTrailingSlash)(_pathname); // set up the component cache (by route keys)

    this.components = {}; // We should not keep the cache, if there's an error
    // Otherwise, this cause issues when when going back and
    // come again to the errored page.

    if (_pathname !== '/_error') {
      this.components[this.route] = {
        Component,
        initial: true,
        props: initialProps,
        err,
        __N_SSG: initialProps && initialProps.__N_SSG,
        __N_SSP: initialProps && initialProps.__N_SSP
      };
    }

    this.components['/_app'] = {
      Component: App,
      styleSheets: [
        /* /_app does not need its stylesheets managed */
      ]
    }; // Backwards compat for Router.router.events
    // TODO: Should be remove the following major version as it was never documented

    this.events = Router.events;
    this.pageLoader = pageLoader;
    this.pathname = _pathname;
    this.query = _query; // if auto prerendered and dynamic route wait to update asPath
    // until after mount to prevent hydration mismatch

    const autoExportDynamic = (0, _isDynamic.isDynamicRoute)(_pathname) && self.__NEXT_DATA__.autoExport;

    this.asPath = autoExportDynamic ? _pathname : _as;
    this.basePath = basePath;
    this.sub = subscription;
    this.clc = null;
    this._wrapApp = wrapApp; // make sure to ignore extra popState in safari on navigating
    // back from external site

    this.isSsr = true;
    this.isFallback = isFallback;
    this.isReady = !!(self.__NEXT_DATA__.gssp || self.__NEXT_DATA__.gip || !autoExportDynamic && !self.location.search);
    this.isPreview = !!isPreview;
    this.isLocaleDomain = false;

    if (false) {}

    if (false) {}
  }

  reload() {
    window.location.reload();
  }
  /**
  * Go back in history
  */


  back() {
    window.history.back();
  }
  /**
  * Performs a `pushState` with arguments
  * @param url of the route
  * @param as masks `url` for the browser
  * @param options object you can define `shallow` and other options
  */


  push(url, as, options = {}) {
    if (false) {}

    ;
    ({
      url,
      as
    } = prepareUrlAs(this, url, as));
    return this.change('pushState', url, as, options);
  }
  /**
  * Performs a `replaceState` with arguments
  * @param url of the route
  * @param as masks `url` for the browser
  * @param options object you can define `shallow` and other options
  */


  replace(url, as, options = {}) {
    ;
    ({
      url,
      as
    } = prepareUrlAs(this, url, as));
    return this.change('replaceState', url, as, options);
  }

  async change(method, url, as, options, forcedScroll) {
    var _options$scroll;

    if (!isLocalURL(url)) {
      window.location.href = url;
      return false;
    } // for static pages with query params in the URL we delay
    // marking the router ready until after the query is updated


    if (options._h) {
      this.isReady = true;
    } // Default to scroll reset behavior unless explicitly specified to be
    // `false`! This makes the behavior between using `Router#push` and a
    // `<Link />` consistent.


    options.scroll = !!((_options$scroll = options.scroll) != null ? _options$scroll : true);
    let localeChange = options.locale !== this.locale;

    if (false) { var _this$locales; }

    if (!options._h) {
      this.isSsr = false;
    } // marking route changes as a navigation start entry


    if (_utils.ST) {
      performance.mark('routeChange');
    }

    const {
      shallow = false
    } = options;
    const routeProps = {
      shallow
    };

    if (this._inFlightRoute) {
      this.abortComponentLoad(this._inFlightRoute, routeProps);
    }

    as = addBasePath(addLocale(hasBasePath(as) ? delBasePath(as) : as, options.locale, this.defaultLocale));
    const cleanedAs = delLocale(hasBasePath(as) ? delBasePath(as) : as, this.locale);
    this._inFlightRoute = as; // If the url change is only related to a hash change
    // We should not proceed. We should only change the state.
    // WARNING: `_h` is an internal option for handing Next.js client-side
    // hydration. Your app should _never_ use this property. It may change at
    // any time without notice.

    if (!options._h && this.onlyAHashChange(cleanedAs)) {
      this.asPath = cleanedAs;
      Router.events.emit('hashChangeStart', as, routeProps); // TODO: do we need the resolved href when only a hash change?

      this.changeState(method, url, as, options);
      this.scrollToHash(cleanedAs);
      this.notify(this.components[this.route], null);
      Router.events.emit('hashChangeComplete', as, routeProps);
      return true;
    }

    let parsed = (0, _parseRelativeUrl.parseRelativeUrl)(url);
    let {
      pathname,
      query
    } = parsed; // The build manifest needs to be loaded before auto-static dynamic pages
    // get their query parameters to allow ensuring they can be parsed properly
    // when rewritten to

    let pages, rewrites;

    try {
      pages = await this.pageLoader.getPageList();
      ({
        __rewrites: rewrites
      } = await (0, _routeLoader.getClientBuildManifest)());
    } catch (err) {
      // If we fail to resolve the page list or client-build manifest, we must
      // do a server-side transition:
      window.location.href = as;
      return false;
    } // If asked to change the current URL we should reload the current page
    // (not location.reload() but reload getInitialProps and other Next.js stuffs)
    // We also need to set the method = replaceState always
    // as this should not go into the history (That's how browsers work)
    // We should compare the new asPath to the current asPath, not the url


    if (!this.urlIsNew(cleanedAs) && !localeChange) {
      method = 'replaceState';
    } // we need to resolve the as value using rewrites for dynamic SSG
    // pages to allow building the data URL correctly


    let resolvedAs = as; // url and as should always be prefixed with basePath by this
    // point by either next/link or router.push/replace so strip the
    // basePath from the pathname to match the pages dir 1-to-1

    pathname = pathname ? (0, _normalizeTrailingSlash.removePathTrailingSlash)(delBasePath(pathname)) : pathname;

    if (pathname !== '/_error') {
      if (false) {} else {
        parsed.pathname = resolveDynamicRoute(pathname, pages);

        if (parsed.pathname !== pathname) {
          pathname = parsed.pathname;
          url = (0, _utils.formatWithValidation)(parsed);
        }
      }
    }

    const route = (0, _normalizeTrailingSlash.removePathTrailingSlash)(pathname);

    if (!isLocalURL(as)) {
      if (false) {}

      window.location.href = as;
      return false;
    }

    resolvedAs = delLocale(delBasePath(resolvedAs), this.locale);

    if ((0, _isDynamic.isDynamicRoute)(route)) {
      const parsedAs = (0, _parseRelativeUrl.parseRelativeUrl)(resolvedAs);
      const asPathname = parsedAs.pathname;
      const routeRegex = (0, _routeRegex.getRouteRegex)(route);
      const routeMatch = (0, _routeMatcher.getRouteMatcher)(routeRegex)(asPathname);
      const shouldInterpolate = route === asPathname;
      const interpolatedAs = shouldInterpolate ? interpolateAs(route, asPathname, query) : {};

      if (!routeMatch || shouldInterpolate && !interpolatedAs.result) {
        const missingParams = Object.keys(routeRegex.groups).filter(param => !query[param]);

        if (missingParams.length > 0) {
          if (false) {}

          throw new Error((shouldInterpolate ? `The provided \`href\` (${url}) value is missing query values (${missingParams.join(', ')}) to be interpolated properly. ` : `The provided \`as\` value (${asPathname}) is incompatible with the \`href\` value (${route}). `) + `Read more: https://nextjs.org/docs/messages/${shouldInterpolate ? 'href-interpolation-failed' : 'incompatible-href-as'}`);
        }
      } else if (shouldInterpolate) {
        as = (0, _utils.formatWithValidation)(Object.assign({}, parsedAs, {
          pathname: interpolatedAs.result,
          query: omitParmsFromQuery(query, interpolatedAs.params)
        }));
      } else {
        // Merge params into `query`, overwriting any specified in search
        Object.assign(query, routeMatch);
      }
    }

    Router.events.emit('routeChangeStart', as, routeProps);

    try {
      var _self$__NEXT_DATA__$p, _self$__NEXT_DATA__$p2;

      let routeInfo = await this.getRouteInfo(route, pathname, query, as, resolvedAs, routeProps);
      let {
        error,
        props,
        __N_SSG,
        __N_SSP
      } = routeInfo; // handle redirect on client-transition

      if ((__N_SSG || __N_SSP) && props) {
        if (props.pageProps && props.pageProps.__N_REDIRECT) {
          const destination = props.pageProps.__N_REDIRECT; // check if destination is internal (resolves to a page) and attempt
          // client-navigation if it is falling back to hard navigation if
          // it's not

          if (destination.startsWith('/')) {
            const parsedHref = (0, _parseRelativeUrl.parseRelativeUrl)(destination);
            parsedHref.pathname = resolveDynamicRoute(parsedHref.pathname, pages);

            if (pages.includes(parsedHref.pathname)) {
              const {
                url: newUrl,
                as: newAs
              } = prepareUrlAs(this, destination, destination);
              return this.change(method, newUrl, newAs, options);
            }
          }

          window.location.href = destination;
          return new Promise(() => {});
        }

        this.isPreview = !!props.__N_PREVIEW; // handle SSG data 404

        if (props.notFound === SSG_DATA_NOT_FOUND) {
          let notFoundRoute;

          try {
            await this.fetchComponent('/404');
            notFoundRoute = '/404';
          } catch (_) {
            notFoundRoute = '/_error';
          }

          routeInfo = await this.getRouteInfo(notFoundRoute, notFoundRoute, query, as, resolvedAs, {
            shallow: false
          });
        }
      }

      Router.events.emit('beforeHistoryChange', as, routeProps);
      this.changeState(method, url, as, options);

      if (false) {} // shallow routing is only allowed for same page URL changes.


      const isValidShallowRoute = options.shallow && this.route === route;

      if (options._h && pathname === '/_error' && ((_self$__NEXT_DATA__$p = self.__NEXT_DATA__.props) == null ? void 0 : (_self$__NEXT_DATA__$p2 = _self$__NEXT_DATA__$p.pageProps) == null ? void 0 : _self$__NEXT_DATA__$p2.statusCode) === 500 && props != null && props.pageProps) {
        // ensure statusCode is still correct for static 500 page
        // when updating query information
        props.pageProps.statusCode = 500;
      }

      await this.set(route, pathname, query, cleanedAs, routeInfo, forcedScroll || (isValidShallowRoute || !options.scroll ? null : {
        x: 0,
        y: 0
      })).catch(e => {
        if (e.cancelled) error = error || e;else throw e;
      });

      if (error) {
        Router.events.emit('routeChangeError', error, cleanedAs, routeProps);
        throw error;
      }

      if (false) {}

      Router.events.emit('routeChangeComplete', as, routeProps);
      return true;
    } catch (err) {
      if (err.cancelled) {
        return false;
      }

      throw err;
    }
  }

  changeState(method, url, as, options = {}) {
    if (false) {}

    if (method !== 'pushState' || (0, _utils.getURL)() !== as) {
      this._shallow = options.shallow;
      window.history[method]({
        url,
        as,
        options,
        __N: true,
        idx: this._idx = method !== 'pushState' ? this._idx : this._idx + 1
      }, // Most browsers currently ignores this parameter, although they may use it in the future.
      // Passing the empty string here should be safe against future changes to the method.
      // https://developer.mozilla.org/en-US/docs/Web/API/History/replaceState
      '', as);
    }
  }

  async handleRouteInfoError(err, pathname, query, as, routeProps, loadErrorFail) {
    if (err.cancelled) {
      // bubble up cancellation errors
      throw err;
    }

    if ((0, _routeLoader.isAssetError)(err) || loadErrorFail) {
      Router.events.emit('routeChangeError', err, as, routeProps); // If we can't load the page it could be one of following reasons
      //  1. Page doesn't exists
      //  2. Page does exist in a different zone
      //  3. Internal error while loading the page
      // So, doing a hard reload is the proper way to deal with this.

      window.location.href = as; // Changing the URL doesn't block executing the current code path.
      // So let's throw a cancellation error stop the routing logic.

      throw buildCancellationError();
    }

    try {
      let Component;
      let styleSheets;
      let props;

      if (typeof Component === 'undefined' || typeof styleSheets === 'undefined') {
        ;
        ({
          page: Component,
          styleSheets
        } = await this.fetchComponent('/_error'));
      }

      const routeInfo = {
        props,
        Component,
        styleSheets,
        err,
        error: err
      };

      if (!routeInfo.props) {
        try {
          routeInfo.props = await this.getInitialProps(Component, {
            err,
            pathname,
            query
          });
        } catch (gipErr) {
          console.error('Error in error page `getInitialProps`: ', gipErr);
          routeInfo.props = {};
        }
      }

      return routeInfo;
    } catch (routeInfoErr) {
      return this.handleRouteInfoError(routeInfoErr, pathname, query, as, routeProps, true);
    }
  }

  async getRouteInfo(route, pathname, query, as, resolvedAs, routeProps) {
    try {
      const existingRouteInfo = this.components[route];

      if (routeProps.shallow && existingRouteInfo && this.route === route) {
        return existingRouteInfo;
      }

      const cachedRouteInfo = existingRouteInfo && 'initial' in existingRouteInfo ? undefined : existingRouteInfo;
      const routeInfo = cachedRouteInfo ? cachedRouteInfo : await this.fetchComponent(route).then(res => ({
        Component: res.page,
        styleSheets: res.styleSheets,
        __N_SSG: res.mod.__N_SSG,
        __N_SSP: res.mod.__N_SSP
      }));
      const {
        Component,
        __N_SSG,
        __N_SSP
      } = routeInfo;

      if (false) {}

      let dataHref;

      if (__N_SSG || __N_SSP) {
        dataHref = this.pageLoader.getDataHref((0, _utils.formatWithValidation)({
          pathname,
          query
        }), resolvedAs, __N_SSG, this.locale);
      }

      const props = await this._getData(() => __N_SSG ? this._getStaticData(dataHref) : __N_SSP ? this._getServerData(dataHref) : this.getInitialProps(Component, // we provide AppTree later so this needs to be `any`
      {
        pathname,
        query,
        asPath: as
      }));
      routeInfo.props = props;
      this.components[route] = routeInfo;
      return routeInfo;
    } catch (err) {
      return this.handleRouteInfoError(err, pathname, query, as, routeProps);
    }
  }

  set(route, pathname, query, as, data, resetScroll) {
    this.isFallback = false;
    this.route = route;
    this.pathname = pathname;
    this.query = query;
    this.asPath = as;
    return this.notify(data, resetScroll);
  }
  /**
  * Callback to execute before replacing router state
  * @param cb callback to be executed
  */


  beforePopState(cb) {
    this._bps = cb;
  }

  onlyAHashChange(as) {
    if (!this.asPath) return false;
    const [oldUrlNoHash, oldHash] = this.asPath.split('#');
    const [newUrlNoHash, newHash] = as.split('#'); // Makes sure we scroll to the provided hash if the url/hash are the same

    if (newHash && oldUrlNoHash === newUrlNoHash && oldHash === newHash) {
      return true;
    } // If the urls are change, there's more than a hash change


    if (oldUrlNoHash !== newUrlNoHash) {
      return false;
    } // If the hash has changed, then it's a hash only change.
    // This check is necessary to handle both the enter and
    // leave hash === '' cases. The identity case falls through
    // and is treated as a next reload.


    return oldHash !== newHash;
  }

  scrollToHash(as) {
    const [, hash] = as.split('#'); // Scroll to top if the hash is just `#` with no value or `#top`
    // To mirror browsers

    if (hash === '' || hash === 'top') {
      window.scrollTo(0, 0);
      return;
    } // First we check if the element by id is found


    const idEl = document.getElementById(hash);

    if (idEl) {
      idEl.scrollIntoView();
      return;
    } // If there's no element with the id, we check the `name` property
    // To mirror browsers


    const nameEl = document.getElementsByName(hash)[0];

    if (nameEl) {
      nameEl.scrollIntoView();
    }
  }

  urlIsNew(asPath) {
    return this.asPath !== asPath;
  }
  /**
  * Prefetch page code, you may wait for the data during page rendering.
  * This feature only works in production!
  * @param url the href of prefetched page
  * @param asPath the as path of the prefetched page
  */


  async prefetch(url, asPath = url, options = {}) {
    let parsed = (0, _parseRelativeUrl.parseRelativeUrl)(url);
    let {
      pathname
    } = parsed;

    if (false) {}

    const pages = await this.pageLoader.getPageList();
    let resolvedAs = asPath;

    if (false) {} else {
      parsed.pathname = resolveDynamicRoute(parsed.pathname, pages);

      if (parsed.pathname !== pathname) {
        pathname = parsed.pathname;
        url = (0, _utils.formatWithValidation)(parsed);
      }
    }

    const route = (0, _normalizeTrailingSlash.removePathTrailingSlash)(pathname); // Prefetch is not supported in development mode because it would trigger on-demand-entries

    if (false) {}

    await Promise.all([this.pageLoader._isSsg(route).then(isSsg => {
      return isSsg ? this._getStaticData(this.pageLoader.getDataHref(url, resolvedAs, true, typeof options.locale !== 'undefined' ? options.locale : this.locale)) : false;
    }), this.pageLoader[options.priority ? 'loadPage' : 'prefetch'](route)]);
  }

  async fetchComponent(route) {
    let cancelled = false;

    const cancel = this.clc = () => {
      cancelled = true;
    };

    const componentResult = await this.pageLoader.loadPage(route);

    if (cancelled) {
      const error = new Error(`Abort fetching component for route: "${route}"`);
      error.cancelled = true;
      throw error;
    }

    if (cancel === this.clc) {
      this.clc = null;
    }

    return componentResult;
  }

  _getData(fn) {
    let cancelled = false;

    const cancel = () => {
      cancelled = true;
    };

    this.clc = cancel;
    return fn().then(data => {
      if (cancel === this.clc) {
        this.clc = null;
      }

      if (cancelled) {
        const err = new Error('Loading initial props cancelled');
        err.cancelled = true;
        throw err;
      }

      return data;
    });
  }

  _getStaticData(dataHref) {
    const {
      href: cacheKey
    } = new URL(dataHref, window.location.href);

    if ( true && !this.isPreview && this.sdc[cacheKey]) {
      return Promise.resolve(this.sdc[cacheKey]);
    }

    return fetchNextData(dataHref, this.isSsr).then(data => {
      this.sdc[cacheKey] = data;
      return data;
    });
  }

  _getServerData(dataHref) {
    const {
      href: resourceKey
    } = new URL(dataHref, window.location.href);

    if (this.sdr[resourceKey]) {
      return this.sdr[resourceKey];
    }

    return this.sdr[resourceKey] = fetchNextData(dataHref, this.isSsr).then(data => {
      delete this.sdr[resourceKey];
      return data;
    }).catch(err => {
      delete this.sdr[resourceKey];
      throw err;
    });
  }

  getInitialProps(Component, ctx) {
    const {
      Component: App
    } = this.components['/_app'];

    const AppTree = this._wrapApp(App);

    ctx.AppTree = AppTree;
    return (0, _utils.loadGetInitialProps)(App, {
      AppTree,
      Component,
      router: this,
      ctx
    });
  }

  abortComponentLoad(as, routeProps) {
    if (this.clc) {
      Router.events.emit('routeChangeError', buildCancellationError(), as, routeProps);
      this.clc();
      this.clc = null;
    }
  }

  notify(data, resetScroll) {
    return this.sub(data, this.components['/_app'].Component, resetScroll);
  }

}

exports.default = Router;
Router.events = (0, _mitt.default)();

/***/ }),

/***/ "g/15":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.execOnce = execOnce;
exports.getLocationOrigin = getLocationOrigin;
exports.getURL = getURL;
exports.getDisplayName = getDisplayName;
exports.isResSent = isResSent;
exports.loadGetInitialProps = loadGetInitialProps;
exports.formatWithValidation = formatWithValidation;
exports.ST = exports.SP = exports.urlObjectKeys = void 0;

var _formatUrl = __webpack_require__("6D7l");
/**
* Utils
*/


function execOnce(fn) {
  let used = false;
  let result;
  return (...args) => {
    if (!used) {
      used = true;
      result = fn(...args);
    }

    return result;
  };
}

function getLocationOrigin() {
  const {
    protocol,
    hostname,
    port
  } = window.location;
  return `${protocol}//${hostname}${port ? ':' + port : ''}`;
}

function getURL() {
  const {
    href
  } = window.location;
  const origin = getLocationOrigin();
  return href.substring(origin.length);
}

function getDisplayName(Component) {
  return typeof Component === 'string' ? Component : Component.displayName || Component.name || 'Unknown';
}

function isResSent(res) {
  return res.finished || res.headersSent;
}

async function loadGetInitialProps(App, ctx) {
  if (false) { var _App$prototype; } // when called from _app `ctx` is nested in `ctx`


  const res = ctx.res || ctx.ctx && ctx.ctx.res;

  if (!App.getInitialProps) {
    if (ctx.ctx && ctx.Component) {
      // @ts-ignore pageProps default
      return {
        pageProps: await loadGetInitialProps(ctx.Component, ctx.ctx)
      };
    }

    return {};
  }

  const props = await App.getInitialProps(ctx);

  if (res && isResSent(res)) {
    return props;
  }

  if (!props) {
    const message = `"${getDisplayName(App)}.getInitialProps()" should resolve to an object. But found "${props}" instead.`;
    throw new Error(message);
  }

  if (false) {}

  return props;
}

const urlObjectKeys = ['auth', 'hash', 'host', 'hostname', 'href', 'path', 'pathname', 'port', 'protocol', 'query', 'search', 'slashes'];
exports.urlObjectKeys = urlObjectKeys;

function formatWithValidation(url) {
  if (false) {}

  return (0, _formatUrl.formatUrl)(url);
}

const SP = typeof performance !== 'undefined';
exports.SP = SP;
const ST = SP && typeof performance.mark === 'function' && typeof performance.measure === 'function';
exports.ST = ST;

/***/ }),

/***/ "gguc":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.getRouteMatcher = getRouteMatcher;

function getRouteMatcher(routeRegex) {
  const {
    re,
    groups
  } = routeRegex;
  return pathname => {
    const routeMatch = re.exec(pathname);

    if (!routeMatch) {
      return false;
    }

    const decode = param => {
      try {
        return decodeURIComponent(param);
      } catch (_) {
        const err = new Error('failed to decode param');
        err.code = 'DECODE_FAILED';
        throw err;
      }
    };

    const params = {};
    Object.keys(groups).forEach(slugName => {
      const g = groups[slugName];
      const m = routeMatch[g.pos];

      if (m !== undefined) {
        params[slugName] = ~m.indexOf('/') ? m.split('/').map(entry => decode(entry)) : g.repeat ? [decode(m)] : decode(m);
      }
    });
    return params;
  };
}

/***/ }),

/***/ "hS4m":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.parseRelativeUrl = parseRelativeUrl;

var _utils = __webpack_require__("g/15");

var _querystring = __webpack_require__("3WeD");
/**
* Parses path-relative urls (e.g. `/hello/world?foo=bar`). If url isn't path-relative
* (e.g. `./hello`) then at least base must be.
* Absolute urls are rejected with one exception, in the browser, absolute urls that are on
* the current origin will be parsed as relative
*/


function parseRelativeUrl(url, base) {
  const globalBase = new URL(true ? 'http://n' : undefined);
  const resolvedBase = base ? new URL(base, globalBase) : globalBase;
  const {
    pathname,
    searchParams,
    search,
    hash,
    href,
    origin
  } = new URL(url, resolvedBase);

  if (origin !== globalBase.origin) {
    throw new Error(`invariant: invalid relative URL, router received ${url}`);
  }

  return {
    pathname,
    query: (0, _querystring.searchParamsToUrlQuery)(searchParams),
    search,
    hash,
    href: href.slice(globalBase.origin.length)
  };
}

/***/ }),

/***/ "id0+":
/***/ (function(module, exports) {

module.exports = require("react-markdown");

/***/ }),

/***/ "jYMq":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, "a", function() { return /* binding */ Layout; });

// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__("xnum");
var head_default = /*#__PURE__*/__webpack_require__.n(head_);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "nookies"
var external_nookies_ = __webpack_require__("kG9d");

// EXTERNAL MODULE: external "shards-react"
var external_shards_react_ = __webpack_require__("Eyjp");

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__("YFqc");
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);

// EXTERNAL MODULE: ./src/assets/logo.svg
var logo = __webpack_require__("mxmt");
var logo_default = /*#__PURE__*/__webpack_require__.n(logo);

// EXTERNAL MODULE: ./src/components/userSnippet/userSnippet.tsx
var userSnippet = __webpack_require__("4AIp");

// EXTERNAL MODULE: ./src/components/contexts.tsx
var contexts = __webpack_require__("Ti4I");

// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__("zr5I");
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);

// CONCATENATED MODULE: ./src/hooks/useLogout.ts

;
const useLogout = () => {
  const performLogout = async () => {
    await external_axios_default.a.get('/api/logout');
    window.location.reload();
  };

  return {
    performLogout
  };
};
// CONCATENATED MODULE: ./src/components/navigationBar/navigationBar.tsx
var __jsx = external_react_default.a.createElement;







const NavigationBar = () => {
  const {
    isAuthenticated,
    profileImageUrl
  } = Object(external_react_["useContext"])(contexts["a" /* AuthenticationContext */]);
  const {
    0: menuOpen,
    1: setMenuOpen
  } = Object(external_react_["useState"])(false);
  const {
    0: dropdownOpen,
    1: setDropdownOpen
  } = Object(external_react_["useState"])(false);
  const {
    0: userDropdownOpen,
    1: setUserDropdownOpen
  } = Object(external_react_["useState"])(false);
  const {
    performLogout
  } = useLogout();

  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };

  const toggleDropdown = () => {
    setDropdownOpen(!dropdownOpen);
  };

  const toggleUserDropdown = () => {
    setUserDropdownOpen(!userDropdownOpen);
  };

  const handleLogout = async () => {
    await performLogout();
  };

  return __jsx(external_shards_react_["Navbar"], {
    type: "dark",
    expand: "md",
    className: "nb-2"
  }, __jsx(external_shards_react_["NavbarBrand"], {
    href: "/"
  }, __jsx("img", {
    src: logo_default.a,
    className: "nb-2__ico"
  }), __jsx("span", {
    className: "nb-2__brand"
  }, "Zerochass")), __jsx(external_shards_react_["NavbarToggler"], {
    onClick: toggleMenu
  }), __jsx(external_shards_react_["Collapse"], {
    open: menuOpen,
    navbar: true
  }, __jsx(external_shards_react_["Nav"], {
    navbar: true
  }, __jsx(external_shards_react_["NavItem"], null, __jsx(external_shards_react_["NavLink"], {
    className: "nb-2__link",
    href: "/tutorials"
  }, "Tutorials"))), isAuthenticated && __jsx(external_shards_react_["Nav"], {
    navbar: true,
    className: "ml-auto align-items-center"
  }, __jsx(external_shards_react_["NavItem"], {
    className: "mr-auto"
  }, __jsx(external_shards_react_["NavLink"], {
    className: "nb-2__link",
    href: "/write"
  }, "Write")), __jsx(external_shards_react_["NavItem"], {
    className: "mr-auto"
  }, __jsx(external_shards_react_["NavLink"], {
    className: "nb-2__link",
    href: "/dashboard"
  }, "Dashboard")), __jsx(external_shards_react_["Dropdown"], {
    className: "mr-auto ml-md-4",
    open: userDropdownOpen,
    toggle: toggleUserDropdown
  }, __jsx(external_shards_react_["DropdownToggle"], {
    className: "p-0",
    nav: true
  }, __jsx(userSnippet["a" /* UserSnip */], {
    profileImageUrl: profileImageUrl,
    usePadding: false
  })), __jsx(external_shards_react_["DropdownMenu"], {
    className: "left"
  }, __jsx(external_shards_react_["DropdownItem"], null, __jsx(link_default.a, {
    href: "/planner"
  }, __jsx("a", {
    className: "main__link"
  }, "Planner"))), __jsx(external_shards_react_["DropdownItem"], null, __jsx(link_default.a, {
    href: "/profile"
  }, __jsx("a", {
    className: "main__link"
  }, "Profile"))), __jsx(external_shards_react_["DropdownItem"], null, __jsx(link_default.a, {
    href: "/account"
  }, __jsx("a", {
    className: "main__link"
  }, "Account"))), __jsx("hr", null), __jsx(external_shards_react_["DropdownItem"], {
    onClick: handleLogout
  }, "Log out"))))));
};
// CONCATENATED MODULE: ./src/components/informationSection/informationSection.tsx

var informationSection_jsx = external_react_default.a.createElement;

 //<a href="https://twitter.com/zerochass?ref_src=twsrc%5Etfw" className="twitter-follow-button" data-size="large" data-show-count="false">Follow @zerochass</a>

const InformationSection = () => {
  return informationSection_jsx("div", {
    className: "information-banner"
  }, informationSection_jsx("div", {
    className: "inner-content"
  }, informationSection_jsx("div", {
    className: "left-content"
  }, informationSection_jsx("div", {
    className: "brand-logo"
  }, informationSection_jsx("img", {
    src: logo_default.a
  })), informationSection_jsx("div", {
    className: "brand-support"
  }, informationSection_jsx("h3", {
    className: "brand-text"
  }, "zerochass"), informationSection_jsx("p", {
    className: "top"
  }, "practical and goal-oriented resources"), informationSection_jsx("p", {
    className: "top small-text"
  }, "learn by doing. enjoy what you do."), informationSection_jsx("br", null))), informationSection_jsx("div", {
    className: "right-content"
  }, informationSection_jsx("div", {
    className: "info-list"
  }, informationSection_jsx("ul", null, informationSection_jsx("li", null, informationSection_jsx(link_default.a, {
    href: "/"
  }, informationSection_jsx("a", {
    className: "link link-bold"
  }, "Zerochass"))))))));
};
// CONCATENATED MODULE: ./src/components/footer/footer.tsx

var footer_jsx = external_react_default.a.createElement;
const Footer = () => {
  return footer_jsx("div", {
    className: "footer"
  }, footer_jsx("div", {
    className: "legal"
  }, footer_jsx("p", null, "\xA9 Zerochass, LLC. All rights reserved.")));
};
// EXTERNAL MODULE: external "react-modal"
var external_react_modal_ = __webpack_require__("7koQ");
var external_react_modal_default = /*#__PURE__*/__webpack_require__.n(external_react_modal_);

// CONCATENATED MODULE: ./src/components/modal/modal.tsx

var modal_jsx = external_react_default.a.createElement;

const Modal = ({
  isOpen,
  onRequestClose,
  children
}) => {
  external_react_modal_default.a.setAppElement('#__next');
  const customStyles = {
    overlay: {
      background: 'rgba(0, 0, 0, 0.685)',
      zIndex: '9999'
    }
  };
  return modal_jsx(external_react_modal_default.a, {
    isOpen: isOpen,
    onRequestClose: onRequestClose,
    style: customStyles,
    contentLabel: "Example Modal",
    className: "modal-content"
  }, children);
};
// CONCATENATED MODULE: ./src/components/authenticationModal/authenticationModal.tsx

var authenticationModal_jsx = external_react_default.a.createElement;

const GITHUB_AUTHENTICATION_LINK = `https://github.com/login/oauth/authorize?scope=read:user%20user:email&client_id=${"4641cd510f9afeaca3b3"}`;
;
const AuthenticationModal = ({
  modalType,
  isOpen,
  onRequestClose
}) => {
  const highlightClass = 'current';
  let loginClass = highlightClass;
  let signUpClass = highlightClass;

  const onGitHubClick = () => {
    window.location.href = GITHUB_AUTHENTICATION_LINK;
  };

  const handleModalClose = () => {
    onRequestClose();
  };

  return authenticationModal_jsx(Modal, {
    isOpen: isOpen,
    onRequestClose: onRequestClose
  }, authenticationModal_jsx("div", {
    className: "modal-content"
  }, authenticationModal_jsx("i", {
    className: `fas fa-times`,
    onClick: handleModalClose
  }), authenticationModal_jsx("div", {
    className: "modal-content__inner"
  }, authenticationModal_jsx("p", {
    className: "modal-content__title"
  }, authenticationModal_jsx("span", {
    className: loginClass
  }, "Sign In"), authenticationModal_jsx("span", {
    className: "line"
  }), authenticationModal_jsx("span", {
    className: signUpClass
  }, "Zerochass")), authenticationModal_jsx("div", {
    className: "modal-content__text"
  }, authenticationModal_jsx("p", null, "Learn what interests you"), authenticationModal_jsx("p", null, "quickly and intuitively.")), authenticationModal_jsx("div", {
    className: "modal-content__buttons"
  }, authenticationModal_jsx("button", {
    className: "modal-content__sign-in",
    onClick: () => onGitHubClick()
  }, "Log in with GitHub"), authenticationModal_jsx("button", {
    className: "modal-content__sign-in disabled"
  }, "Log in with Twitter \u2014 coming soon!")))));
};
// CONCATENATED MODULE: ./src/hooks/useAuthenticationModal.tsx

var useAuthenticationModal_jsx = external_react_default.a.createElement;


;
const useAuthenticationModal = () => {
  /** Control the status of the dialog */
  const {
    0: isModalOpen,
    1: setIsModalOpen
  } = Object(external_react_["useState"])(false);
  /** Toggle the current status of the dialog */

  const toggleAuthenticationModal = () => {
    setIsModalOpen(!isModalOpen);
  };
  /** Render the dialog */


  const AuthModal = () => {
    return useAuthenticationModal_jsx(external_react_default.a.Fragment, null, useAuthenticationModal_jsx(AuthenticationModal, {
      isOpen: isModalOpen,
      onRequestClose: toggleAuthenticationModal
    }));
  };

  return {
    toggleAuthenticationModal,
    AuthModal
  };
};
// CONCATENATED MODULE: ./src/features/layout/layout.tsx
var layout_jsx = external_react_default.a.createElement;








const defaultImage = "https://s3.us-east-1.amazonaws.com/zerochass-assets/images/zerochass-rect.PNG";
const Layout = props => {
  const {
    children,
    pageTitle,
    description,
    keywords,
    slug,
    image,
    large
  } = props;
  const fullPageTitle = `${pageTitle} | Zerochass`;
  const {
    0: tutorial,
    1: setTutorial
  } = Object(external_react_["useState"])(null);
  const {
    0: isAuthenticated,
    1: setIsAuthenticated
  } = Object(external_react_["useState"])(null);
  const {
    0: profileImageUrl,
    1: setProfileImageUrl
  } = Object(external_react_["useState"])(null);
  const {
    toggleAuthenticationModal,
    AuthModal
  } = useAuthenticationModal();
  /** Determines if a user is authenticated client-side */

  Object(external_react_["useEffect"])(() => {
    const {
      zerochassClientCookie
    } = Object(external_nookies_["parseCookies"])();

    if (zerochassClientCookie) {
      const {
        authenticated,
        expires,
        profileImageUrl
      } = JSON.parse(zerochassClientCookie);
      setIsAuthenticated(authenticated);
      setProfileImageUrl(profileImageUrl);
    }
  }, [isAuthenticated, profileImageUrl]);
  return layout_jsx(external_react_default.a.Fragment, null, layout_jsx(head_default.a, null, layout_jsx("meta", {
    name: "viewport",
    content: "width=device-width, initial-scale=1"
  }), layout_jsx("meta", {
    name: "url",
    content: `${"https://zerochass.io"}/${slug}`
  }), layout_jsx("meta", {
    name: "description",
    content: description
  }), layout_jsx("meta", {
    name: "keywords",
    content: keywords
  }), layout_jsx("meta", {
    name: "robots",
    content: "index, follow"
  }), layout_jsx("meta", {
    name: "twitter:card",
    content: large ? "summary_large_image" : "summary"
  }), layout_jsx("meta", {
    name: "twitter:site",
    content: "@zerochass"
  }), layout_jsx("meta", {
    name: "twitter:title",
    content: fullPageTitle
  }), layout_jsx("meta", {
    name: "twitter:description",
    content: description
  }), layout_jsx("meta", {
    name: "twitter:image",
    content: image ? image : defaultImage
  }), layout_jsx("title", null, fullPageTitle), layout_jsx("script", {
    async: true,
    src: "https://www.googletagmanager.com/gtag/js?id=UA-163465719-1"
  }), layout_jsx("script", {
    dangerouslySetInnerHTML: {
      __html: `
                    window.dataLayer = window.dataLayer || [];
                    function gtag(){dataLayer.push(arguments);}
                    gtag("js", new Date());
                    gtag("config", "UA-163465719-1");
                    `
    }
  }), layout_jsx("script", {
    async: true,
    src: "https://platform.twitter.com/widgets.js",
    charSet: "utf-8"
  })), layout_jsx("section", {
    className: "layout"
  }, layout_jsx(contexts["a" /* AuthenticationContext */].Provider, {
    value: {
      isAuthenticated,
      profileImageUrl,
      toggleAuthenticationModal
    }
  }, layout_jsx(NavigationBar, null), layout_jsx("div", {
    className: "app__body"
  }, children), layout_jsx(InformationSection, null), layout_jsx(AuthModal, null))), layout_jsx(Footer, null));
};

/***/ }),

/***/ "kG9d":
/***/ (function(module, exports) {

module.exports = require("nookies");

/***/ }),

/***/ "mxmt":
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjxzdmcKICAgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIgogICB4bWxuczpjYz0iaHR0cDovL2NyZWF0aXZlY29tbW9ucy5vcmcvbnMjIgogICB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiCiAgIHhtbG5zOnN2Zz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciCiAgIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIKICAgeG1sbnM6c29kaXBvZGk9Imh0dHA6Ly9zb2RpcG9kaS5zb3VyY2Vmb3JnZS5uZXQvRFREL3NvZGlwb2RpLTAuZHRkIgogICB4bWxuczppbmtzY2FwZT0iaHR0cDovL3d3dy5pbmtzY2FwZS5vcmcvbmFtZXNwYWNlcy9pbmtzY2FwZSIKICAgaWQ9InN2ZyIKICAgdmVyc2lvbj0iMS4xIgogICB3aWR0aD0iNDAwIgogICBoZWlnaHQ9IjM3OC43ODU3NjQxMzExOTMzIgogICBzdHlsZT0iZGlzcGxheTogYmxvY2s7IgogICBzb2RpcG9kaTpkb2NuYW1lPSJsb2dvLnN2ZyIKICAgaW5rc2NhcGU6dmVyc2lvbj0iMC45Mi4yICg1YzNlODBkLCAyMDE3LTA4LTA2KSI+CiAgPG1ldGFkYXRhCiAgICAgaWQ9Im1ldGFkYXRhMjEiPgogICAgPHJkZjpSREY+CiAgICAgIDxjYzpXb3JrCiAgICAgICAgIHJkZjphYm91dD0iIj4KICAgICAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgICAgICA8ZGM6dHlwZQogICAgICAgICAgIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiIC8+CiAgICAgICAgPGRjOnRpdGxlPjwvZGM6dGl0bGU+CiAgICAgIDwvY2M6V29yaz4KICAgIDwvcmRmOlJERj4KICA8L21ldGFkYXRhPgogIDxkZWZzCiAgICAgaWQ9ImRlZnMxOSIgLz4KICA8c29kaXBvZGk6bmFtZWR2aWV3CiAgICAgcGFnZWNvbG9yPSIjZmZmZmZmIgogICAgIGJvcmRlcmNvbG9yPSIjNjY2NjY2IgogICAgIGJvcmRlcm9wYWNpdHk9IjEiCiAgICAgb2JqZWN0dG9sZXJhbmNlPSIxMCIKICAgICBncmlkdG9sZXJhbmNlPSIxMCIKICAgICBndWlkZXRvbGVyYW5jZT0iMTAiCiAgICAgaW5rc2NhcGU6cGFnZW9wYWNpdHk9IjAiCiAgICAgaW5rc2NhcGU6cGFnZXNoYWRvdz0iMiIKICAgICBpbmtzY2FwZTp3aW5kb3ctd2lkdGg9IjE5MjAiCiAgICAgaW5rc2NhcGU6d2luZG93LWhlaWdodD0iMTA1NyIKICAgICBpZD0ibmFtZWR2aWV3MTciCiAgICAgc2hvd2dyaWQ9ImZhbHNlIgogICAgIGlua3NjYXBlOnpvb209IjAuNjIzMDQzNDciCiAgICAgaW5rc2NhcGU6Y3g9IjIwMCIKICAgICBpbmtzY2FwZTpjeT0iMTg5LjM5Mjg4IgogICAgIGlua3NjYXBlOndpbmRvdy14PSIxOTEyIgogICAgIGlua3NjYXBlOndpbmRvdy15PSI2IgogICAgIGlua3NjYXBlOndpbmRvdy1tYXhpbWl6ZWQ9IjEiCiAgICAgaW5rc2NhcGU6Y3VycmVudC1sYXllcj0ic3ZnIiAvPgogIDxnCiAgICAgaWQ9InN2Z2ciPgogICAgPHBhdGgKICAgICAgIGlkPSJwYXRoMCIKICAgICAgIGQ9Ik0xODUuMzQ1IDEwMC4zOTYgQyAxNDEuNjYyIDEwNC43MzQsMTA4LjQ3NyAxMzYuMzU0LDEwMy4yMjUgMTc4LjY0NiBDIDk2LjY0MyAyMzEuNjQ5LDE0My42NzcgMjgwLjQ0NiwxOTguNDg3IDI3Ny40NzkgQyAyMzguOTI2IDI3NS4yODksMjY2LjEwNCAyNTQuNTk4LDI3Ni42MDIgMjE4LjAwOCBDIDI3Ny44MTYgMjEzLjc3NywyNzguMTU1IDIxMS4zMzEsMjc3LjAwOSAyMTUuMDczIEMgMjY2LjU5OCAyNDkuMDY3LDI0MC4zMTMgMjY3LjM4NSwyMDEuOTE0IDI2Ny40MDggQyAxNTUuNjcyIDI2Ny40MzYsMTE2LjA3NCAyMjcuNjIyLDExOS4xNjYgMTg0LjIwOSBDIDEyMi42NjUgMTM1LjA5NiwxNzAuMTcyIDEwMS4zNDAsMjIwLjIzNyAxMTIuMzkzIEMgMjQ4LjE5MyAxMTguNTY1LDI3Mi40MjMgMTQwLjYwNSwyODAuMDAyIDE2Ni43NTYgQyAyODAuMzU0IDE2Ny45NjksMjgwLjY4OCAxNjguODIzLDI4MC43NDUgMTY4LjY1MiBDIDI4MS4wMTQgMTY3Ljg0NiwyNzguMzA2IDE1OS40MDEsMjc2LjE2MyAxNTQuMzYxIEMgMjYxLjI2NSAxMTkuMzMzLDIyMy4wODkgOTYuNjQ4LDE4NS4zNDUgMTAwLjM5NiAiCiAgICAgICBzdHJva2U9Im5vbmUiCiAgICAgICBmaWxsPSIjNTQwZDZlIgogICAgICAgZmlsbC1ydWxlPSJldmVub2RkIiAvPgogICAgPHBhdGgKICAgICAgIGlkPSJwYXRoMSIKICAgICAgIGQ9IiIKICAgICAgIHN0cm9rZT0ibm9uZSIKICAgICAgIGZpbGw9IiNiZjFmMWYiCiAgICAgICBmaWxsLXJ1bGU9ImV2ZW5vZGQiIC8+CiAgICA8cGF0aAogICAgICAgaWQ9InBhdGgyIgogICAgICAgZD0iTTMxNC4zMDYgMTkyLjA0NSBDIDMxNC4zMDYgMTkzLjc4NSwzMTQuMzcwIDE5NS4xNDQsMzE0LjQ0OSAxOTUuMDY1IEMgMzE0LjY0NyAxOTQuODY3LDMxNC42NjMgMTg5LjIzOCwzMTQuNDY1IDE4OS4wNDEgQyAzMTQuMzc4IDE4OC45NTMsMzE0LjMwNiAxOTAuMzA1LDMxNC4zMDYgMTkyLjA0NSAiCiAgICAgICBzdHJva2U9Im5vbmUiCiAgICAgICBmaWxsPSIjZmYwMDNmIgogICAgICAgZmlsbC1ydWxlPSJldmVub2RkIiAvPgogICAgPHBhdGgKICAgICAgIGlkPSJwYXRoMyIKICAgICAgIGQ9IiIKICAgICAgIHN0cm9rZT0ibm9uZSIKICAgICAgIGZpbGw9IiNmZjAwMDAiCiAgICAgICBmaWxsLXJ1bGU9ImV2ZW5vZGQiIC8+CiAgICA8cGF0aAogICAgICAgaWQ9InBhdGg0IgogICAgICAgZD0iIgogICAgICAgc3Ryb2tlPSJub25lIgogICAgICAgZmlsbD0iI2ZlMWM1NCIKICAgICAgIGZpbGwtcnVsZT0iZXZlbm9kZCIgLz4KICAgIDxwYXRoCiAgICAgICBpZD0icGF0aDUiCiAgICAgICBkPSIiCiAgICAgICBzdHJva2U9Im5vbmUiCiAgICAgICBmaWxsPSIjZmUyODY1IgogICAgICAgZmlsbC1ydWxlPSJldmVub2RkIiAvPgogICAgPHBhdGgKICAgICAgIGlkPSJwYXRoNiIKICAgICAgIGQ9IiIKICAgICAgIHN0cm9rZT0ibm9uZSIKICAgICAgIGZpbGw9IiNmZjI0NDgiCiAgICAgICBmaWxsLXJ1bGU9ImV2ZW5vZGQiIC8+CiAgICA8cGF0aAogICAgICAgaWQ9InBhdGg3IgogICAgICAgZD0iIgogICAgICAgc3Ryb2tlPSJub25lIgogICAgICAgZmlsbD0iI2ZmMmE1NSIKICAgICAgIGZpbGwtcnVsZT0iZXZlbm9kZCIgLz4KICAgIDxwYXRoCiAgICAgICBpZD0icGF0aDgiCiAgICAgICBkPSJNMTkzLjAyMiA3Mi40ODggQyAxNDQuMTIyIDc0LjU3MCwxMDEuMDQ4IDEwOC43MDQsODcuNDA3IDE1Ni4xODMgQyA4NS43MjkgMTYyLjAyMiw4NS43NTQgMTYyLjkxMSw4Ny40NTMgMTU3Ljg1MSBDIDEwNS4wNzAgMTA1LjM4MywxNTkuMDY4IDc1LjY0MSwyMTMuMTQ0IDg4LjYyMSBDIDI1MC44NzggOTcuNjc5LDI4MC44MjUgMTI3LjAyNiwyOTAuMTQ3IDE2NC4wODMgQyAyOTIuMjQ0IDE3Mi40MTksMjkzLjE3OSAxNzkuOTM1LDI5Mi45MzggMTg2LjUzMyBDIDI5Mi42NzIgMTkzLjg0NiwyOTIuNjYyIDE5NS4xMTEsMjkyLjg3MCAxOTUuMTg0IEMgMjkyLjk4MSAxOTUuMjIzLDI5Mi45NDggMTk2LjUxMSwyOTIuNzk2IDE5OC4wNDYgQyAyODcuNjc4IDI0OS43NzAsMjQwLjE2NiAyOTEuOTU4LDE4Ny4wMjAgMjkxLjk3MCBDIDEzOC40MjcgMjkxLjk4MiwxMDMuOTQ4IDI2Ny45MDcsOTEuMjgzIDIyNS4xMjIgQyA4OS44NDcgMjIwLjI3Myw4OS44OTQgMjIwLjQxMSw4OS43NDUgMjIwLjU1OSBDIDg5LjI0OSAyMjEuMDU2LDkzLjgzMyAyMzUuODgwLDk2LjMxMSAyNDEuNzkwIEMgMTEzLjUxOSAyODIuODM0LDE0OS4xMDQgMzA1LjE0MSwxOTcuNDg4IDMwNS4yMTMgQyAyNTguNTQwIDMwNS4zMDMsMzExLjg4MiAyNTQuMDA5LDMxMy45NDIgMTkzLjIzMSBDIDMxNC4wMzYgMTkwLjQyOSwzMTQuMTk0IDE4OC4xMzcsMzE0LjI5MiAxODguMTM3IEMgMzE0LjUxMiAxODguMTM3LDMxNC40MzggMTg0LjM4OSwzMTQuMjEwIDE4NC4wMjEgQyAzMTQuMTE5IDE4My44NzQsMzEzLjkwOSAxODIuMDA4LDMxMy43NDQgMTc5Ljg3NCBDIDMwOC44NjggMTE3LjAzNywyNTUuNzgzIDY5LjgxNywxOTMuMDIyIDcyLjQ4OCAiCiAgICAgICBzdHJva2U9Im5vbmUiCiAgICAgICBmaWxsPSIjZmYzMzY2IgogICAgICAgZmlsbC1ydWxlPSJldmVub2RkIiAvPgogICAgPHBhdGgKICAgICAgIGlkPSJwYXRoOSIKICAgICAgIGQ9Ik0zMTQuMTMwIDE5MS4yMDcgQyAzMTQuMTMwIDE5Mi44MTksMzE0LjE3NiAxOTMuNDc5LDMxNC4yMzIgMTkyLjY3MyBDIDMxNC4yODkgMTkxLjg2NywzMTQuMjg5IDE5MC41NDgsMzE0LjIzMiAxODkuNzQyIEMgMzE0LjE3NiAxODguOTM2LDMxNC4xMzAgMTg5LjU5NSwzMTQuMTMwIDE5MS4yMDcgIgogICAgICAgc3Ryb2tlPSJub25lIgogICAgICAgZmlsbD0iI2ZmMmM1ZSIKICAgICAgIGZpbGwtcnVsZT0iZXZlbm9kZCIgLz4KICAgIDxwYXRoCiAgICAgICBpZD0icGF0aDEwIgogICAgICAgZD0iIgogICAgICAgc3Ryb2tlPSJub25lIgogICAgICAgZmlsbD0iI2ZmMmI2NSIKICAgICAgIGZpbGwtcnVsZT0iZXZlbm9kZCIgLz4KICAgIDxwYXRoCiAgICAgICBpZD0icGF0aDExIgogICAgICAgZD0iIgogICAgICAgc3Ryb2tlPSJub25lIgogICAgICAgZmlsbD0iI2ZmMmM2MSIKICAgICAgIGZpbGwtcnVsZT0iZXZlbm9kZCIgLz4KICAgIDxwYXRoCiAgICAgICBpZD0icGF0aDEyIgogICAgICAgZD0iTTE4MC43NzYgMC4yOTkgQyA2OS45MDkgNi4wMjYsLTEyLjI2OSAxMDMuNzMxLDEuNTQ0IDIxMy4zOTggQyAxMi4wMzAgMjk2LjY2MCw3Ny4zOTMgMzYzLjQ0NiwxNjEuMDYxIDM3Ni4zODggQyAyNDYuMjk1IDM4OS41NzMsMzMwLjMwNCAzNDMuOTc3LDM2NC44MzQgMjY1Ljc5MCBDIDM2Ny4zNjAgMjYwLjA3MCwzNjcuMjE4IDI1OS42NjAsMzY0LjU4MyAyNjUuMDY4IEMgMzM3LjA4OSAzMjEuNDk5LDI4MS41OTggMzU5LjA3MCwyMTYuNzQ4IDM2NS4xNjAgQyAyMTEuNDkwIDM2NS42NTQsMTg5Ljg0NiAzNjUuNjU5LDE4NS4wNjYgMzY1LjE2OCBDIDEzNC41MjQgMzU5Ljk3NCw5Mi41MDUgMzM4LjM3NCw2MS4wNzEgMzAxLjQyNiBDIDAuMzU2IDIzMC4wNjMsNy41MzUgMTIzLjQ4MCw3Ny4zMDUgNjAuNDM2IEMgMTY2LjY0OCAtMjAuMjk1LDMwOC45NDEgNS4xMDMsMzYzLjQ3NSAxMTEuNTE0IEMgMzY3LjE2OCAxMTguNzE5LDM2Ny42NTggMTE5LjI4MCwzNjQuOTcxIDExMy4yMjYgQyAzMzIuOTgyIDQxLjE1NSwyNTkuNjkzIC0zLjc3OCwxODAuNzc2IDAuMjk5ICIKICAgICAgIHN0cm9rZT0ibm9uZSIKICAgICAgIGZpbGw9IiNmNmY3ZjgiCiAgICAgICBmaWxsLXJ1bGU9ImV2ZW5vZGQiIC8+CiAgPC9nPgo8L3N2Zz4K"

/***/ }),

/***/ "nOHt":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireWildcard = __webpack_require__("284h");

var _interopRequireDefault = __webpack_require__("TqRt");

exports.__esModule = true;
exports.useRouter = useRouter;
exports.makePublicRouterInstance = makePublicRouterInstance;
exports.createRouter = exports.withRouter = exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__("cDcd"));

var _router2 = _interopRequireWildcard(__webpack_require__("elyg"));

exports.Router = _router2.default;
exports.NextRouter = _router2.NextRouter;

var _routerContext = __webpack_require__("Osoz");

var _withRouter = _interopRequireDefault(__webpack_require__("0Bsm"));

exports.withRouter = _withRouter.default;
/* global window */

const singletonRouter = {
  router: null,
  // holds the actual router instance
  readyCallbacks: [],

  ready(cb) {
    if (this.router) return cb();

    if (false) {}
  }

}; // Create public properties and methods of the router in the singletonRouter

const urlPropertyFields = ['pathname', 'route', 'query', 'asPath', 'components', 'isFallback', 'basePath', 'locale', 'locales', 'defaultLocale', 'isReady', 'isPreview', 'isLocaleDomain'];
const routerEvents = ['routeChangeStart', 'beforeHistoryChange', 'routeChangeComplete', 'routeChangeError', 'hashChangeStart', 'hashChangeComplete'];
const coreMethodFields = ['push', 'replace', 'reload', 'back', 'prefetch', 'beforePopState']; // Events is a static property on the router, the router doesn't have to be initialized to use it

Object.defineProperty(singletonRouter, 'events', {
  get() {
    return _router2.default.events;
  }

});
urlPropertyFields.forEach(field => {
  // Here we need to use Object.defineProperty because, we need to return
  // the property assigned to the actual router
  // The value might get changed as we change routes and this is the
  // proper way to access it
  Object.defineProperty(singletonRouter, field, {
    get() {
      const router = getRouter();
      return router[field];
    }

  });
});
coreMethodFields.forEach(field => {
  // We don't really know the types here, so we add them later instead
  ;

  singletonRouter[field] = (...args) => {
    const router = getRouter();
    return router[field](...args);
  };
});
routerEvents.forEach(event => {
  singletonRouter.ready(() => {
    _router2.default.events.on(event, (...args) => {
      const eventField = `on${event.charAt(0).toUpperCase()}${event.substring(1)}`;
      const _singletonRouter = singletonRouter;

      if (_singletonRouter[eventField]) {
        try {
          _singletonRouter[eventField](...args);
        } catch (err) {
          console.error(`Error when running the Router event: ${eventField}`);
          console.error(`${err.message}\n${err.stack}`);
        }
      }
    });
  });
});

function getRouter() {
  if (!singletonRouter.router) {
    const message = 'No router instance found.\n' + 'You should only use "next/router" inside the client side of your app.\n';
    throw new Error(message);
  }

  return singletonRouter.router;
} // Export the singletonRouter and this is the public API.


var _default = singletonRouter; // Reexport the withRoute HOC

exports.default = _default;

function useRouter() {
  return _react.default.useContext(_routerContext.RouterContext);
} // INTERNAL APIS
// -------------
// (do not use following exports inside the app)
// Create a router and assign it as the singleton instance.
// This is used in client side when we are initilizing the app.
// This should **not** use inside the server.


const createRouter = (...args) => {
  singletonRouter.router = new _router2.default(...args);
  singletonRouter.readyCallbacks.forEach(cb => cb());
  singletonRouter.readyCallbacks = [];
  return singletonRouter.router;
}; // This function is used to create the `withRouter` router instance


exports.createRouter = createRouter;

function makePublicRouterInstance(router) {
  const _router = router;
  const instance = {};

  for (const property of urlPropertyFields) {
    if (typeof _router[property] === 'object') {
      instance[property] = Object.assign(Array.isArray(_router[property]) ? [] : {}, _router[property]); // makes sure query is not stateful

      continue;
    }

    instance[property] = _router[property];
  } // Events is a static property on the router, the router doesn't have to be initialized to use it


  instance.events = _router2.default.events;
  coreMethodFields.forEach(field => {
    instance[field] = (...args) => {
      return _router[field](...args);
    };
  });
  return instance;
}

/***/ }),

/***/ "vNVm":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.useIntersection = useIntersection;

var _react = __webpack_require__("cDcd");

var _requestIdleCallback = __webpack_require__("0G5g");

const hasIntersectionObserver = typeof IntersectionObserver !== 'undefined';

function useIntersection({
  rootMargin,
  disabled
}) {
  const isDisabled = disabled || !hasIntersectionObserver;
  const unobserve = (0, _react.useRef)();
  const [visible, setVisible] = (0, _react.useState)(false);
  const setRef = (0, _react.useCallback)(el => {
    if (unobserve.current) {
      unobserve.current();
      unobserve.current = undefined;
    }

    if (isDisabled || visible) return;

    if (el && el.tagName) {
      unobserve.current = observe(el, isVisible => isVisible && setVisible(isVisible), {
        rootMargin
      });
    }
  }, [isDisabled, rootMargin, visible]);
  (0, _react.useEffect)(() => {
    if (!hasIntersectionObserver) {
      if (!visible) {
        const idleCallback = (0, _requestIdleCallback.requestIdleCallback)(() => setVisible(true));
        return () => (0, _requestIdleCallback.cancelIdleCallback)(idleCallback);
      }
    }
  }, [visible]);
  return [setRef, visible];
}

function observe(element, callback, options) {
  const {
    id,
    observer,
    elements
  } = createObserver(options);
  elements.set(element, callback);
  observer.observe(element);
  return function unobserve() {
    elements.delete(element);
    observer.unobserve(element); // Destroy observer when there's nothing left to watch:

    if (elements.size === 0) {
      observer.disconnect();
      observers.delete(id);
    }
  };
}

const observers = new Map();

function createObserver(options) {
  const id = options.rootMargin || '';
  let instance = observers.get(id);

  if (instance) {
    return instance;
  }

  const elements = new Map();
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const callback = elements.get(entry.target);
      const isVisible = entry.isIntersecting || entry.intersectionRatio > 0;

      if (callback && isVisible) {
        callback(isVisible);
      }
    });
  }, options);
  observers.set(id, instance = {
    id,
    observer,
    elements
  });
  return instance;
}

/***/ }),

/***/ "wkBG":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
exports.__esModule=true;exports.normalizePathSep=normalizePathSep;exports.denormalizePagePath=denormalizePagePath;function normalizePathSep(path){return path.replace(/\\/g,'/');}function denormalizePagePath(page){page=normalizePathSep(page);if(page.startsWith('/index/')){page=page.slice(6);}else if(page==='/index'){page='/';}return page;}
//# sourceMappingURL=denormalize-page-path.js.map

/***/ }),

/***/ "xnum":
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ "zr5I":
/***/ (function(module, exports) {

module.exports = require("axios");

/***/ })

/******/ });